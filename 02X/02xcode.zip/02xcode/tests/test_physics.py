"""Behavior checks against analytically known manufactured heat solutions."""

import sys
from pathlib import Path
import unittest

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"python"))
from twinproof.model import Case
from twinproof.solver import LocalSolver
from twinproof.evidence import Verifier, boundary_error, residual_norm, reference_error


class HeatPhysicsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.solver = LocalSolver()
        cls.verifier = Verifier(cls.solver)

    @classmethod
    def tearDownClass(cls):
        cls.solver.close()

    def test_valid_manufactured_solution(self):
        case = Case("gold")
        run = self.solver.run(case)
        self.assertEqual("converged",run["solver_status"])
        self.assertLess(abs(run["temperature_k"][8*17+8] - 320.03219), .001)
        self.assertLess(boundary_error(run), 1e-6)
        self.assertLess(residual_norm(run), 1e-4)
        self.assertLess(reference_error(case,run), .05)
        self.assertEqual(self.verifier.verify(case,run).decision,"PASS_WITH_EVIDENCE")

    def test_boundaries_swapped_are_rejected(self):
        case=Case("swap")
        report=self.verifier.verify(case,self.solver.run(case,"swap_boundaries"))
        self.assertEqual(report.decision,"REJECT_WITH_CAUSE")
        self.assertIn("readback failed",report.reasons)

    def test_false_convergence_is_rejected(self):
        case=Case("false")
        run=self.solver.run(case,"fake_converged")
        self.assertEqual("converged",run["solver_status"])
        self.assertGreater(residual_norm(run),1)
        self.assertEqual(self.verifier.verify(case,run).decision,"REJECT_WITH_CAUSE")

    def test_fault_matrix_rejects_all_known_corruptions(self):
        case=Case("matrix")
        for fault in ("reverse_source", "missing_source", "wrong_conductivity", "short_iteration", "tamper_center"):
            with self.subTest(fault=fault):
                run=self.solver.run(case,fault)
                self.assertEqual(self.verifier.verify(case,run).decision,"REJECT_WITH_CAUSE")

    def test_insufficient_budget_stops_without_pass(self):
        case=Case("budget")
        run=self.solver.run(case)
        report=self.verifier.verify(case,run,budget=2)
        self.assertEqual(report.decision,"HUMAN_ESCALATION")
        self.assertFalse(report.allowed)
        self.assertLessEqual(report.used_units,2)

    def test_expensive_refinement_is_required_by_physical_risk(self):
        case=Case("high",amplitude_k=30)
        run=self.solver.run(case)
        self.assertEqual(self.verifier.verify(case,run,budget=8).decision,"HUMAN_ESCALATION")
        full=self.verifier.verify(case,run,budget=20)
        self.assertEqual(full.decision,"PASS_WITH_EVIDENCE")
        self.assertEqual(full.used_units,20)
        self.assertEqual(len(full.checks),6)

    def test_coarse_mesh_can_converge_but_not_meet_reference_accuracy(self):
        case=Case("coarse",n=9,amplitude_k=30)
        run=self.solver.run(case)
        self.assertEqual(run["solver_status"],"converged")
        self.assertGreater(reference_error(case,run),.17)
        self.assertEqual(self.verifier.verify(case,run).decision,"REJECT_WITH_CAUSE")

    def test_self_report_only_never_claims_independent_evidence(self):
        case=Case("weak")
        report=self.verifier.verify(case,self.solver.run(case),policy="exit_only")
        self.assertEqual(report.decision,"PASS_UNVERIFIED")
        self.assertNotEqual(report.decision,"PASS_WITH_EVIDENCE")

    def test_invalid_cases_are_not_sent_to_solver(self):
        for kwargs in ({"n":16}, {"conductivity":0}, {"left_k":float("nan")},
                       {"case_id":"../../x"}, {"source_scale":999}, {"risk_level":"normal"}):
            with self.subTest(kwargs=kwargs), self.assertRaises((TypeError,ValueError)):
                Case(**{"case_id":"bad",**kwargs})

    def test_malformed_binary_result_is_refused(self):
        case=Case("bad-result")
        bad=self.solver.run(case)
        bad["temperature_k"] = bad["temperature_k"][:-1]
        # The production runner validates shape before this ever reaches the verifier;
        # here we assert the contract at its publicly visible parsing seam.
        from unittest.mock import patch
        import subprocess
        with patch("twinproof.solver.subprocess.run") as run_process:
            run_process.return_value.returncode=0
            import json
            run_process.return_value.stdout=json.dumps(bad)
            with self.assertRaises(ValueError):
                self.solver.run(case)


if __name__=="__main__":
    unittest.main()
