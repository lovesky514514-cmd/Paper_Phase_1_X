import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"python"))
from twinproof.solver import LocalSolver
from twinproof.evaluation import cases, wilson, experiment


class EvaluationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.solver=LocalSolver()

    @classmethod
    def tearDownClass(cls):
        cls.solver.close()

    def test_wilson_bounds(self):
        self.assertEqual(wilson(0,0),[None,None])
        a,b=wilson(0,30)
        self.assertEqual(a,0)
        self.assertGreater(b,0)
        self.assertLess(b,.15)

    def test_seed_produces_identical_cases(self):
        self.assertEqual(list(cases(4,16)),list(cases(4,16)))
        self.assertNotEqual(list(cases(4,16)),list(cases(5,16)))

    def test_policy_results_reproduce_ignoring_cpu_clock(self):
        x=experiment(self.solver,count=12,seed=7)
        y=experiment(self.solver,count=12,seed=7)
        for policy in x["summary"]:
            x["summary"][policy].pop("p95_verification_wall_ms_observed")
            y["summary"][policy].pop("p95_verification_wall_ms_observed")
        for records in x["records"].values():
            for r in records:r.pop("latency_ms")
        for records in y["records"].values():
            for r in records:r.pop("latency_ms")
        self.assertEqual(x,y)

    def test_all_policies_face_identical_truth(self):
        data=experiment(self.solver,count=12,seed=13)
        first=[r["truth_valid"] for r in data["records"]["exit_only"]]
        for rows in data["records"].values():
            self.assertEqual(first,[r["truth_valid"] for r in rows])


if __name__=="__main__":unittest.main()
