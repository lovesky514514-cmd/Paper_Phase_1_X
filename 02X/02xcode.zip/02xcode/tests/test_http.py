"""Exercise the public loopback /verify seam with a real HTTP request."""

from dataclasses import asdict
import json
import sys
import tempfile
import threading
from http.server import ThreadingHTTPServer
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen
import unittest

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"python"))
from twinproof.model import Case
from twinproof.server import handler_for
from twinproof.solver import LocalSolver
from twinproof.twin import TwinStore


class HttpTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.solver=LocalSolver()
        cls.tmp=tempfile.TemporaryDirectory()
        store=TwinStore(Path(cls.tmp.name)/"db.sqlite")
        cls.server=ThreadingHTTPServer(("127.0.0.1",0),handler_for(cls.solver,store))
        cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=5)
        cls.solver.close()
        cls.tmp.cleanup()

    def send(self, payload,content_type="application/json",route="/verify"):
        request=Request(f"http://127.0.0.1:{self.server.server_port}{route}",
                        data=json.dumps(payload).encode(),
                        headers={"Content-Type":content_type},method="POST")
        try:
            with urlopen(request,timeout=10) as response:
                return response.status,json.load(response)
        except HTTPError as error:
            return error.code,json.loads(error.read()) if error.code==400 else {}

    def test_valid_call_returns_evidence_not_just_exit_code(self):
        status,payload=self.send({"case":asdict(Case("web"))})
        self.assertEqual(status,200)
        self.assertEqual(payload["report"]["decision"],"PASS_WITH_EVIDENCE")
        self.assertTrue(payload["report"]["model_digest"])
        self.assertEqual(payload["twin_update"],"NOT_REQUESTED")

    def test_unknown_fault_cannot_be_injected_via_agent_interface(self):
        status,_=self.send({"case":asdict(Case("web")),"fault":"tamper_center"})
        self.assertEqual(status,400)
        status,_=self.send({"case":{**asdict(Case("web")),"risk_level":"normal"}})
        self.assertEqual(status,400)

    def test_bad_content_type_and_route(self):
        self.assertEqual(self.send({"case":{}},content_type="text/plain")[0],415)
        self.assertEqual(self.send({"case":{}},route="/command")[0],404)

    def test_low_budget_refuses_optimistic_pass(self):
        code,report=self.send({"case":asdict(Case("web")),"budget":1})
        self.assertEqual(code,200)
        self.assertEqual(report["report"]["decision"],"HUMAN_ESCALATION")


if __name__=="__main__":unittest.main()
