"""Use an isolated SQLite file to prove version, evidence and sensor gates."""

import tempfile
import time
import sys
from dataclasses import replace
from pathlib import Path
import unittest

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"python"))
from twinproof.model import Case
from twinproof.solver import LocalSolver
from twinproof.evidence import Verifier
from twinproof.twin import Observation,TwinStore


class TwinUpdateTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.solver=LocalSolver()
        cls.verifier=Verifier(cls.solver)

    @classmethod
    def tearDownClass(cls):
        cls.solver.close()

    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.store=TwinStore(Path(self.tmp.name)/"twin.sqlite")
        self.case=Case("plant")
        self.run=self.solver.run(self.case)
        self.report=self.verifier.verify(self.case,self.run)
        self.now=1700000000
        self.obs=Observation("center",self.run["temperature_k"][8*17+8]+.05,self.now)

    def tearDown(self):
        self.tmp.cleanup()

    def test_good_update_then_stale_version_freezes(self):
        self.assertEqual(self.store.update(self.case,self.run,self.report,self.obs,now_s=self.now),"SYNTHETIC_UPDATE_ACCEPTED")
        self.assertEqual(self.store.update(self.case,self.run,self.report,self.obs,now_s=self.now),"FROZEN_VERSION_CONFLICT")
        self.assertEqual(self.store.state("plant")[0],1)

    def test_bad_sensor_freezes(self):
        variants=[(replace(self.obs,source="web"),"FROZEN_BAD_SOURCE"),
                  (replace(self.obs,sensor_id="unknown"),"FROZEN_BAD_SOURCE"),
                  (replace(self.obs,observed_k=self.obs.observed_k+5),"FROZEN_DRIFT"),
                  (replace(self.obs,measured_at_s=self.now-121),"FROZEN_STALE_OBSERVATION"),
                  (replace(self.obs,measured_at_s=self.now+1),"FROZEN_STALE_OBSERVATION")]
        for obs, expected in variants:
            with self.subTest(expected=expected):
                self.assertEqual(self.store.update(self.case,self.run,self.report,obs,now_s=self.now),expected)
                self.assertIsNone(self.store.state("plant"))

    def test_forged_report_and_changed_grid_do_not_update(self):
        forged=replace(self.report,model_digest="altered")
        self.assertEqual(self.store.update(self.case,self.run,forged,self.obs,now_s=self.now),"FROZEN_UNVERIFIABLE")
        corrupt={**self.run,"temperature_k":list(self.run["temperature_k"])}
        corrupt["temperature_k"][144]+=1
        self.assertEqual(self.store.update(self.case,corrupt,self.report,self.obs,now_s=self.now),"FROZEN_UNVERIFIABLE")

    def test_unverified_pass_never_updates(self):
        weak=self.verifier.verify(self.case,self.run,policy="exit_only")
        self.assertEqual(self.store.update(self.case,self.run,weak,self.obs,now_s=self.now),"FROZEN_UNVERIFIABLE")

    def test_updated_version_requires_new_observation(self):
        self.assertEqual(self.store.update(self.case,self.run,self.report,self.obs,now_s=self.now),"SYNTHETIC_UPDATE_ACCEPTED")
        case2=replace(self.case,version=2)
        run2=self.solver.run(case2)
        report2=self.verifier.verify(case2,run2)
        self.assertEqual(self.store.update(case2,run2,report2,self.obs,now_s=self.now),"FROZEN_VERSION_CONFLICT")
        newer=replace(self.obs,measured_at_s=self.now+1)
        self.assertEqual(self.store.update(case2,run2,report2,newer,now_s=self.now+1),"SYNTHETIC_UPDATE_ACCEPTED")

    def test_audit_log_does_not_duplicate_trace_ids(self):
        self.store.log("fixed-trace",self.report)
        import sqlite3
        with self.assertRaises(sqlite3.IntegrityError):
            self.store.log("fixed-trace",self.report)


if __name__=="__main__":
    unittest.main()
