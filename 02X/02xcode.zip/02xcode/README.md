# 02xcode · TwinProof-Gate

**用途**：验证 Agent 发起的科学仿真是否有足够的独立证据，并决定能否更新**合成**数字孪生。
本包是科研 v0 原型；不是已验证的真实数字孪生或工程安全软件。

## 需要安装

- **Python 3.11+**（标准库，无需 pip 安装）
- **Go 1.22+**（用于本地热传导求解器；无需第三方 Go 包）

## 一键使用

| 系统 | 命令或双击 |
|---|---|
| Windows 自检 | `scripts\check_windows.bat` |
| Windows 本地网关 | `scripts\start_windows.bat` |
| Linux/macOS 自检 | `sh scripts/check.sh` |
| Linux/macOS 本地网关 | `sh scripts/start.sh` |
| 运行示例 | `python scripts/cli.py demo` |
| 合成对照实验 | `python scripts/cli.py evaluate --count 48` |

网关仅绑定 `127.0.0.1:8765`。POST `/verify` 发送 JSON，如：

```json
{"case":{"case_id":"heat_demo","n":17,"left_k":300,"right_k":320,"conductivity":5,"amplitude_k":10},"budget":20,"policy":"adaptive"}
```

成功仅表示**本次显式检查通过**；`PASS_UNVERIFIED` 不具备独立物理证据，不能更新孪生。所有温度为 K，网格为单位正方形，导热系数 SI 制。

## 文件去哪看

- `solver/`：Go 二维稳态传热求解器及测试
- `python/twinproof/`：独立检查、验证预算、合成孪生状态与评测
- `scripts/`：启动、实验、自检
- `results/`：合成实验结果
- `docs/DEBUG_INDEX.md`：故障排查及**逐文件修复文档**
- `docs/QUALITY.md`：自检状态与未实现能力

**明确局限**：未接 FEniCSx、COMSOL、弹性 PDE、实时传感器、真实 Agent 或公开强基线；预算是相对计量单位，验证选择是启发式，非经校准的误接受风险上界。
