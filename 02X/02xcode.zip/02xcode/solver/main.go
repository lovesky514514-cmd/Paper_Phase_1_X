package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math"
	"os"
)

// Case is a deliberately small, typed contract for an isolated manufactured-solution test.
// Units are kelvin, metres, and W/(m K); this solver never calls real hardware.
type Case struct {
	CaseID        string  `json:"case_id"`
	Version       int     `json:"version"`
	N             int     `json:"n"`
	LeftK         float64 `json:"left_k"`
	RightK        float64 `json:"right_k"`
	Conductivity  float64 `json:"conductivity"`
	AmplitudeK    float64 `json:"amplitude_k"`
	SourceScale   float64 `json:"source_scale"`
	Fault         string  `json:"fault,omitempty"`
	MaxIterations int     `json:"max_iterations,omitempty"`
}

type Result struct {
	CaseID       string    `json:"case_id"`
	Version      int       `json:"version"`
	N            int       `json:"n"`
	LeftK        float64   `json:"left_k"`
	RightK       float64   `json:"right_k"`
	Conductivity float64   `json:"conductivity"`
	AmplitudeK   float64   `json:"amplitude_k"`
	SourceScale  float64   `json:"source_scale"`
	SolverStatus string    `json:"solver_status"`
	Iterations   int       `json:"iterations"`
	MaxChange    float64   `json:"max_change"`
	TemperatureK []float64 `json:"temperature_k"`
}

func finite(v float64) bool { return !math.IsNaN(v) && !math.IsInf(v, 0) }

func validate(c Case) error {
	if c.CaseID == "" || len(c.CaseID) > 80 || c.Version < 1 || c.N < 5 || c.N > 65 || c.N%2 == 0 {
		return errors.New("case_id/version/grid must be valid; n must be odd in [5, 65]")
	}
	if !finite(c.LeftK) || !finite(c.RightK) || !finite(c.Conductivity) || !finite(c.AmplitudeK) || !finite(c.SourceScale) ||
		c.LeftK < 1 || c.RightK < 1 || c.Conductivity <= 0 || math.Abs(c.AmplitudeK) > 200 || math.Abs(c.SourceScale) > 5 {
		return errors.New("invalid physical parameters")
	}
	if c.MaxIterations < 0 || c.MaxIterations > 250000 {
		return errors.New("invalid max_iterations")
	}
	switch c.Fault {
	case "", "swap_boundaries", "reverse_source", "missing_source", "wrong_conductivity", "fake_converged", "short_iteration", "tamper_center":
	default:
		return errors.New("unknown sandbox-only fault")
	}
	return nil
}

// solve discretizes -k ΔT=q on [0,1]^2 with Dirichlet boundary temperatures.
// The manufactured exact solution is a linear x-profile plus A sin(pi x)sin(pi y).
func solve(c Case) (Result, error) {
	if err := validate(c); err != nil {
		return Result{}, err
	}
	left, right, k, scale := c.LeftK, c.RightK, c.Conductivity, c.SourceScale
	switch c.Fault {
	case "swap_boundaries":
		left, right = right, left
	case "reverse_source":
		scale = -scale
	case "missing_source":
		scale = 0
	case "wrong_conductivity":
		k *= 1.5
	}
	n := c.N
	grid := make([]float64, n*n)
	h := 1.0 / float64(n-1)
	for y := 0; y < n; y++ {
		for x := 0; x < n; x++ {
			grid[y*n+x] = left + (right-left)*float64(x)*h
		}
	}
	limit := c.MaxIterations
	if limit == 0 {
		limit = 18000
	}
	if c.Fault == "short_iteration" || c.Fault == "fake_converged" {
		limit = 1
	}
	change := math.Inf(1)
	count := 0
	// SOR in-place; bounded work and convergence measured on solution updates.
	for it := 0; it < limit; it++ {
		change = 0
		for y := 1; y < n-1; y++ {
			yy := float64(y) * h
			for x := 1; x < n-1; x++ {
				xx := float64(x) * h
				q := 2 * math.Pi * math.Pi * c.Conductivity * c.AmplitudeK * scale * math.Sin(math.Pi*xx) * math.Sin(math.Pi*yy)
				idx := y*n + x
				candidate := (grid[idx-1] + grid[idx+1] + grid[idx-n] + grid[idx+n] + h*h*q/k) / 4
				delta := 1.55 * (candidate - grid[idx])
				grid[idx] += delta
				if math.Abs(delta) > change {
					change = math.Abs(delta)
				}
			}
		}
		count = it + 1
		if change < 1e-10 {
			break
		}
	}
	status := "not_converged"
	if change < 1e-10 {
		status = "converged"
	}
	if c.Fault == "fake_converged" {
		status = "converged"
	} // Maliciously optimistic status for verifier tests.
	if c.Fault == "tamper_center" {
		grid[(n/2)*n+n/2] += 50
	}
	return Result{CaseID: c.CaseID, Version: c.Version, N: n, LeftK: left, RightK: right,
		Conductivity: k, AmplitudeK: c.AmplitudeK, SourceScale: scale, SolverStatus: status,
		Iterations: count, MaxChange: change, TemperatureK: grid}, nil
}

func main() {
	dec := json.NewDecoder(os.Stdin)
	dec.DisallowUnknownFields()
	var c Case
	if err := dec.Decode(&c); err != nil {
		fmt.Fprintln(os.Stderr, "invalid input:", err)
		os.Exit(2)
	}
	var extra any
	if err := dec.Decode(&extra); err != io.EOF {
		fmt.Fprintln(os.Stderr, "trailing data after input JSON")
		os.Exit(2)
	}
	result, err := solve(c)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(2)
	}
	if err := json.NewEncoder(os.Stdout).Encode(result); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(3)
	}
}
