package main

import (
	"math"
	"testing"
)

func base() Case {
	return Case{CaseID: "test", Version: 1, N: 17, LeftK: 300, RightK: 320, Conductivity: 5, AmplitudeK: 10, SourceScale: 1}
}

func TestManufacturedHeatSolution(t *testing.T) {
	r, err := solve(base())
	if err != nil {
		t.Fatal(err)
	}
	if r.SolverStatus != "converged" {
		t.Fatal(r.SolverStatus)
	}
	center := r.TemperatureK[8*17+8]
	if math.Abs(center-320) > 0.06 {
		t.Fatalf("center %.6f outside finite-difference tolerance", center)
	}
}

func TestReadbackReflectsFault(t *testing.T) {
	c := base()
	c.Fault = "swap_boundaries"
	r, err := solve(c)
	if err != nil {
		t.Fatal(err)
	}
	if r.LeftK != 320 || r.RightK != 300 {
		t.Fatal("readback hid boundary change")
	}
}

func TestBadInputs(t *testing.T) {
	for _, bad := range []Case{{CaseID: "", Version: 1, N: 17, Conductivity: 1},
		{CaseID: "x", Version: 1, N: 16, Conductivity: 1, LeftK: 300, RightK: 300},
		{CaseID: "x", Version: 1, N: 17, Conductivity: -1, LeftK: 300, RightK: 300},
	} {
		if _, err := solve(bad); err == nil {
			t.Fatalf("accepted %+v", bad)
		}
	}
}

func TestFakeConvergenceDiffersFromActual(t *testing.T) {
	c := base()
	c.Fault = "fake_converged"
	r, err := solve(c)
	if err != nil {
		t.Fatal(err)
	}
	if r.SolverStatus != "converged" || r.MaxChange < 0.01 {
		t.Fatal("test injection not active")
	}
}
