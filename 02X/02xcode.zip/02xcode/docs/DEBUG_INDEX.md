# 故障排查速查

1. **Go not found**：安装 Go 1.22+；终端执行 `go version`。Windows 安装后重开终端。
2. **Python not found**：安装 Python 3.11+；终端执行 `python --version`，Windows 可用 `py -3`。
3. **启动失败或编译出错**：在项目根目录运行 `go test ./...`；关闭可能残留的 Go/Python 进程再试。
4. **POST /verify 失败**：只接受 `application/json`；仅支持白名单参数和 K 单位；查看返回的 400 错误。
5. **HUMAN_ESCALATION**：预算不足，不能当作程序故障；将单任务预算调高，或降低验证任务复杂度。
6. **FROZEN_DRIFT / FROZEN_STALE_OBSERVATION**：校准偏差或时间戳不符合合成观测契约；不要强行更新。
7. **REJECT_WITH_CAUSE**：物理证据真的未过检查；检查源项/边界/网格，不能直接绕过。
8. **Unicode/中文乱码**：Windows 终端设置 UTF-8，启动脚本已设置 `PYTHONUTF8=1`。

每个程序和关键配置文件的独立排错页位于 `docs/files/`，包括“用途、常见错误、检查命令、修复方法”。
