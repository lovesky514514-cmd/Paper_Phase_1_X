# tests/test_evaluation.py

**用途**：`tests/test_evaluation.py` 的独立检查与修复备忘。

**常见错误**：Python 模块导入失败、解析出错或数据类型错误。

**检查命令**：`python -m unittest discover -s tests -v`

**修复建议**：从项目根目录运行 Python 3.11+；核对模块公开接口及单元测试；禁止跳过安全拒绝。

**复测**：`python scripts/check.py`，如为交付包另执行 `python scripts/verify_package.py`。保存最小复现案例，不篡改风险标签或删除失败断言。
