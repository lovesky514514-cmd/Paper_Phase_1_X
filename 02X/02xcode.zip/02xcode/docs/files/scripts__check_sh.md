# scripts/check.sh

**用途**：`scripts/check.sh` 的独立检查与修复备忘。

**常见错误**：文件无可执行权限或 cwd 错误。

**检查命令**：`sh scripts/check.sh`

**修复建议**：用 sh 调用，确认 PATH 中的 python3、go，执行 chmod +x scripts/*.sh。

**复测**：`python scripts/check.py`，如为交付包另执行 `python scripts/verify_package.py`。保存最小复现案例，不篡改风险标签或删除失败断言。
