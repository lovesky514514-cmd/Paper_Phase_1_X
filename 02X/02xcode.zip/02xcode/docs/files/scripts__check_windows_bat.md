# scripts/check_windows.bat

**用途**：`scripts/check_windows.bat` 的独立检查与修复备忘。

**常见错误**：找不到 Go/Python、脚本闪退。

**检查命令**：`双击 scripts\check_windows.bat`

**修复建议**：打开 cmd 执行脚本，检查 PATH 和版本；已跳过 Windows 上对 C 编译器有要求的 race 检测。

**复测**：`python scripts/check.py`，如为交付包另执行 `python scripts/verify_package.py`。保存最小复现案例，不篡改风险标签或删除失败断言。
