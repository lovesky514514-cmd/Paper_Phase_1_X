# results/pilot.json

**用途**：`results/pilot.json` 的独立检查与修复备忘。

**常见错误**：配置/实验结果损坏、随机种子与标签不一致。

**检查命令**：`python -m json.tool <具体文件>`

**修复建议**：使用命令行实验重新生成合成结果；只比较真值/决策不比较 CPU 计时。

**复测**：`python scripts/check.py`，如为交付包另执行 `python scripts/verify_package.py`。保存最小复现案例，不篡改风险标签或删除失败断言。
