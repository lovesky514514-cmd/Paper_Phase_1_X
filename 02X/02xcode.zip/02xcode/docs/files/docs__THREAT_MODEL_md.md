# docs/THREAT_MODEL.md

**用途**：`docs/THREAT_MODEL.md` 的独立检查与修复备忘。

**常见错误**：文档/原始研究方案/配置文件丢失或不匹配。

**检查命令**：`python scripts/check.py`

**修复建议**：核对 README 和源码；重新解压 ZIP；文档不得夸大为真实设备保证。

**复测**：`python scripts/check.py`，如为交付包另执行 `python scripts/verify_package.py`。保存最小复现案例，不篡改风险标签或删除失败断言。
