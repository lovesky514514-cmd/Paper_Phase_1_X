# solver/main.go

**用途**：`solver/main.go` 的独立检查与修复备忘。

**常见错误**：编译失败或热传导方程数值计算异常。

**检查命令**：`go test -race ./... (Linux); go test ./... (Windows)`

**修复建议**：核对物理参数与离散式，重新运行 Go 单元测试、解析解和竞态检测。

**复测**：`python scripts/check.py`，如为交付包另执行 `python scripts/verify_package.py`。保存最小复现案例，不篡改风险标签或删除失败断言。
