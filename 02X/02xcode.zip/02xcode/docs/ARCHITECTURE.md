# 架构与物理定义

```text
Agent (声明 Case) → 本地 HTTP /verify
   → Go 稳态传热求解器 → 执行配置 Readback + 温度场
   → Python 物理证据：参数 / 边界 / PDE 残差 / MMS / 三网格
   → PASS / REJECT / ABSTAIN / HUMAN
   → 合成观测门控 → SQLite 版本化状态与审计
```

求解域为单位正方形，`-k ΔT = q`，四边使用 Dirichlet 边界。
制造解：`T(x,y)=T_left+(T_right-T_left)x+A sin(πx)sin(πy)`，源项 `q=2kπ²A sin(πx)sin(πy)`；Go 使用五点差分和 SOR，Python 独立重算离散残差与解析真值。

三种检查层：低成本（参数读回、求解器状态、边界）、物理层（离散残差、MMS）、高成本层（三次真实网格求解）。验证预算默认 20 抽象单位，不充当统计置信保证。

**信任假设**：Go 沙箱及其读回没有被攻击者控制；无法对不可信操作系统、真实传感器或独立有限元引擎提供形式正确性保证。真实物理场、传感器单位与状态误差都需要额外建模。
