@echo off
setlocal
cd /d "%~dp0.."
set PYTHONUTF8=1
set GOPROXY=off
set GOSUMDB=off
where py >nul 2>nul
if %errorlevel%==0 (py -3 scripts\cli.py serve) else (python scripts\cli.py serve)
if errorlevel 1 echo See docs\DEBUG_INDEX.md
pause
