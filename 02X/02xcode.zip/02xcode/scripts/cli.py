"""Unified CLI for check, demo, synthetic evaluation, and loopback gateway."""

import argparse
from dataclasses import asdict
import json
import tempfile
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python"))

from twinproof.model import Case
from twinproof.evidence import Verifier
from twinproof.evaluation import experiment
from twinproof.solver import LocalSolver
from twinproof.server import serve
from twinproof.twin import Observation, TwinStore


def main():
    cli = argparse.ArgumentParser(description="TwinProof-Gate synthetic science verification")
    cli.add_argument("command",choices=["demo", "evaluate", "serve"])
    cli.add_argument("--count",type=int,default=48)
    cli.add_argument("--seed",type=int,default=19)
    cli.add_argument("--budget",type=int,default=20)
    cli.add_argument("--port",type=int,default=8765)
    cli.add_argument("--output",type=Path)
    args = cli.parse_args()
    with LocalSolver() as solver:
        if args.command == "serve":
            serve(solver, ROOT / "runtime" / "twinproof.sqlite", args.port)
        elif args.command == "evaluate":
            if args.count < 1 or args.count > 2000:
                cli.error("--count must be 1..2000")
            output = experiment(solver,seed=args.seed,count=args.count,budget=args.budget)
            dest = args.output or (ROOT / "results" / "pilot.json")
            dest.parent.mkdir(parents=True,exist_ok=True)
            dest.write_text(json.dumps(output,ensure_ascii=False,indent=2),encoding="utf-8")
            print(json.dumps(output["summary"],ensure_ascii=False,indent=2))
            print(f"Detailed records: {dest}")
        else:
            case = Case("demo_heat",amplitude_k=22)
            good = solver.run(case)
            report = Verifier(solver).verify(case,good,budget=args.budget)
            print(f"Normal run: {report.decision}, checks={len(report.checks)}, units={report.used_units}")
            bad = solver.run(case,"fake_converged")
            unsafe = Verifier(solver).verify(case,bad,budget=args.budget)
            print(f"False convergence: {unsafe.decision}, reasons={unsafe.reasons}")
            # Demo must not depend on a previous invocation's state version.
            with tempfile.TemporaryDirectory(prefix="twinproof-demo-") as tmp:
                db=TwinStore(Path(tmp)/"twin.sqlite")
                sensor=Observation("center",good["temperature_k"][8*17+8]+0.05,int(time.time()))
                print("Synthetic observation:",db.update(case,good,report,sensor))


if __name__ == "__main__":
    main()
