@echo off
setlocal
cd /d "%~dp0.."
set PYTHONUTF8=1
set GOPROXY=off
set GOSUMDB=off
where py >nul 2>nul
if %errorlevel%==0 (py -3 scripts\check.py) else (python scripts\check.py)
set ERR=%errorlevel%
echo.
if not "%ERR%"=="0" echo Check failed. See docs\DEBUG_INDEX.md
pause
exit /b %ERR%
