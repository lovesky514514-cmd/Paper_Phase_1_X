#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
export GOPROXY=off GOSUMDB=off
python3 scripts/check.py
