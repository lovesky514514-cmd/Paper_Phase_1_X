"""Verify every packaged file hash; absent manifest is allowed before packaging."""

import hashlib
import json
from pathlib import Path

root=Path(__file__).resolve().parents[1]
manifest=root/"PACKAGE_SHA256.json"
if not manifest.exists():
    print("Package manifest not yet created (development directory)")
else:
    hashes=json.loads(manifest.read_text(encoding="utf-8"))
    for name,digest in hashes.items():
        target=(root/name).resolve()
        if not target.is_relative_to(root.resolve()) or not target.is_file():
            raise SystemExit(f"Missing/unsafe package file: {name}")
        if hashlib.sha256(target.read_bytes()).hexdigest()!=digest:
            raise SystemExit(f"Package checksum mismatch: {name}")
    print(f"Package SHA256 verified: {len(hashes)} files")
