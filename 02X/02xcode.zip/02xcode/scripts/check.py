"""Offline project checks using only standard toolchains."""

from pathlib import Path
import os
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
commands = [
    ["go","test","./..."],
    ["go","vet","./..."],
    [sys.executable,"-m","unittest","discover","-s","tests","-v"],
    [sys.executable,"scripts/cli.py","demo"],
    [sys.executable,"scripts/verify_package.py"],
]
# Go's race detector may require a C toolchain on Windows; keep self-check one-click.
if sys.platform != "win32":
    commands.insert(2, ["go", "test", "-race", "./..."])
else:
    print("SKIP: Go -race on Windows (requires additional C compiler)", flush=True)
for cmd in commands:
    print("CHECK:"," ".join(cmd),flush=True)
    out=subprocess.run(cmd,cwd=root,env={**os.environ,"GOPROXY":"off","GOSUMDB":"off"})
    if out.returncode:
        raise SystemExit(out.returncode)
print("All checks passed.")
