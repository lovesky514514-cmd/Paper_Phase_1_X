# 交叉学科 SCI 研究报告 02｜Agent × 科学计算 × 数字孪生

> 研究候选名称：**TwinProof-Gate — Evidence-Calibrated Runtime Assurance for Agent-Driven Scientific Digital Twins**  
> 中文拟题：**面向智能体驱动科学数字孪生的证据校准与运行时可信验证网关**  
> 文献及期刊信息检索日期：**2026-10-20**  
> 状态：**研究立项与方案设计；未开展本文提出的实验；没有已经验证的算法性能或录用保证。**  
> 适用团队：Agent/后端网关开发者 + 科学计算/数值分析协作者（最好再有一名工程领域专家）。

---

## 0. 一页结论

**主观点：能够成功启动仿真、求解器收敛、生成漂亮的结果图，都不能独立证明物理结果可信。** 一个可用于科学决策的 Agent 不仅要“能操作仿真器”，还要由**与 Agent 输出相互独立的验证机制**检查：模型是否真正按预期配置、离散误差和物理误差是否在允许范围、与观测是否一致、数字孪生是否失配，以及何时必须弃权或请求人工复核。

**建议主创新，不是“LLM 自动调用 COMSOL/FEniCS”**，而是：

1. **独立证据契约（Evidence Contract）**：执行后的读取与物理检查不依赖 Agent 自述；把“执行成功”和“物理可信”区分成不同结果标签。
2. **误差-不确定性预算驱动的动态验证**：按风险决定采用廉价量纲/守恒检查、网格收敛、独立求解器对照或观测校准；重型验证有成本上限。
3. **可信的孪生更新门控（Twin Update Gate）**：只有满足观测时序、校准残差和适用域检查，才允许把新仿真结果用于下一轮孪生状态或工程决策；无法验证则弃权/升级。

**高水平投稿的真实门槛**：上述任何一项单独都不保证创新。必须给出清楚的数学定义、可复现算法、独立参考结果，以及在 *正确放行率/错误放行率/端到端成本* 上超过现有系统的严格对照。没有实时观测反馈的方案应称 **simulation automation / digital model**，不应宣称已完成真实数字孪生。

**优先推进顺序**：

- **A：两周可验证的 MVP**：二维稳态/瞬态热传导 + 线弹性（FEniCSx，解析解/高精网格参考解）+ 规则基线和成本控制；不需要 GPU 训练。
- **B：论文主实验**：跨 PDE、错边界、错单位、错选择、网格病态、求解器假收敛、参数漂移、观测延迟；比较验证质量与资源消耗。
- **C：真正的孪生实证**：有传感器数据的热系统或机械系统，时间同步校准；没有真实数据时明确标注 **synthetic digital-twin testbed**。

---

## 1. 领域定位与科学问题

### 1.1 三个不同层次不能混淆

| 层次 | 系统做了什么 | 可以声称 | 不能声称 |
|---|---|---|---|
| 自动化仿真 | 生成脚本、调用求解器、产出结果 | 仿真任务自动化 | 仿真物理正确；构成真实孪生 |
| 可验证科学仿真 | 独立读取模型并检查守恒、数值和参考解 | 在指定检查与假设范围内获得可信证据 | 对所有未知物理过程形式化正确 |
| 数字孪生 | 物理实体与数值模型持续接收、同步、更新数据（视定义包含反馈/控制） | 对观测域内给出经校准的状态估计和更新 | 无传感器就自称在线孪生；用一次校准证明永远可靠 |

基础分层参考 Kritzinger et al., 2018（Digital Model / Digital Shadow / Digital Twin）及 Tao et al., 2019。把离线仿真称作 DT 会成为审稿人明确的拒稿风险。

### 1.2 研究问题（可证伪）

- **RQ1：可信性**。独立读回+物理约束是否能比“求解器正常退出、LLM 自检、简单规则”显著降低**错误放行率**？
- **RQ2：效率**。在相同误放行上限/人工作业量下，风险自适应验证是否显著降低总验证成本（wall-time / solver calls / $）？
- **RQ3：数字孪生漂移**。当热交换系数、材料常数、测量噪声和边界条件变化时，动态校准+弃权是否降低错误更新及过度自信？
- **RQ4：跨仿真器泛化**。FEniCSx 与其他独立引擎（有条件时 COMSOL/OpenFOAM）使用共享证据契约时，哪些物理检查可以迁移，哪些必须专用实现？

### 1.3 最小假设与失败条件

- 数学模型与单位系统已声明；至少有一部分任务具有解析解、制造解（MMS）或可信高精度参考解。
- 网关能够通过受限接口读取实际求解器模型/导出结果；仅解析 Agent 文本不算“独立证据”。
- 给出的风险约束只针对预先定义的危险事件分布与检测覆盖范围；分布漂移或观测缺失时必须退化为不保证/弃权。
- 不把 PDE 残差小简单等同于工程真实误差小；离散误差、模型偏差、观测误差需分别处理。

---

## 2. 2025–2026 直接竞争文献：哪些创新已经存在

| 工作 | 已经做了什么 | 本文不能再当首创的内容 | 需要突出差异 |
|---|---|---|---|
| **MCP-SIM**（npj Artificial Intelligence, 2026） | 多 Agent 自然语言构建物理仿真、错误诊断、修正、说明；12 个展示任务 | 多 Agent + 有限元 + 自纠错 | **独立物理证据**而非仅完成求解；评价假成功与错误放行 |
| **ALL-FEM**（CMAME, 2026） | FEniCS 仿真代码生成、微调及自动检查；39 项测试 | 自动生成、调试有限元、运行反馈 | 模型读回、跨求解器证据、成本-风险选择、孪生校准 |
| **GENIUS**（Communications Materials, 2026） | Quantum ESPRESSO 脚本自动设计与有限状态错误恢复；295 个任务 | 结构化 Agent 仿真协议、自动恢复 | *物理质量与可信度*，不只输入文件/执行通过 |
| **SimBench**（IEEE Access, 2026） | 多物理数字孪生生成评估，Chrono 仿真环境 | 有多轮生成质量评估 | 可信的物理证据包、校准、置信与弃权，针对假成功 |
| **Building digital twins**（JII, 2025） | Agent 辅助模型开发、诊断、校准 | Agent + 建筑 DT 校准 | 误差预算门控、独立证据、跨任务风险评估 |
| **AROMA-GPT**（Progress in Nuclear Energy, 2026） | 核反应堆模拟孪生 + 物理工具 + 人类监督 | Agent 连接模拟器、物理建议、远程监控 | 一般化风险校准和异常场景下安全拒绝，而不是替代控制器 |
| **Hydro-Agent**（Water Research, 2026） | 物理引擎支持的地下水逆问题、多 Agent 编码和校验 | 物理模型一致性与仿真-反馈闭环 | 通用验证契约及其统计可靠性、资源预算比较 |
| **Agentic Digital Twins**（Array, 2026） | DT 与 Agent 分层架构、实时反馈 | 把 Agent 与 DT 连接成一个框架 | 证明哪些结果可信与何时不能更新，定量超越架构方案 |
| **WorldSolver**（arXiv 2026，预印本） | 168 项、7 物理域的求解器生成评估，覆盖执行、视觉和物理合理性 | 评价生成物理求解器 | 数值解可信性门控/在线风险管理/孪生更新 |

**论文定位声明**：已有研究覆盖的内容相当多，绝不能在摘要里写“first agentic scientific simulation”或“first simulation verification gateway”。最有潜力的论文是 **Verification-Aware / Uncertainty-Budgeted / Abstention-Capable Scientific Twin Orchestration**，但其原创性仍须由与这些论文的逐项实验验证。

---

## 3. 主创新：TwinProof-Gate

### 3.1 架构（建议）

```text
用户科学问题 + 应用域约束 + 观测数据（如有）
    │
    ▼
任务结构化器（Agent） ──► ScientificPlan（声明目标，不视为证据）
    │
    ▼
网关：模式选择 / API 约束 / 单位与物理类型检查
    │
    ├─ FEniCSx / OpenFOAM / COMSOL（有许可时）
    ▼
求解器真实状态 Readback + 数值结果 + 配置清单
    │
    ▼
独立 Evidence Engine
    ├─ 层 I：字段、版本、选择域、量纲、边界条件
    ├─ 层 II：物理残差、守恒、对称性、材料合法区间
    ├─ 层 III：网格/时间步收敛、参考解/独立求解器
    └─ 层 IV：真实/合成传感器校准、漂移与不确定性
    │
    ▼
风险-成本选择器（验证是否升级/终止）
    │
    ├─ PASS_WITH_EVIDENCE（限定条件内可放行）
    ├─ RETRY_WITH_PLAN（可安全修复，并保留证据）
    ├─ ABSTAIN_UNVERIFIABLE（证据不足，不得宣称正确）
    └─ HUMAN_ESCALATION（高影响/高风险任务）
    │
    ▼
Twin Update Gate：检查时间戳/观测校准/漂移/约束
    │
    ▼
下游数字孪生状态更新或只读建议（视授权）
```

**不可偷换的概念**：`PASS_WITH_EVIDENCE` 表示某组预定义规则和参考证据通过，不意味着客观物理真理已形式化证明。`ABSTAIN_UNVERIFIABLE` 不是失败，而是系统明确拒绝过度自信。

### 3.2 主张 A：独立证据契约

每次求解记录最少字段：

```yaml
case_id: heat2d_0041
plan_hash: sha256_of_intended_task
solver:
  name: fenicsx
  version: pinned_exact_version
  code_hash: reproducible_input
readback:
  mesh_statistics: {cells: 3200, h_max: null}
  geometry_id: verified_geometry
  pde_class: heat_diffusion
  material_parameters_with_units: verified
  boundary_regions: [left, right, top, bottom]
  boundary_conditions: verified_by_solver_state
numerics:
  nonlinear_solver_status: converged_or_not
  residual_norm: measured_value_with_definition
  mesh_refinement_study: not_run_or_results
  reference_error: not_available_or_value
physics:
  conservation_balance: measured_with_uncertainty
  units_check: pass_fail_unknown
observations:
  data_source: none_or_provenance
  timestamp_range: none_or_interval
  calibration_status: not_run_or_report
outcome:
  decision: PASS_WITH_EVIDENCE_or_ABSTAIN_or_RETRY_or_ESCALATE
  check_scope: explicit_validity_conditions
  unsupported_claims: explicit_list
```

**审稿人关心的细节**：边界编号可变化，必须依据几何/标签语义验证，而非硬编码面编号；读取单元与施加单元的单位换算要能够复现；日志中不能仅出现“API 返回创建成功”就当作边界条件在真实求解器里生效。

### 3.3 主张 B：预算约束下的动态验证

定义任务 \(i\) 的候选检查集合 \(V_i\)，检查 \(v\) 的运行时间/费用 \(c(v)\)，检查失败风险估计 \(\hat r_i\)，误接受成本 \(L_{FA}\)。目标概念：

\[
\min_{\pi} \; \mathbb E[C_{solve}+C_{verify}+C_{rework}+C_{human}]
\]

在以下**需经验校准**的约束下：

\[
\operatorname{FAR}(\pi) := P(\text{放行}\mid\text{物理不正确})\le\epsilon,\qquad
P(\text{可接受任务完成})\ge q_0.
\]

这不是天然的分布无关保证；若样本不独立同分布、基准覆盖不全，风险上界的解释应明确降级。更实用的算法是逐层检查 + 风险预测 + 成本约束 + 校准阈值，预留人工复核。

**建议算法雏形（待实验验证）**：

```python
for task in workload:
    evidence = execute_and_readback(task)
    for check in cheap_deterministic_checks:
        evidence.add(check(evidence))
    if certain_violation(evidence):
        return REJECT_WITH_CAUSE
    if missing_required_evidence(evidence):
        return ABSTAIN_UNVERIFIABLE
    while risk_upper_bound(evidence) > epsilon:
        candidate = choose_next_check(expected_risk_reduction_per_cost)
        if candidate is None or budget_exceeded():
            return HUMAN_ESCALATION
        evidence.add(run(candidate))
    return PASS_WITH_EVIDENCE
```

“风险上界”必须有正式估计方式（例如独立留出校准或由已证明的物理不等式推导）；在做不到前，只称 `risk_score`，不可谎称认证。

### 3.4 主张 C：可信数字孪生更新

针对热系统观测 \(y_t\)：

\[
y_t = H\bigl(u_t(\theta_t)\bigr) + \eta_t + \delta_t
\]

其中 \(\theta_t\) 为可校准物理参数，\(\eta_t\) 为测量噪声，\(\delta_t\) 为模型偏差（不可简单吞进观测噪声）。

**更新前验收**：观测时间戳和坐标映射、传感器质量、参数可识别性、残差及覆盖率、漂移分数、模型与观测对齐。在不满足条件时冻结孪生校准结果并登记不确定性，不能用最新模型强制覆盖可信旧状态。

**注意**：模型参数不断变化不意味着物理模型自动正确；对结构性偏差（缺失热源、几何错误）强行调参容易得到“拟合很好但物理错误”的假孪生。

---

## 4. 7 个跨学科可做的子课题（由低成本到高上限）

| 主题 | 交叉学科 | 真正的研究对象 | 开源/数据资源 | 难点与可投稿形态 |
|---|---|---|---|---|
| A. 有限元证据验证 | 数值分析×软件可靠性 | 执行结果假阳性率与验证预算 | FEniCSx、PDEBench | **最低成本最优先**，方法论文可行 |
| B. 数字孪生可信校准 | 统计学×控制×热工 | 状态漂移下风险敏感更新 | 合成/真实传感器时序 | 要区分真正物理测量与模拟生成流 |
| C. 多保真物理验证 | 多保真优化×数值 PDE | 何时用粗网格/精网格/独立解 | FEniCSx/OpenFOAM | 要评估误差-成本前沿 |
| D. 工业热管理 | 传热学×IoT | 热参数变化与故障识别 | 热台或公开温度监测 | 有真实工况价值更高 |
| E. 结构可靠性 | 固体力学×失效分析 | 不可靠应力/强度结果自动拒绝 | 线弹性/非线性 benchmark | 必须专业核验材料与载荷 |
| F. 材料/多场耦合 | 材料科学×计算力学 | 错耦合/错参数的危险检测 | 热应力、扩散-反应 | 稳健对照与计算较贵 |
| G. 逆问题与主动实验 | 贝叶斯推断×实验设计 | 低代价验证/挑选下一观测 | 合成数据 + 工程测量 | 需真正的校准和不确定度评价 |

### 对学弟更切合实际的团队分工

- **Agent/网关负责人**：受限工具 API、模型版本与调用凭证、执行状态采集、审计追溯、隔离与回退。
- **科学计算负责人**：PDE/边界/解析解或制造解、网格收敛、物理守恒、误差预算和基准真值。
- **统计/控制协作者（可兼职）**：测量噪声建模、校准集/测试集隔离、风险覆盖与漂移敏感度。
- **外部领域专家**：物理基准审核及复杂失败案例标注；这是投稿较高水平期刊的关键资源。

---

## 5. 数据集、基准与实验任务设计

### 5.1 分阶段任务

| 阶段 | 仿真类型 | 真值/参考 | 建议样本量（规划值，不是已经完成） |
|---|---|---|---|
| T0 | 一维/二维传热、Poisson 方程 | 解析解/MMS | 30–50 个任务模板 |
| T1 | 线弹性、稳态热传导 | 网格收敛 + 独立解析例 | 40–60 个任务模板 |
| T2 | 瞬态扩散、热应力 | 高精基准/已知守恒 | 30–50 个任务模板 |
| T3 | 在线参数扰动的合成孪生 | 已知时变参数 + 延迟观测 | ≥3 种漂移、≥3 个噪声等级 |
| T4 | 跨引擎对照（可选） | FEniCSx vs OpenFOAM/COMSOL | ≥15 个兼容任务 |

样本量是资源估算，不能作为统计功效的保证；实验前根据基线 FAR 和待检测的改善幅度做样本量/置信区间规划，建议每个物理题型至少多个随机种子、不同 BC、多个网格级别。

### 5.2 最关键的故障注入表

1. **边界选错**：边界坐标一致但标签错位，API 成功，温度/位移结果物理不对。
2. **单位错**：`mm` 当 `m`、`MPa` 当 `Pa`、`°C/K` 偏置处理错误。
3. **材料错**：导热系数、弹性模量、泊松比非法或调换。
4. **物理残缺**：漏热源、漏惯性项、源项符号颠倒。
5. **数值假成功**：求解器退出码 0 但残差容限过宽、粗网格导致大误差。
6. **几何拓扑改变**：模型更新后实体 ID 变化，原选择静默失效。
7. **退化网格**：病态网格导致误差/数值振荡。
8. **测量漂移**：传感器零点漂移、异常值、采样延迟、传感器离线。
9. **分布迁移**：超出校准温度/载荷区间，风险校准不再适用。
10. **工具层失败**：超时、部分写入、版本不一致和读回缓存。

每种故障分别记录**根因类型、可观测信号、理论上可检测检查项及检测盲区**，防止模型选择偏差。

### 5.3 模型与 Agent 基线（不可省）

- B0 纯人工模板/专家脚本（可解释上限）。
- B1 单 Agent + 工具调用，只凭执行退出码放行。
- B2 单 Agent + 自我反思/修错（Reflexion 风格）。
- B3 固定顺序物理规则验证，无动态预算。
- B4 固定网格细化/参考解验证（成本高但强基线）。
- B5 随机选择昂贵检查且满足同样预算（排除随机预算效应）。
- B6 风险评分驱动验证，但不使用独立 Readback。
- **Ours**：独立 Readback + 证据契约 + 动态检查 + 弃权 + 更新门控。

**强对比要求**：尽可能复现 MCP-SIM/ALL-FEM/GENIUS 的可公开模块；若代码或计算资源不允许，必须诚实说“仅概念相关，不是实测对比”，不能用自己简化的弱实现冒充原系统。

### 5.4 数值分析不能偷工减料

- 热传导：对边界通量积分和体源积分做离散守恒检验，说明数值积分误差。
- 热弹性：应力/位移边界满足性与平衡方程残差分别评估。
- 网格：至少 3 个分辨率，评估关键量收敛，不能只比较截图相似度。
- 误差：明确解误差、离散误差、模型形式误差、测量误差；使用多指标，不用一项残差代表所有正确性。
- 制造解：在给定精确解时逆推源项/边界，既验证代码也验证检查器。

---

## 6. 评测指标、统计方法与消融

### 6.1 主要指标（需同时报告）

| 指标 | 计算/含义 | 易犯错误 |
|---|---|---|
| **False Acceptance Rate (FAR)** | 真值错误案例中被放行的比例；给置信区间 | “拒绝全部”也能得到零 FAR，需同时报告完成率 |
| Valid Task Completion Rate | 真正满足物理误差要求的任务完成率 | 把退出码成功算成功 |
| Unnecessary Rejection | 物理正确却被拒绝/弃权的比例 | 不区分拒绝和合理升级 |
| Coverage / Abstention | 放行覆盖率、弃权率 | 忽略人审成本 |
| Calibration ECE / Brier | 风险预测可信度 | 仅在独立测试集报告，不能反复调参 |
| End-to-end cost | LLM token + 求解时间 + 验证次数 + 人审成本 | 只统计 LLM 费用 |
| Tail latency | P95 / P99 | 只报告均值 |
| Twin update error | 更新后状态相对观测/真值误差 | 合成流不等于真实传感器 |
| Drift robustness | 不同漂移强度下的 FAR、覆盖率 | 在漂移数据上再校准后冒充零样本泛化 |
| Evidence audit completeness | 每项关键验证是否有独立可重跑证据 | 使用 LLM“认为已验证”作为证据 |

### 6.2 消融实验（建议 >=6 项）

1. 移除独立读取，仅保留 Agent 自报。
2. 移除量纲和边界语义检查。
3. 移除守恒与解析/MMS 检查。
4. 固定检查序列替代动态预算。
5. 移除弃权，强制二元 PASS/FAIL。
6. 移除校准与漂移门控，强制更新孪生。
7. 移除跨求解器对照（如可用）。
8. 训练/校准数据与测试数据的时间切分交换，观察泄漏敏感度。

### 6.3 必须报告的不确定性

- 对 FAR/完成率至少报告 95% Wilson 或合适的二项置信区间，并分故障类型统计。
- 对成本/延迟报告 bootstrap 区间和硬件、环境、求解器版本。
- 任务按问题族/几何/参数范围隔离；类似边界条件变体不能全部混入训练和测试。
- 若涉及 conformal risk 或覆盖：明确**交换性假设**，报告分布变化下失效条件；不可宣称普适可靠性保证。

---

## 7. 软件与复现实验架构（轻量版）

```text
TwinProof-Gate/
├── README.md
├── pyproject.toml
├── configs/
│   ├── contracts/                 # 明示证据阈值与单位
│   └── scenarios/                 # 任务清单 + 故障注入参数
├── gateway/
│   ├── api.py                     # 有限白名单的执行接口
│   ├── router.py                  # 选择验证层级
│   ├── outcome.py                 # PASS/RETRY/ABSTAIN/ESCALATE
│   └── audit.py                   # trace_id + hash + provenance
├── adapters/
│   ├── fenicsx.py                 # 主平台（开源）
│   ├── openfoam.py                # 可选
│   └── comsol.py                  # 有许可证再启用
├── evidence/
│   ├── schema.py
│   ├── model_readback.py
│   ├── units.py
│   ├── pde_residuals.py
│   ├── convergence.py
│   └── reference_checks.py
├── twinstream/
│   ├── synthetic_sensors.py
│   ├── calibration.py
│   └── drift_gate.py
├── baselines/
├── evaluation/
│   ├── faults.py
│   ├── metrics.py
│   └── statistics.py
├── tests/
│   ├── unit/
│   ├── integration/
│   └── physics_gold/
└── artifacts/
    ├── manifests/
    ├── results/                   # 输出不含 API Keys
    └── reports/
```

技术选型：Python 用于仿真驱动与实验；网关高并发部分确有瓶颈再用 Go/Rust。避免过早引入微服务、分布式消息队列和大模型微调。初始版只运行安全的本地算例，限制外部命令、文件路径、资源时间和访问权限。

---

## 8. 投稿路线：**优先无 APC 的订阅发表，不把“初审快”当“录用快”**

> **重要核查说明**：当前能够直接确认的是 Elsevier 官方的混合期刊订阅发表政策（一般不收 APC）与部分期刊的首判数据。若下面的“投稿到录用”时长来自检索到的第三方索引或出版商历史指标转述，一律按**约数、非实时、非承诺**看待。不同快照存在显著差异，投稿前需打开该期刊 ScienceDirect `Journal insights` 与 `Guide for authors` 复查。不要依据最短单一统计做时间承诺。

| 期刊 | 课题契合度 | 投稿→录用（公开历史/第三方转录） | 免费选项 | 适合什么成果 |
|---|---|---|---|---|
| **Advanced Engineering Informatics (AEI)** | **强** | **约 125–171 天**；来源/快照不一致 | 一般可选订阅发表，无 APC | 科学工作流、知识/证据表示、工程决策和数字孪生验证 |
| **Expert Systems with Applications (ESWA)** | 强（偏 AI 算法） | **约 147 天**；历史指标转录 | 一般可选订阅发表，无 APC | 风险预测/动态验证算法有强对照及真实工程应用 |
| **Simulation Modelling Practice and Theory (SMPT)** | 强（偏仿真） | **约 135 天**；第三方转录，需核实 | 先核实当年订阅可用性和附加收费 | 通用验证网关、仿真实验、复杂系统建模 |
| **Applied Mathematical Modelling (AMM)** | 中高 | **约 176 天**；第三方缓存，口径需核实 | 一般可选订阅发表，无 APC | 明确数学误差界/数值建模方法，不是普通 Agent 平台 |
| **Engineering Applications of Artificial Intelligence (EAAI)** | **强** | **约 207 天**；历史转录 | 一般可选订阅发表，无 APC | 带领域实证的 AI 验证/决策方法 |
| **Computer Methods in Applied Mechanics and Engineering (CMAME)** | **高上限但门槛高** | **约 98–121 天**；不同转录冲突，谨慎对待 | 官方 Journal Finder 显示订阅无 publication charge | 对计算力学方法、数值分析或验证理论有明确本质创新 |
| **Computers & Chemical Engineering (C&CE)** | 取决于化工案例 | **约 170 天**；第三方快照，需核实 | 一般可选订阅发表，无 APC | 有物理/化工过程模型验证和实时校准 |
| **Applied Soft Computing (ASC)** | 中（偏算法） | **约 281 天**；某索引快照 | 一般可选订阅发表，无 APC | 优化算法足够强而不是重系统实现 |

**首选顺序**：

1. **AEI**：如果贡献是“科学仿真 Agent 的工程信息与证据验证机制”，最贴切。
2. **ESWA / EAAI**：如果真正的新方法是风险估计/自适应验证算法，且有多领域外部验证。
3. **SMPT**：如果论文主体是跨模型/跨求解器仿真可靠性、故障注入和理论模型。
4. **CMAME**：只有出现实质性数值/力学理论突破或强数值分析结果才值得冲，不能因为表面上录用快就误投。
5. **AMM / C&CE**：需要偏数学/化工实证而非泛用 Agent。

**投稿费用**：Elsevier 官方明确：**混合出版期刊选择 subscription 一般不收文章发表费（APC）**；不等于一定没有彩图/额外服务费，也不意味着在开放获取资助要求下可以随意选择 subscription。**全开放获取（fully OA）期刊即便速度快，也不满足“默认免费”的筛选条件**，除非确认机构协议/赞助免 APC。

**分区 / SCI 注意事项**：本表不把未核实的“中科院一区、JCR Q1”等视为已确认。正式投递用 [Clarivate Master Journal List](https://mjl.clarivate.com/) 验证 **SCIE 当前状态**，再核对当年中科院分区、JCR 分类、机构认可政策；不同分类体系不可混称。

**主要出版政策来源**：

- Elsevier 官方订阅模式与 APC：[https://www.elsevier.com/about/policies-and-standards/pricing](https://www.elsevier.com/about/policies-and-standards/pricing)
- Elsevier 官方选刊和混合模式：[https://www.elsevier.com/publishing/publish-in-a-journal/journal-selection](https://www.elsevier.com/publishing/publish-in-a-journal/journal-selection)
- Elsevier 官方 Journal Finder（部分题录、首判时间和订阅费显示）：[https://journalfinder.elsevier.com/](https://journalfinder.elsevier.com/)
- 期刊历史数据转录示例（仅作筛选，勿视为保证）：[AEI](https://knoweave.com/a/advanced-engineering-informatics)、[ESWA](https://journalcompass.com/journals/expert-systems-with-applications-09574174.html)、[EAAI](https://journalcompass.com/journals/engineering-applications-of-artificial-intelligence-09521976.html)、[SMPT](https://sciscribe.dev/latex-template/journal/simulation-modelling-practice-and-theory-journal/)。

### 审稿周期概念澄清

- `Submission → first decision`：包括几天内的编辑初筛/拒稿，**不能理解为进入外审的时间**。
- `Submission → decision after review`：外审后一个决定（可能为修改/拒稿），不等于录用。
- `Submission → acceptance`：仅已录用样本的历史统计，通常包含作者修改往返，拒稿记录不在内。
- `Acceptance → online publication`：录用后出版阶段；即使很短，也不等于审稿周期短。

---

## 9. 12 周执行计划、两条预算路线及止损点

| 周 | 任务 | 必须产出/验收 |
|---|---|---|
| W1 | 整理 8 篇直竞论文，界定验证范围；固定求解环境 | 问题陈述、真值定义、环境 hash |
| W2 | 热传导/Poisson 最小黄金算例与边界/单位注错 | ≥20 个可复现 case（目标值） |
| W3 | readback + 证据格式 + 固定检查基线 | 错单位/错 BC 可重复检出 |
| W4 | 独立守恒、MMS、网格收敛 | 数值收敛报告、异常检测清单 |
| W5 | 故障注入集 T1/T2 | 成功/失败标签双人审核样本 |
| W6 | 网关动态验证策略 | 与固定规则和成本匹配基线对照 |
| W7 | 误接受代价/弃权策略 | 风险-覆盖-成本曲线 |
| W8 | 合成孪生+参数校准 | 明确标注 synthetic，记录真值漂移 |
| W9 | 漂移、观测缺失、错配校验 | 泛化失效边界及弃权报告 |
| W10 | 可选跨求解器/复杂热弹性 | 转移实验或明确条件不足 |
| W11 | 统计分析与消融、代码/数据封存 | 检查可复现、CI、置信区间 |
| W12 | 写作与导师物理审核、定刊 | 论文初稿和最小可复现包 |

**基本预算路线**（低成本）：CPU 桌面、FEniCSx + Python、可选小额度 LLM API，主要花费为计算时间和 API Token。**增强路线**：COMSOL 许可证、真实传感器和跨引擎、高精 FEM/CFD 耗时。无需从第一天购买 GPU 或多 GPU 服务。

**立项三道门**：

1. **G1（W3）**：不能证明独立检查可检测基本错边界/错单位，则暂缓“可信性”论文主张。
2. **G2（W7）**：错误放行与成本不能同时超过固定规则/固定高强度验证，则调整为 benchmark 论文或报告负结果。
3. **G3（W10）**：没有可信外部物理数据/对照时，不把研究包装成真实在线 DT，并降低目标期刊档次。

---

## 10. 论文结构建议（SCI Original Research）

1. Introduction：自动执行成功 ≠ 物理可信 + 真实 DT 缺少持续可信验证。
2. Related Work：MCP-SIM、ALL-FEM、GENIUS、SimBench、Digital Twins、V&V、UQ。
3. Problem Definition：任务/模型/观测/验证预算/错误放行定义，明确非保证范围。
4. Framework：Evidence Contract、Readback、Validation Policy、Twin Update Gate。
5. Methods：检查器、策略选择、风险估计校准、失败弃权。
6. Experimental Setup：公开算例、注错、硬件版本、对照和物理参考解。
7. Results：FAR vs completion、coverage-cost、domain shift、ablation、calibration。
8. Limitations：物理模型偏差、传感器真实性、求解器共同模式错误、未观测危险、信任根。
9. Conclusion：有边界地提高科学 Agent 的可信可用性，而非宣称自动科学发现。

### 可检验的贡献表述模板（尚不能填数字）

- 提出独立验证契约，确保任务结果能够追踪到真实求解器状态和物理数值证据。
- 提出资源受限的验证选择策略，在指定错误放行约束下优化完成率与成本。
- 建立带错误注入、数值真值和模拟数据漂移的可复现实验基准。
- 在指定数据集与所测试求解器版本上，报告真实正确完成率、错误放行率、弃权率及开销相对现有基线的变化。

### English abstract outline (不捏造结果)

> Current tool-using scientific agents can generate and execute numerical simulations, but successful execution alone does not establish physical validity. We study runtime assurance for agent-driven scientific simulations and data-synchronized digital twins. We propose a solver-independent evidence contract, physically informed verification checks, and a risk- and cost-aware validation policy with explicit abstention. We further investigate a twin-update gate that prevents unverified model changes from being treated as trustworthy state updates. Evaluation is planned across benchmark PDEs, fault injection, numerical convergence studies, and measurement drift. We will report physical false-acceptance rates, verified task completion, calibration, and end-to-end cost against execution-only, reflection-based, and fixed-verification baselines.

---

## 11. 重要警示：怎么避免“看起来很先进，结果被秒拒”

1. **把仿真执行成功当真值**：最危险的假阳性来源之一。
2. **用同一个 LLM 生成模型并给自己打分**：评价不独立，可能共享系统性错误。
3. **没有数值真值**：失去评估“正确放行”的依据；至少使用解析/MMS/已验证参考解。
4. **只用 LLM 输出图好看作为验证**：视觉合理 ≠ 守恒和边界正确。
5. **没有测量就叫数字孪生**：可以做 *synthetic twin*，但必须透明命名。
6. **乱写 safety guarantee / certified**：数值容差、风险统计和物理模型错误不能统统被“认证”覆盖。
7. **把 2026 年已发表的 Agent 仿真工作当创新**：必须主动比较 MCP-SIM、GENIUS、ALL-FEM、SimBench。
8. **自动选择过小的验证预算**：精度提升若来自全部拒绝没有实际价值，应展示风险-成本-覆盖的 Pareto 曲线。
9. **期刊只按审稿快排名**：CMAME 等期刊可能初筛很快，但方法要求很高；不能因为统计快而误投。
10. **忽略学科专家**：工程方法必须得到物理审查和误差界审查，单靠后端工程代码很难达到高水平跨学科论文标准。

---

## 12. 阅读顺序（先读 10 篇，再选择完整版）

1. MCP-SIM — 学会辨别“自动求解”和“物理正确”的边界。
2. ALL-FEM — 理解自动化有限元已经走到哪里。
3. GENIUS — 看结构化状态机与求解失败修复。
4. SimBench — 学生成物理孪生评测设计。
5. Kritzinger 2018 — 严格定义 digital model/shadow/twin。
6. Oberkampf & Trucano 2002 — 学验证与确认（V&V）。
7. Roy & Oberkampf 2011 — 误差与不确定性量化。
8. Kennedy & O'Hagan 2001 — 校准与模型偏差。
9. PDEBench 2022 — 建立公开基准和统计评测。
10. ScienceAgentBench 2025 — 学如何防止 Agent 评价的结果虚高。

---

## 13. 关联文献列表（正式发表与预印本分开标注）

> 本节文献经 2026-10-20 网络检索，对标题、出处、研究主题和可追溯链接进行了交叉对照。若无 DOI 使用出版社/会议官网或 arXiv 链接。**预印本不等于同行评审发表，综述/观点文章也不等于原创实验论文**。链接可用于后续导入 Zotero；终稿还需作者自行核对引用格式和最新版本。


### A. 直接相关：2025–2026 科学 Agent 与数字孪生（前 11 篇）

1. **[A self-correcting multi-agent LLM framework for language-based physics simulation and explanation](https://www.nature.com/articles/s44387-025-00057-z)**（2026；npj Artificial Intelligence；正式期刊研究）。用途：直接竞争：MCP-SIM 自纠错物理仿真。
2. **[GENIUS: an agentic AI framework for autonomous design and execution of simulation protocols](https://www.nature.com/articles/s43246-026-01167-0)**（2026；Communications Materials；正式期刊研究）。用途：直接竞争：自动仿真协议及错误恢复。
3. **[ALL-FEM: Agentic Large Language Models fine-tuned for finite element methods](https://doi.org/10.1016/j.cma.2026.118985)**（2026；Computer Methods in Applied Mechanics and Engineering；正式期刊研究）。用途：直接竞争：FEniCS 代码自动化与验证。
4. **[SimBench: A Framework for Evaluating and Diagnosing LLM-Based Digital-Twin Generation for Multi-Physics Simulation](https://doi.org/10.1109/ACCESS.2026.3685519)**（2026；IEEE Access；正式期刊研究）。用途：直接竞争：多物理数字孪生生成评测。
5. **[AI agent-based virtual model development, diagnosis, and calibration for building digital twins](https://doi.org/10.1016/j.jii.2025.100990)**（2025；Journal of Industrial Information Integration；正式期刊研究）。用途：直接竞争：模型校准、诊断自动化。
6. **[Large language model-assisted digital twin for remote monitoring and control of advanced reactors](https://doi.org/10.1016/j.pnucene.2025.106172)**（2026；Progress in Nuclear Energy；正式期刊研究）。用途：强领域案例：仿真工具与物理建议。
7. **[Autonomous inverse modeling of complex groundwater systems via a physics-integrated large language model multi-agent framework](https://doi.org/10.1016/j.watres.2026.125886)**（2026；Water Research；正式期刊研究）。用途：强领域案例：逆问题与守恒约束。
8. **[Integrating agentic AI and digital twins for intelligent decision-making systems](https://doi.org/10.1016/j.array.2026.100721)**（2026；Array；正式期刊研究）。用途：直接竞争：多层 Agent 与数字孪生整合。
9. **[The evolution of digital twins from reactive to agentic systems](https://www.nature.com/articles/s43588-025-00944-0)**（2026；Nature Computational Science；观点/综述）。用途：研究趋势/定义：Agentic digital twins。
10. **[WorldSolver: Can LLM Agents Simulate the Physical Dynamics via Solver Generation?](https://arxiv.org/abs/2610.08720)**（2026；arXiv；预印本）。用途：直接竞争：物理求解器生成 168 题基准。
11. **[When Digital Twins Meet Large Language Models: Realistic, Interactive, and Editable Simulation for Autonomous Driving](https://arxiv.org/abs/2507.00319)**（2025；arXiv；预印本）。用途：交叉案例：可编辑数字孪生与动力学。

### B. Agent 科学研究与评估（12–17）

12. **[ScienceAgentBench: Toward Rigorous Assessment of Language Agents for Data-Driven Scientific Discovery](https://arxiv.org/abs/2410.05080)**（2025；ICLR；正式会议研究）。用途：Agent 科学基准与严谨评估。
13. **[Gravity-Bench-v1: A Benchmark on Gravitational Physics Discovery for Agents](https://proceedings.mlr.press/v267/koblischke25a.html)**（2025；ICML (PMLR)；正式会议研究）。用途：物理探索与实验预算。
14. **[LLM and Simulation as Bilevel Optimizers: A New Paradigm to Advance Physical Scientific Discovery](https://proceedings.mlr.press/v235/ma24m.html)**（2024；ICML (PMLR)；正式会议研究）。用途：LLM 提议假设+物理仿真反馈。
15. **[The AI Scientist: Towards Fully Automated Open-Ended Scientific Discovery](https://arxiv.org/abs/2408.06292)**（2024；arXiv；预印本）。用途：自动科学发现的范围与局限。
16. **[Autonomous chemical research with large language models](https://doi.org/10.1038/s41586-023-06792-0)**（2023；Nature；正式期刊研究）。用途：真实科学工具/实验系统案例。
17. **[Augmenting large language models with chemistry tools](https://doi.org/10.1038/s42256-024-00832-8)**（2024；Nature Machine Intelligence；正式期刊研究）。用途：ChemCrow：工具科学计算与实验。

### C. 数值计算、物理约束、数字孪生理论与验证（18–32）

18. **[Physics-informed neural networks: A deep learning framework for solving forward and inverse problems involving nonlinear partial differential equations](https://doi.org/10.1016/j.jcp.2018.10.045)**（2019；Journal of Computational Physics；正式期刊研究）。用途：物理约束与逆问题基础。
19. **[Physics-informed machine learning](https://doi.org/10.1038/s42254-021-00314-5)**（2021；Nature Reviews Physics；综述）。用途：物理先验与物理一致性。
20. **[Learning nonlinear operators via DeepONet based on the universal approximation theorem of operators](https://doi.org/10.1038/s42256-021-00302-5)**（2021；Nature Machine Intelligence；正式期刊研究）。用途：数字孪生快速替代模型基础。
21. **[The FEniCS Project Version 1.5](https://doi.org/10.11588/ans.2015.100.20553)**（2015；Archive of Numerical Software；正式期刊软件论文）。用途：开放有限元工具基础。
22. **[Digital Twin in manufacturing: A categorical literature review and classification](https://doi.org/10.1016/j.ifacol.2018.08.474)**（2018；IFAC-PapersOnLine；会议/论文）。用途：区分数字模型、影子、孪生。
23. **[Digital Twin in Industry: State-of-the-Art](https://doi.org/10.1109/TII.2018.2873186)**（2019；IEEE Transactions on Industrial Informatics；正式期刊综述）。用途：数字孪生要素和应用。
24. **[Bayesian calibration of computer models](https://doi.org/10.1111/1467-9868.00294)**（2001；Journal of the Royal Statistical Society Series B；正式期刊研究）。用途：模型校准与偏差。
25. **[Verification and validation in computational fluid dynamics](https://doi.org/10.1016/S0376-0421(02)00005-2)**（2002；Progress in Aerospace Sciences；正式期刊综述）。用途：验证 VS 确认、数值误差。
26. **[A comprehensive framework for verification, validation, and uncertainty quantification in scientific computing](https://doi.org/10.1016/j.cma.2011.03.016)**（2011；Computer Methods in Applied Mechanics and Engineering；正式期刊研究）。用途：不确定度系统分解。
27. **[Discovering governing equations from data by sparse identification of nonlinear dynamical systems](https://doi.org/10.1073/pnas.1517384113)**（2016；PNAS；正式期刊研究）。用途：物理模型结构识别基础。
28. **[Data-driven discovery of partial differential equations](https://doi.org/10.1126/sciadv.1602614)**（2017；Science Advances；正式期刊研究）。用途：方程误设检测与发现。
29. **[A composite neural network that learns from multi-fidelity data: Application to function approximation and inverse PDE problems](https://doi.org/10.1016/j.jcp.2019.109020)**（2020；Journal of Computational Physics；正式期刊研究）。用途：多保真/数值成本权衡。
30. **[Neural Operator: Learning Maps Between Function Spaces](https://arxiv.org/abs/2108.08481)**（2021；arXiv；预印本（本文采用此版本链接））。用途：参数化 PDE 的替代建模。
31. **[Scientific discovery in the age of artificial intelligence](https://doi.org/10.1038/s41586-023-06221-2)**（2023；Nature；正式综述）。用途：科学 AI 综述与验证风险。
32. **[Neural operators for accelerating scientific simulations and design](https://doi.org/10.1038/s42254-024-00712-5)**（2024；Nature Reviews Physics；观点/综述）。用途：替代模型加速和有效范围。

### D. 工具使用与公开基准（33–35）

33. **[Toolformer: Language Models Can Teach Themselves to Use Tools](https://proceedings.neurips.cc/paper_files/paper/2023/hash/d842425e4bf79ba039352da0f658a906-Abstract-Conference.html)**（2023；NeurIPS；正式会议研究）。用途：Agent 工具 API 使用机制。
34. **[Reflexion: Language Agents with Verbal Reinforcement Learning](https://papers.neurips.cc/paper_files/paper/2023/hash/1b44b878bb782e6954cd888628510e90-Abstract-Conference.html)**（2023；NeurIPS；正式会议研究）。用途：可对照的语言反馈自修复。
35. **[PDEBench: An Extensive Benchmark for Scientific Machine Learning](https://proceedings.neurips.cc/paper_files/paper/2022/hash/0a9747136d411fb83f0cf81820d44afb-Abstract-Datasets_and_Benchmarks.html)**（2022；NeurIPS Datasets and Benchmarks；正式会议研究）。用途：公开 PDE 数值基准。


**文献总体说明**：表中共 **35 篇**；分类包括 SCI/其他期刊、正式会议、综述/观点和预印本，不能把 35 篇说成“35 篇 SCI 论文”，也不能把全部视为直接竞争。正式论文引用时从其出版网页导出 BibTeX，核对期刊题名及最新修订。

### 额外权威资源（非以上 35 篇论文）

- [COMSOL 官方 2026 年 Agent 工作流技术文章](https://www.comsol.com/blogs/using-agentic-workflows-with-comsol-multiphysics)：说明用 Agent 操作 COMSOL 已有官方实践；这是技术博客，不计论文。
- [FEniCSx 官方引用/项目](https://fenicsproject.org/citing/)：建议优先安装维护中的 FEniCSx；上表第 21 篇为历史 FEniCS 论文，不意味着是 FEniCSx 唯一推荐引用。
- [PDEBench 官方仓库](https://github.com/pdebench/PDEBench)：数据与基线、许可证需独立检查。
- [OpenFOAM Verification and Validation Tutorials](https://doc.openfoam.com/2306/examples/verification-validation/)：实验用参考方案。
- [Elsevier Publication Pricing](https://www.elsevier.com/about/policies-and-standards/pricing)：订阅与 OA 费用解释。
- [Clarivate Master Journal List](https://mjl.clarivate.com/)：SCIE 收录正式查询入口。

---

## 14. 最终判断与交付状态

**当前状态**：完成选题、竞争文献分析、可检验创新定义、算法假设、基准路线与投稿预选；**未实现 TwinProof-Gate、未收集实验结果、未独立验证物理系统，更没有得到录用或可靠性上界。**

**研究优先级建议**：本篇的潜在学术上限比普通“网关 + Agent 调用”更高，但对于只做过 Agent/后端的学弟，首个瓶颈在 PDE 物理/数值分析，而不是 Agent 框架。最有效的策略是**先做独立证据检查的热传导 MVP，证实假成功问题与验证成本优势，再决定是否把它扩展为真实数字孪生**。

**作者与导师须补充**：是否有 COMSOL 授权和模型权限；是否能使用热学/力学专家标定的参考解；是否有真实传感器数据；投稿单位认可的 SCIE/JCR/中科院标准；预算约束。没有这些条件的情况下，也可以先完成开源仿真版本，但必须下调“在线真实数字孪生”的主张。
