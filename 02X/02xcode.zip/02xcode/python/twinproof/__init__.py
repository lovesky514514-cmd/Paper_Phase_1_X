"""TwinProof-Gate: evidence-based checks for isolated heat simulations."""

__version__ = "0.1.0"
