"""One trusted local executable and a narrow JSON protocol; no shell or remote tools."""

import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

from .model import Case

ROOT = Path(__file__).resolve().parents[2]


class LocalSolver:
    def __init__(self, binary=None):
        self._dir = None
        if binary:
            self.binary = str(binary)
        else:
            if not shutil.which("go"):
                raise RuntimeError("Go 1.22+ is required; see README")
            self._dir = tempfile.TemporaryDirectory(prefix="twinproof-")
            self.binary = str(Path(self._dir.name) / ("heat.exe" if os.name == "nt" else "heat"))
            # Compilation stays offline; no external packages are downloaded.
            built = subprocess.run(["go", "build", "-o", self.binary, "./solver"],
                                   cwd=ROOT, capture_output=True, text=True, timeout=60,
                                   env={**os.environ, "GOPROXY": "off", "GOSUMDB": "off"})
            if built.returncode:
                self.close()
                raise RuntimeError(f"Go build failed: {built.stderr.strip()[:700]}")

    def close(self):
        if self._dir is not None:
            self._dir.cleanup()
            self._dir = None

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()

    def run(self, case: Case, fault="", *, n=None):
        command = json.dumps(case.solver_input(fault, n=n), allow_nan=False)
        result = subprocess.run([self.binary], input=command, capture_output=True,
                                text=True, timeout=15)
        if result.returncode:
            raise RuntimeError(f"sandbox rejected input: {result.stderr.strip()[:250]}")
        if len(result.stdout) > 200_000:
            raise RuntimeError("sandbox produced an oversized result")
        data = json.loads(result.stdout)
        # Structural validation happens before any physical interpretation.
        size = data.get("n")
        grid = data.get("temperature_k")
        if not isinstance(size, int) or size < 5 or size > 65 or not isinstance(grid, list) or len(grid) != size * size:
            raise ValueError("malformed solver grid")
        if any(not isinstance(v, (float, int)) or not math.isfinite(v) for v in grid):
            raise ValueError("grid contains non-finite temperatures")
        return data
