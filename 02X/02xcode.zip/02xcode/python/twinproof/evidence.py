"""Independent readback, finite-difference physics and MMS reference checks."""

import hashlib
import json
import math
import random

from .model import Case, Report


def grid_reference(case: Case, n: int):
    """Independent manufactured exact solution (NOT returned by the Go solver)."""
    return [case.left_k + (case.right_k-case.left_k)*x/(n-1)
            + case.amplitude_k*math.sin(math.pi*x/(n-1))*math.sin(math.pi*y/(n-1))
            for y in range(n) for x in range(n)]


def check_readback(case, run):
    needed = ("case_id", "version", "n", "left_k", "right_k", "conductivity", "amplitude_k", "source_scale")
    return all(run.get(key) == getattr(case, key) for key in needed)


def boundary_error(run):
    n = run["n"]
    arr = run["temperature_k"]
    return max(abs(arr[y*n+x] - (run["left_k"] + (run["right_k"]-run["left_k"])*x/(n-1)))
               for y in range(n) for x in range(n) if x in (0,n-1) or y in (0,n-1))


def residual_norm(run):
    """Independent discretized -kΔu=q residual in W/m^3 on a unit-square grid."""
    n, k, amp, scale = run["n"], run["conductivity"], run["amplitude_k"], run["source_scale"]
    arr = run["temperature_k"]
    h = 1/(n-1)
    worst = 0.0
    for y in range(1,n-1):
        for x in range(1,n-1):
            idx = y*n+x
            lap = (arr[idx-1] + arr[idx+1] + arr[idx-n] + arr[idx+n] - 4*arr[idx])/(h*h)
            source = 2*k*math.pi**2*amp*scale*math.sin(math.pi*x*h)*math.sin(math.pi*y*h)
            worst = max(worst, abs(-k*lap-source))
    return worst


def reference_error(case, run):
    truth = grid_reference(case, run["n"])
    return max(abs(actual-target) for actual,target in zip(run["temperature_k"], truth))


def model_digest(run):
    # No tool credentials or user prompt content are kept in the manifest.
    snapshot = {k: v for k,v in run.items() if k != "temperature_k"}
    snapshot["grid_sha256"] = hashlib.sha256(json.dumps(run["temperature_k"],
                                      separators=(",", ":")).encode()).hexdigest()
    return hashlib.sha256(json.dumps(snapshot, sort_keys=True).encode()).hexdigest()


class Verifier:
    """Budget costs are abstract units, not a wall-clock or calibrated risk guarantee."""
    def __init__(self, runner, *, tolerance_k=0.17):
        self.runner = runner
        self.tolerance_k = tolerance_k

    def verify(self, case: Case, run, *, budget=20, policy="adaptive", seed=0):
        if not isinstance(budget, int) or not 0 <= budget <= 100:
            raise ValueError("budget must be an integer within [0, 100]")
        if policy not in {"adaptive", "exit_only", "fixed", "random"}:
            raise ValueError("unknown policy")
        report = Report(case_id=case.case_id, decision="ABSTAIN_UNVERIFIABLE", budget_units=budget)
        report.model_digest = model_digest(run)
        if policy == "exit_only":
            report.decision = "PASS_UNVERIFIED" if run.get("solver_status") == "converged" else "ABSTAIN_UNVERIFIABLE"
            report.reasons.append("exit status is not independent physical evidence")
            return report

        def check(name, cost, fn, detail=""):
            if report.used_units + cost > budget:
                report.decision = "HUMAN_ESCALATION"
                report.reasons.append(f"budget exhausted before {name}")
                return False
            ok = bool(fn())
            report.add(name, ok, cost, detail)
            if not ok:
                report.decision = "REJECT_WITH_CAUSE"
                report.reasons.append(f"{name} failed")
            return ok

        if not check("readback", 1, lambda: check_readback(case,run)):
            return report
        if not check("solver_status", 1, lambda: run.get("solver_status") == "converged"):
            return report
        if not check("boundary", 1, lambda: boundary_error(run) <= 1e-7):
            return report
        if not check("pde_residual", 2, lambda: residual_norm(run) <= 1e-4):
            return report

        if policy == "random":
            # Budget-matched random expensive testing is an intentionally simple local baseline.
            choose_reference = random.Random(seed).random() < .5
            if not choose_reference:
                report.decision = "PASS_UNVERIFIED"
                report.reasons.append("random baseline did not collect independent reference")
                return report

        if not check("mms_reference", 3, lambda: reference_error(case,run) <= self.tolerance_k):
            return report

        # Refinement is the expensive verification tier. For elevated risk, the
        # adaptive policy requires it; normal-risk tasks use the independent MMS.
        # Elevated tier is derived from typed physical task properties, never from an Agent risk label.
        elevated = case.n <= 9 or abs(case.amplitude_k) >= 20 or abs(case.right_k-case.left_k) >= 80
        require_refinement = policy == "fixed" or (policy == "adaptive" and elevated)
        if require_refinement:
            if report.used_units + 12 > budget:
                report.decision = "HUMAN_ESCALATION"
                report.reasons.append("budget exhausted before mesh refinement")
                return report
            try:
                # Three independently executed grid sizes; don't recycle a cached answer.
                errors = [reference_error(case, self.runner.run(case,n=n)) for n in (9,17,33)]
                good = errors[0] > errors[1] > errors[2] and errors[0]/max(errors[1],1e-12) > 3 and errors[1]/max(errors[2],1e-12) > 3
                report.add("three_mesh_convergence", good, 12, f"errors_kelvin={[round(e, 7) for e in errors]}")
            except (RuntimeError, ValueError, TimeoutError) as error:
                report.add("three_mesh_convergence", False, 12, "solver run unavailable")
                report.reasons.append(f"refinement failed: {type(error).__name__}")
                report.decision = "ABSTAIN_UNVERIFIABLE"
                return report
            if not good:
                report.decision = "REJECT_WITH_CAUSE"
                report.reasons.append("mesh convergence failed")
                return report
        report.decision = "PASS_WITH_EVIDENCE"
        return report
