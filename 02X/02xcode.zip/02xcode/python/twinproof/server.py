"""Restricted loopback HTTP interface; no arbitrary code, tools, or file paths."""

from dataclasses import asdict
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import secrets
import time

from .model import Case
from .evidence import Verifier
from .twin import TwinStore, Observation


def handler_for(runner, store):
    class Handler(BaseHTTPRequestHandler):
        def do_POST(self):
            if self.path != "/verify":
                self.send_error(404)
                return
            if self.headers.get("Content-Type", "").split(";")[0].strip() != "application/json":
                self.send_error(415)
                return
            try:
                size = int(self.headers.get("Content-Length", "0"))
                if size < 1 or size > 8192:
                    raise ValueError("request size must be 1..8192 bytes")
                data = json.loads(self.rfile.read(size))
                if set(data) - {"case", "budget", "policy", "observation"}:
                    raise ValueError("unknown top-level fields")
                case = Case(**data["case"])
                run = runner.run(case)
                report = Verifier(runner).verify(case,run,budget=data.get("budget",20),
                                                       policy=data.get("policy","adaptive"))
                trace_id = secrets.token_hex(16)
                store.log(trace_id,report)
                twin_status = "NOT_REQUESTED"
                if "observation" in data:
                    obs = Observation(**data["observation"])
                    twin_status = store.update(case,run,report,obs,now_s=int(time.time()))
                body = {"trace_id": trace_id, "report":asdict(report), "twin_update":twin_status}
                output = json.dumps(body,ensure_ascii=False).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type","application/json; charset=utf-8")
                self.send_header("Content-Length",str(len(output)))
                self.end_headers()
                self.wfile.write(output)
            except (ValueError,TypeError,KeyError) as error:
                output = json.dumps({"error":str(error)[:180]}).encode()
                self.send_response(400)
                self.send_header("Content-Type","application/json")
                self.send_header("Content-Length",str(len(output)))
                self.end_headers()
                self.wfile.write(output)
            except (RuntimeError,TimeoutError):
                self.send_error(502, "local sandbox execution failed")

        def log_message(self, fmt, *args):
            # Never log user-supplied payloads or complete request JSON.
            return
    return Handler


def serve(runner, db_path, port=8765):
    if not isinstance(port,int) or not (1024<=port<=65535):
        raise ValueError("invalid port")
    store = TwinStore(db_path)
    server = ThreadingHTTPServer(("127.0.0.1",port),handler_for(runner,store))
    print(f"TwinProof sandbox: http://127.0.0.1:{port}/verify",flush=True)
    try:
        server.serve_forever()
    finally:
        server.server_close()
