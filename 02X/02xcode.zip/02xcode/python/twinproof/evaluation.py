"""Repeatable paired *synthetic* experiment; never infer peer-reviewed gains."""

from dataclasses import asdict
import math
import random
import statistics
import time

from .model import Case
from .evidence import Verifier, check_readback, reference_error

FAULTS = ("", "", "", "", "swap_boundaries", "reverse_source", "missing_source", "wrong_conductivity", "fake_converged", "short_iteration", "tamper_center")
POLICIES = ("exit_only", "random", "fixed", "adaptive")


def cases(seed=19, count=48):
    rng = random.Random(seed)
    for i in range(count):
        # Ground-truth injection metadata is never passed to the Verifier.
        fault = FAULTS[i % len(FAULTS)]
        grid = (9, 17, 33)[(i // len(FAULTS)) % 3]
        yield Case(case_id=f"heat_{i:03}", n=grid, left_k=300, right_k=320,
                   conductivity=5, amplitude_k=rng.choice((7.0, 15.0, 30.0)),
                   ), fault


def wilson(successes, total, z=1.96):
    """Wilson score interval for a binomial proportion, including zero events."""
    if total == 0:
        return [None, None]
    p = successes / total
    d = 1 + z*z/total
    mid = (p+z*z/(2*total))/d
    margin = z*math.sqrt((p*(1-p)+z*z/(4*total))/total)/d
    return [round(max(0,mid-margin),5), round(min(1,mid+margin),5)]


def experiment(runner, *, seed=19, count=48, budget=20):
    verifier = Verifier(runner)
    rows = {p: [] for p in POLICIES}
    for i, (case, fault) in enumerate(cases(seed, count)):
        run = runner.run(case, fault)
        # Independent experiment oracle: compare executed state against the
        # declared manufactured exact solution, not the decision or risk flag.
        reference_good = reference_error(case,run) <= 0.17
        truth_valid = check_readback(case,run) and reference_good and run["solver_status"] == "converged"
        for policy in POLICIES:
            start = time.perf_counter_ns()
            decision = verifier.verify(case,run,budget=budget,policy=policy,seed=seed+i)
            elapsed_ms = (time.perf_counter_ns() - start) / 1e6
            rows[policy].append({"case_id": case.case_id, "fault": fault or "none", "truth_valid": truth_valid,
                                 "decision": decision.decision, "allowed": decision.allowed,
                                 "verify_cost_units": decision.used_units, "latency_ms": round(elapsed_ms,4)})
    result = {}
    for policy, records in rows.items():
        negatives = [r for r in records if not r["truth_valid"]]
        positives = [r for r in records if r["truth_valid"]]
        false_accepts = sum(r["allowed"] for r in negatives)
        successes = sum(r["allowed"] and r["truth_valid"] for r in records)
        times = sorted(r["latency_ms"] for r in records)
        result[policy] = {
            "cases": len(records), "invalid_cases": len(negatives), "false_accepts": false_accepts,
            "false_accept_rate": round(false_accepts/len(negatives),5) if negatives else None,
            "false_accept_wilson95": wilson(false_accepts,len(negatives)),
            "valid_completion_rate": round(successes/len(records),5),
            "unnecessary_rejection_rate": round(sum(not r["allowed"] for r in positives)/len(positives),5) if positives else None,
            "abstention_rate": round(sum(r["decision"] in {"ABSTAIN_UNVERIFIABLE","HUMAN_ESCALATION"} for r in records)/len(records),5),
            "mean_verify_cost_units": round(statistics.mean(r["verify_cost_units"] for r in records),3),
            "p95_verification_wall_ms_observed": times[math.ceil(.95*len(times))-1],
        }
    return {"protocol": "synthetic heat MMS v1; not online digital twin", "seed": seed,
            "count": count, "budget_units_per_case": budget, "summary": result,
            "records": rows,
            "timing_note": "Observed CPU time is environment-dependent and not bitwise reproducible."}
