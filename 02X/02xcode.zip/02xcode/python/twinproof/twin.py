"""Synthetic sensor update gate; no real-world digital twin is claimed."""

from dataclasses import dataclass
from contextlib import contextmanager
from datetime import datetime, timezone
import math
import sqlite3
from pathlib import Path


@dataclass(frozen=True)
class Observation:
    sensor_id: str
    observed_k: float
    measured_at_s: int
    source: str = "synthetic"


class TwinStore:
    def __init__(self, path):
        self.path = str(path)
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        with self._db() as db:
            db.execute("CREATE TABLE IF NOT EXISTS twin (case_id TEXT PRIMARY KEY, version INTEGER NOT NULL, temperature_k REAL NOT NULL, observed_at INTEGER NOT NULL)")
            db.execute("CREATE TABLE IF NOT EXISTS audit (trace_id TEXT PRIMARY KEY, case_id TEXT NOT NULL, decision TEXT NOT NULL, digest TEXT NOT NULL, created_at TEXT NOT NULL)")

    @contextmanager
    def _db(self):
        # sqlite3 connection context managers commit but do not close: close explicitly.
        db = sqlite3.connect(self.path, timeout=10)
        try:
            with db:
                yield db
        finally:
            db.close()

    def log(self, trace_id, report):
        with self._db() as db:
            db.execute("INSERT INTO audit VALUES (?, ?, ?, ?, ?)", (trace_id, report.case_id, report.decision,
                       report.model_digest, datetime.now(timezone.utc).isoformat()))

    def state(self, case_id):
        with self._db() as db:
            row = db.execute("SELECT version, temperature_k, observed_at FROM twin WHERE case_id = ?", (case_id,)).fetchone()
        return row

    def update(self, case, run, report, observation, *, max_age_s=120, now_s=None):
        """Use optimistic version-checking to prevent a stale model overwriting a new state."""
        from .evidence import check_readback, model_digest
        if (report.decision != "PASS_WITH_EVIDENCE" or observation is None
                or report.case_id != case.case_id or not check_readback(case, run)
                or report.model_digest != model_digest(run)):
            return "FROZEN_UNVERIFIABLE"
        if observation.source != "synthetic" or observation.sensor_id != "center" or not math.isfinite(observation.observed_k):
            return "FROZEN_BAD_SOURCE"
        if now_s is None:
            now_s = int(datetime.now(timezone.utc).timestamp())
        if observation.measured_at_s > now_s or now_s - observation.measured_at_s > max_age_s:
            return "FROZEN_STALE_OBSERVATION"
        center = run["temperature_k"][(run["n"]//2)*run["n"] + run["n"]//2]
        if abs(center-observation.observed_k) > 0.6:
            return "FROZEN_DRIFT"
        with self._db() as db:
            db.execute("BEGIN IMMEDIATE")
            current = db.execute("SELECT version, observed_at FROM twin WHERE case_id=?", (case.case_id,)).fetchone()
            if current and (case.version <= current[0] or observation.measured_at_s <= current[1]):
                return "FROZEN_VERSION_CONFLICT"
            db.execute("INSERT INTO twin(case_id,version,temperature_k,observed_at) VALUES(?,?,?,?) "
                       "ON CONFLICT(case_id) DO UPDATE SET version=excluded.version, "
                       "temperature_k=excluded.temperature_k, observed_at=excluded.observed_at",
                       (case.case_id,case.version,center,observation.measured_at_s))
        return "SYNTHETIC_UPDATE_ACCEPTED"
