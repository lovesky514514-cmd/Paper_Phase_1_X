"""Typed inputs and evidence outcomes. Only kelvin and SI units are accepted."""

from dataclasses import dataclass, field, asdict
import math
import re


@dataclass(frozen=True)
class Case:
    case_id: str
    version: int = 1
    n: int = 17
    left_k: float = 300.0
    right_k: float = 320.0
    conductivity: float = 5.0
    amplitude_k: float = 10.0
    source_scale: float = 1.0

    def __post_init__(self):
        if not re.fullmatch(r"[a-zA-Z0-9_-]{1,64}", self.case_id):
            raise ValueError("case_id must be 1-64 safe ASCII characters")
        if type(self.version) is not int or type(self.n) is not int:
            raise ValueError("version and n must be integer values")
        if self.version < 1 or self.n < 5 or self.n > 65 or self.n % 2 != 1:
            raise ValueError("invalid version or grid n (odd 5..65)")
        values = (self.left_k, self.right_k, self.conductivity, self.amplitude_k, self.source_scale)
        if any(not math.isfinite(x) for x in values):
            raise ValueError("physical quantities must be finite")
        if min(self.left_k, self.right_k) < 1 or self.conductivity <= 0 or abs(self.amplitude_k) > 200:
            raise ValueError("invalid temperature, conductivity or amplitude")
        if abs(self.source_scale) > 5:
            raise ValueError("invalid source scale")

    def solver_input(self, fault="", *, n=None):
        # Observations and fault truth never become verifier evidence.
        values = asdict(self)
        values.update(n=self.n if n is None else n, fault=fault)
        return values


@dataclass
class Report:
    case_id: str
    decision: str
    checks: list[dict] = field(default_factory=list)
    used_units: int = 0
    budget_units: int = 0
    reasons: list[str] = field(default_factory=list)
    model_digest: str = ""

    @property
    def allowed(self):
        return self.decision in {"PASS_WITH_EVIDENCE", "PASS_UNVERIFIED"}

    def add(self, name, passed, cost, detail=""):
        self.used_units += cost
        self.checks.append({"name": name, "passed": bool(passed), "cost_units": cost, "detail": detail})
