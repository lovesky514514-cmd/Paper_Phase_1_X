module twinproof/solver

go 1.22
