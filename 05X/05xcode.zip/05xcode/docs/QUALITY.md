# 交付质量与研究边界

代码：Python 3.11+ / Go 1.22+，不需要额外第三方依赖，Go 代码采用 gofmt。

强制控制的验证范围：Go 本地模拟票据、合成身份 `alice`、可信本地 source registry、单进程锁、内存请求账本。对于网络绕路、管理员密钥泄露、宿主机攻陷、跨服务事务和生产访问，一概不声称提供保障。

研究层为 V0/M1 **启发式**：额外检查的规则/窗口 bandit 和简单漂移触发器，不是完整 Stackelberg/Nash 求解器，没有动态 regret 证明，也没有验证风险估计的校准性。

用户应重点查看 `results/pilot.json` 中各策略的实际对照；任何没有超过基线的结果保留，不删去负例。

当前环境通过 Python unittest、Go 单元、Go race/vet 和实际 HTTP 本地演示。Windows 启动脚本未经过 Windows 真机确认。
