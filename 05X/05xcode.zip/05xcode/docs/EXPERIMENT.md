# 实验协议（合成）

默认固定种子：`7,19,41,73,101`；每策略每场景 100 条、检查预算 145 合成单位。

4 种场景：static / switch（第 60 步后类别变化）/ cycle（30 步一换）/ reactive（只读公开拒绝计数）。

10 种本地策略：no_extra、all_stop、fixed_light、fixed_deep、random、threshold、bandit、game，以及 game_no_drift、game_no_mix 消融。**均不是 Progent、Fides、CaMeL 的正式复现**。

`results/pilot.json` 包含每次种子、事件标识、决策、合成检查成本以及汇总。使用 `--audit-db path.sqlite` 可生成带哈希链的审计，哈希链支持无密钥的意外修改检测，不等同抗恶意管理员篡改。

主要指标：`vasr`（获硬授权但合成攻击仍造成危险模拟效果的比例，越低越好）、`benign_success_rate`（已获授权的良性任务中完成比例，越高越好）、`spent`、`p95_latency_units`、`false_block_rate`、`hard_policy_violations`。

所有延迟和成本都是**虚拟单位**，不能宣称实测 P95/CPU/Token 成本。检测概率是合成设定，并非训练出的模型；置信度未经校准。反应型对手会受到策略反馈影响，因此不同策略的攻击序列**不严格相同**，仅种子和规则一致。

论文实验仍缺公开真实安全基准、真实 MCP/Agent 调用、强基线和统计显著性、真实运营负载、对手收益建模、漂移后收敛分析。
