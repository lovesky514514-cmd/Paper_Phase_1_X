# 常见错误与处理

| 现象 | 原因与处理 |
|---|---|
| `python` 不存在 | 安装 Python 3.11+，检查 PATH；Windows 先运行 `py -3 scripts/check.py --no-race` |
| `go` 不存在 | 安装 Go 1.22+；只能运行 `python scripts/check.py --no-go`，这**不代表**通过全部检查 |
| Go `-race` 提示缺少 C 编译器 | Windows 使用 `--no-race`；在有 CGO 的 Linux/macOS 单独执行 `cd gateway && go test -race ./...` |
| 401 `unauthorized_client` | Go HTTP 需要临时 Bearer token；用 `python scripts/demo.py` 自动注入，不要硬编码 token |
| 403 `untrusted_provenance` | 服务端来源记录与内容不匹配；检查 `guard.New` 仅允许的合成来源 ID/文本 |
| 403 `not_authorized` | 身份、scope 或撤权状态不满足；重启演示会重置内存沙箱 |
| 403 `idempotency_conflict` | 同 request_id 的资源/内容发生变化；必须创建新的逻辑意图 ID |
| `TimeoutError` | 可能有本地防火墙或 Go 构建未完成；关闭占用回环端口的程序并重新运行 |
| 科研策略 vASR 很高 | 这不是程序崩溃。检查 `docs/EXPERIMENT.md`、JSON 的预算和漂移配置 |
| ZIP 哈希不匹配 | 重新解压原 ZIP；不要修改源码后拿旧清单继续校验 |

按文件查错见 `docs/DEBUG_INDEX.md`。如测试失败，请先保留失败命令和错误文本，再最小化复现并增加回归测试，避免“删掉失败测试来通过”。
