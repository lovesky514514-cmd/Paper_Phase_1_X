# gameshield/audit.py

**职责**：SQLite 摘要链实验账本。

**发现异常**：优先运行 `python scripts/check.py --no-race`；Go 源码可在 `gateway/` 下用 `go test -v ./...` 单独诊断。

**排查与修复**：修改检测失败检查 digest 链，注意无密钥哈希不能防恶意管理员全链重算。

**修改后验证**：重跑对应测试和全量检查，避免改变既有安全门或隐瞒负结果。
