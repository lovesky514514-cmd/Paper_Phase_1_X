# scripts/demo.py

**职责**：实际 Go HTTP 生命周期演示。

**发现异常**：优先运行 `python scripts/check.py --no-race`；Go 源码可在 `gateway/` 下用 `go test -v ./...` 单独诊断。

**排查与修复**：启动失败检查 Go 编译器、回环端口、短暂防火墙拦截，不泄露 token。

**修改后验证**：重跑对应测试和全量检查，避免改变既有安全门或隐瞒负结果。
