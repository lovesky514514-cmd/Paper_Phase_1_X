# docs/TROUBLESHOOTING.md

**职责**：维护和科研边界说明。

**发现异常**：优先运行 `python scripts/check.py --no-race`；Go 源码可在 `gateway/` 下用 `go test -v ./...` 单独诊断。

**排查与修复**：与代码行为不一致时重新执行自检，更新文档并报告受影响的实验结论。

**修改后验证**：重跑对应测试和全量检查，避免改变既有安全门或隐瞒负结果。
