# scripts/check.py

**职责**：统一自检入口。

**发现异常**：优先运行 `python scripts/check.py --no-race`；Go 源码可在 `gateway/` 下用 `go test -v ./...` 单独诊断。

**排查与修复**：先 python -m unittest 再 go test，Windows 无 CGO 可使用 --no-race。

**修改后验证**：重跑对应测试和全量检查，避免改变既有安全门或隐瞒负结果。
