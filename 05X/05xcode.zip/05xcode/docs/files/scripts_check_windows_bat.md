# scripts/check_windows.bat

**职责**：Windows 启动脚本。

**发现异常**：优先运行 `python scripts/check.py --no-race`；Go 源码可在 `gateway/` 下用 `go test -v ./...` 单独诊断。

**排查与修复**：确认从项目根目录启动，并安装 Python/Go 且 PATH 正确；原生 Windows 尚未实测。

**修改后验证**：重跑对应测试和全量检查，避免改变既有安全门或隐瞒负结果。
