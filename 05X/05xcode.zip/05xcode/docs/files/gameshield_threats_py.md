# gameshield/threats.py

**职责**：合成攻击场景与假检测器。

**发现异常**：优先运行 `python scripts/check.py --no-race`；Go 源码可在 `gateway/` 下用 `go test -v ./...` 单独诊断。

**排查与修复**：若结果变动检查种子、coin 盐值、ATTACKS 与不同策略的 reactive 反馈。

**修改后验证**：重跑对应测试和全量检查，避免改变既有安全门或隐瞒负结果。
