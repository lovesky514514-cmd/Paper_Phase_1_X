# gameshield/allocator.py

**职责**：附加检查预算分配。

**发现异常**：优先运行 `python scripts/check.py --no-race`；Go 源码可在 `gateway/` 下用 `go test -v ./...` 单独诊断。

**排查与修复**：若超预算检查 remaining/charge；若漂移失效检查 _drift 的观测反馈。

**修改后验证**：重跑对应测试和全量检查，避免改变既有安全门或隐瞒负结果。
