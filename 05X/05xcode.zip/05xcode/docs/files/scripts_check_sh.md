# scripts/check.sh

**职责**：POSIX 启动脚本。

**发现异常**：优先运行 `python scripts/check.py --no-race`；Go 源码可在 `gateway/` 下用 `go test -v ./...` 单独诊断。

**排查与修复**：执行 sh scripts/check.sh，核对脚本与项目根路径，检查权限。

**修改后验证**：重跑对应测试和全量检查，避免改变既有安全门或隐瞒负结果。
