# gateway/guard/guard.go

**职责**：可信授权与内存事务。

**发现异常**：优先运行 `python scripts/check.py --no-race`；Go 源码可在 `gateway/` 下用 `go test -v ./...` 单独诊断。

**排查与修复**：若出现未授权写入：先检查 source registry/Grant/Execute 的加锁位置；运行 go test -race ./...。

**修改后验证**：重跑对应测试和全量检查，避免改变既有安全门或隐瞒负结果。
