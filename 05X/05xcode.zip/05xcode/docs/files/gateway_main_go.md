# gateway/main.go

**职责**：回环 HTTP 入口、双 Token 角色控制。

**发现异常**：优先运行 `python scripts/check.py --no-race`；Go 源码可在 `gateway/` 下用 `go test -v ./...` 单独诊断。

**排查与修复**：401 检查 Bearer token；403 检查 guard 拒绝原因；413 检查 4096 字节限制。

**修改后验证**：重跑对应测试和全量检查，避免改变既有安全门或隐瞒负结果。
