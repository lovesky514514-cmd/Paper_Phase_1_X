# requirements.txt

**职责**：Python 第三方依赖声明。

**发现异常**：优先运行 `python scripts/check.py --no-race`；Go 源码可在 `gateway/` 下用 `go test -v ./...` 单独诊断。

**排查与修复**：当前只用标准库，不要为解决无关问题添加不必要依赖。

**修改后验证**：重跑对应测试和全量检查，避免改变既有安全门或隐瞒负结果。
