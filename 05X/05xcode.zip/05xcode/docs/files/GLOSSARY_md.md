# GLOSSARY.md

**职责**：项目配置或说明文件。

**发现异常**：优先运行 `python scripts/check.py --no-race`；Go 源码可在 `gateway/` 下用 `go test -v ./...` 单独诊断。

**排查与修复**：校验 SHA 清单，对照 README 环境要求检查修改。

**修改后验证**：重跑对应测试和全量检查，避免改变既有安全门或隐瞒负结果。
