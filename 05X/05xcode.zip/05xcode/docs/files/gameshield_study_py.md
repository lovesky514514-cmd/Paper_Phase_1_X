# gameshield/study.py

**职责**：实验入口、生成结构化指标。

**发现异常**：优先运行 `python scripts/check.py --no-race`；Go 源码可在 `gateway/` 下用 `go test -v ./...` 单独诊断。

**排查与修复**：若指标异常先区分 hard deny、detector flag 与真实模拟效果。

**修改后验证**：重跑对应测试和全量检查，避免改变既有安全门或隐瞒负结果。
