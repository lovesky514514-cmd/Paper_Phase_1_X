# scripts/verify_package.py

**职责**：SHA-256 文件清单核验。

**发现异常**：优先运行 `python scripts/check.py --no-race`；Go 源码可在 `gateway/` 下用 `go test -v ./...` 单独诊断。

**排查与修复**：hash mismatch 说明文件和分发基线不同；回到原 ZIP 重新解压。

**修改后验证**：重跑对应测试和全量检查，避免改变既有安全门或隐瞒负结果。
