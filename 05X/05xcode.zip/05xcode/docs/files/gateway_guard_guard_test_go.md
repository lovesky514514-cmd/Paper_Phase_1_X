# gateway/guard/guard_test.go

**职责**：拒绝、重复与撤权竞态回归测试。

**发现异常**：优先运行 `python scripts/check.py --no-race`；Go 源码可在 `gateway/` 下用 `go test -v ./...` 单独诊断。

**排查与修复**：测试失败时隔离最短重现，检查模拟源文本与逻辑请求 ID 的关系。

**修改后验证**：重跑对应测试和全量检查，避免改变既有安全门或隐瞒负结果。
