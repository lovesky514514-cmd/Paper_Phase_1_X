# gateway/go.mod

**职责**：Go 标准库模块版本。

**发现异常**：优先运行 `python scripts/check.py --no-race`；Go 源码可在 `gateway/` 下用 `go test -v ./...` 单独诊断。

**排查与修复**：确认 go version >= 1.22，避免自动下载新的外部依赖。

**修改后验证**：重跑对应测试和全量检查，避免改变既有安全门或隐瞒负结果。
