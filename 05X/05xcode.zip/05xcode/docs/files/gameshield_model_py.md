# gameshield/model.py

**职责**：严格隔离的观察模型。

**发现异常**：优先运行 `python scripts/check.py --no-race`；Go 源码可在 `gateway/` 下用 `go test -v ./...` 单独诊断。

**排查与修复**：若策略读到攻击标签，检查 Attempt.attack_kind 是否错误传播到 Observation。

**修改后验证**：重跑对应测试和全量检查，避免改变既有安全门或隐瞒负结果。
