# gateway/main_test.go

**职责**：HTTP 授权集成测试。

**发现异常**：优先运行 `python scripts/check.py --no-race`；Go 源码可在 `gateway/` 下用 `go test -v ./...` 单独诊断。

**排查与修复**：调用失败先区分 401、403 与 JSON 格式错误，不要放宽强制授权。

**修改后验证**：重跑对应测试和全量检查，避免改变既有安全门或隐瞒负结果。
