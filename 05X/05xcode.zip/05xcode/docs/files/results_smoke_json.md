# results/smoke.json

**职责**：合成实验固定种子输出。

**发现异常**：优先运行 `python scripts/check.py --no-race`；Go 源码可在 `gateway/` 下用 `go test -v ./...` 单独诊断。

**排查与修复**：发现不一致时以相同 --seeds --budget --count 重新生成，核对所用代码版本。

**修改后验证**：重跑对应测试和全量检查，避免改变既有安全门或隐瞒负结果。
