# tests/test_study.py

**职责**：可复现行为回归测试。

**发现异常**：优先运行 `python scripts/check.py --no-race`；Go 源码可在 `gateway/` 下用 `go test -v ./...` 单独诊断。

**排查与修复**：先单独运行 python -m unittest discover -s tests -v，定位对应行为；不要删除失败断言。

**修改后验证**：重跑对应测试和全量检查，避免改变既有安全门或隐瞒负结果。
