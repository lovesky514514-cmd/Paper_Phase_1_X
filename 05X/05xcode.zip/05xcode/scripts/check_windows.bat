@echo off
setlocal
cd /d "%~dp0.."
chcp 65001 >nul
python scripts\check.py --no-race
if errorlevel 1 (
  echo Self-check failed. See docs\TROUBLESHOOTING.md
  pause
  exit /b 1
)
echo Self-check passed.
pause
