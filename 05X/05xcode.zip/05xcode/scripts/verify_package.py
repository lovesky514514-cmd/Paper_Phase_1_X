"""Check the SHA-256 manifest after the archive is unpacked."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def main():
    manifest=json.loads((ROOT/"PACKAGE_SHA256.json").read_text(encoding="utf-8"))
    for relative, expected in manifest["files"].items():
        path=(ROOT/relative).resolve()
        if not path.is_relative_to(ROOT.resolve()) or not path.is_file():
            raise SystemExit(f"missing or invalid file: {relative}")
        actual=hashlib.sha256(path.read_bytes()).hexdigest()
        if actual!=expected:
            raise SystemExit(f"hash mismatch: {relative}")
    print(f"PASS: SHA-256 of {len(manifest['files'])} package members")


if __name__=="__main__":main()
