#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
python3 -m gameshield.study --out results/pilot.json
