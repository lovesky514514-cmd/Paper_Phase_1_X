"""Compile and exercise the real Go HTTP mock with ephemeral in-memory credentials."""
from __future__ import annotations
import json
import os
from pathlib import Path
import secrets
import socket
import subprocess
import tempfile
import time
import urllib.error
import urllib.request

ROOT=Path(__file__).resolve().parents[1]


def request(url: str, token: str | None = None, body: dict | None = None) -> tuple[int, dict]:
    data=None if body is None else json.dumps(body).encode()
    method="GET" if body is None else "POST"
    headers={"Content-Type":"application/json"}
    if token:
        headers["Authorization"]="Bearer "+token
    req=urllib.request.Request(url,data=data,headers=headers,method=method)
    try:
        with urllib.request.urlopen(req,timeout=3) as response:
            return response.status,json.load(response)
    except urllib.error.HTTPError as error:
        with error:
            return error.code,json.load(error)


def main() -> None:
    client=secrets.token_hex(24)
    admin=secrets.token_hex(24)
    with socket.socket() as s:
        s.bind(("127.0.0.1",0))
        port=s.getsockname()[1]
    with tempfile.TemporaryDirectory() as temp:
        binary=Path(temp)/("gameshield.exe" if os.name=="nt" else "gameshield")
        subprocess.run(["go","build","-o",str(binary),"."],cwd=ROOT/"gateway",check=True,timeout=90)
        env={**os.environ,"GAMESHIELD_CLIENT_TOKEN":client,"GAMESHIELD_ADMIN_TOKEN":admin,
             "GAMESHIELD_ADDR":f"127.0.0.1:{port}"}
        process=subprocess.Popen([str(binary)],cwd=ROOT/"gateway",env=env,
                                 stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        url=f"http://127.0.0.1:{port}"
        try:
            for _ in range(60):
                if process.poll() is not None:
                    raise RuntimeError("Go sandbox exited before becoming healthy")
                try:
                    status,_=request(url+"/health")
                    if status==200:break
                except (urllib.error.URLError,TimeoutError,ConnectionError):
                    time.sleep(.08)
            else:
                raise TimeoutError("Go sandbox did not start")
            call={"request_id":"demo-1","principal":"alice","tool":"sim.ticket.create",
                  "resource":"sandbox/tickets","source_id":"user-approved","text":"synthetic ticket"}
            code,_=request(url+"/v1/execute",body=call)
            assert code==401,code
            code,first=request(url+"/v1/execute",client,call)
            assert code==200 and first["decision"]=="execute",(code,first)
            code,again=request(url+"/v1/execute",client,call)
            assert code==200 and again["replayed"] and again["event_id"]==first["event_id"]
            fake=dict(call,request_id="demo-2",text="forged trusted content")
            code,blocked=request(url+"/v1/execute",client,fake)
            assert code==403 and blocked["reason"]=="untrusted_provenance",blocked
            code,_=request(url+"/v1/revoke",client,{})
            assert code==401,code
            code,_=request(url+"/v1/revoke",admin,{})
            assert code==200,code
            code,blocked=request(url+"/v1/execute",client,dict(call,request_id="demo-3"))
            assert code==403 and blocked["reason"]=="not_authorized",blocked
            code,st=request(url+"/v1/state",admin)
            assert code==200 and st["effects"]==1,st
            print("PASS: HTTP auth, one write, replay, source binding, revoke, effect count=1")
        finally:
            process.terminate()
            try:process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                process.kill();process.wait(timeout=3)

if __name__=="__main__":
    main()
