@echo off
setlocal
cd /d "%~dp0.."
chcp 65001 >nul
python -m gameshield.study --out results\pilot.json
if errorlevel 1 echo Failed. See docs\TROUBLESHOOTING.md
pause
