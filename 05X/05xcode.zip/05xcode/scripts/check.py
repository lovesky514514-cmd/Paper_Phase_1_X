"""Run behavior, race and end-to-end checks from any working directory."""
from __future__ import annotations
import argparse
import shutil
import subprocess
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def run(args: list[str], cwd: Path=ROOT):
    print("CHECK", " ".join(args),flush=True)
    output=subprocess.run(args,cwd=cwd,text=True,encoding="utf-8",errors="replace",
                          stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=180)
    print(output.stdout[-2500:])
    if output.returncode:
        raise SystemExit(f"failed: {output.returncode} {args}")


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--no-go",action="store_true",help="only check Python")
    parser.add_argument("--no-race",action="store_true",help="skip Go -race on Windows without a C compiler")
    args=parser.parse_args()
    if sys.version_info < (3,11):
        raise SystemExit("Python 3.11+ required")
    run([sys.executable,"-m","compileall","-q","gameshield","scripts","tests"])
    run([sys.executable,"-m","unittest","discover","-s","tests","-v"])
    if not args.no_go:
        if not shutil.which("go"):
            raise SystemExit("Go 1.22+ required; use --no-go for Python only")
        run(["go","test","./..."],ROOT/"gateway")
        run(["go","vet","./..."],ROOT/"gateway")
        if not args.no_race:
            run(["go","test","-race","./..."],ROOT/"gateway")
        run([sys.executable,"scripts/demo.py"])
    run([sys.executable,"-m","gameshield.study","--count","30","--seeds","7,19", "--budget","43","--out","results/local-check.json", "--audit-db", "results/local-check.sqlite"])
    print("PASS: all selected checks")

if __name__=="__main__":main()
