# 05x · GameShield-Gate

Agent × 网络安全 × 博弈论：**硬授权永不让步，动态算法只选附加检查的深度**。
当前是**本地合成研究原型**，不是完整 MCP 生产网关或已验证的 SCI 方法。

## 环境与运行

- Python **3.11+**、Go **1.22+**；无需 pip 第三方包、API Key、GPU。
- Windows：双击 `scripts\check_windows.bat` 自检；双击 `scripts\study_windows.bat` 生成论文预实验 JSON。
- Linux/macOS：`sh scripts/check.sh`；`sh scripts/study.sh`。

通用命令：

```bash
python scripts/check.py --no-race
python -m gameshield.study --out results/pilot.json
```

## 看哪里

- `gateway/`：Go 本地可信模拟工具，认证、服务端来源绑定、撤权、幂等执行。
- `gameshield/`：Python 合成对手、附加检查预算策略与离线评测。
- `tests/`：行为测试；`scripts/demo.py`：真实 Go HTTP 联动。
- `results/pilot.json`：固定随机种子的合成实验样例。
- `docs/TROUBLESHOOTING.md`：常见问题；`docs/DEBUG_INDEX.md`：逐文件排错。

**注意**：Go 只允许回环地址、模拟身份和模拟票据，重启后内存状态清空；Python 研究实验和 Go 执行器是两条独立路径。二者都**不应接真实资产/生产账户**。完整局限见 `docs/QUALITY.md`。
