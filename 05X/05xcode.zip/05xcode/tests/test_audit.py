import sqlite3
import tempfile
import unittest
from pathlib import Path
from gameshield.audit import Audit


class TestAudit(unittest.TestCase):
    def test_chain_and_tampering(self):
        with tempfile.TemporaryDirectory() as temp:
            db=Path(temp)/"audit.sqlite"
            with Audit(db) as a:
                a.append({"event_id":"one","decision":"block","cost":1})
                a.append({"event_id":"two","decision":"execute","cost":0})
                self.assertTrue(a.verify())
            with sqlite3.connect(db) as c:
                c.execute("UPDATE events SET record=? WHERE id=1",('{"decision":"fake"}',))
            with Audit(db) as a:
                self.assertFalse(a.verify())

    def test_allowlist_rejects_secrets(self):
        with Audit(":memory:") as a:
            with self.assertRaises(ValueError):
                a.append({"api_key":"secret"})
