import unittest
from gameshield.study import run_episode, study


class TestStudy(unittest.TestCase):
    def test_repeatable_except_no_clock_use(self):
        self.assertEqual(run_episode(7,"switch","game",90,120),run_episode(7,"switch","game",90,120))

    def test_strict_budget_all_policies(self):
        for name in ("no_extra","all_stop","fixed_light","fixed_deep","random","threshold","bandit","game","game_no_mix","game_no_drift"):
            result=run_episode(9,"cycle",name,100,25)
            self.assertLessEqual(result["spent"],25)
            self.assertGreaterEqual(result["spent"],0)
            self.assertEqual(result["hard_policy_violations"],0)

    def test_benign_and_attack_distinct_metrics(self):
        result=run_episode(19,"static","no_extra",100,0)
        self.assertGreater(result["permitted_attack_attempts"],0)
        self.assertLessEqual(result["verified_synthetic_attack_effects"],result["permitted_attack_attempts"])
        self.assertGreaterEqual(result["false_blocks"],0)
        self.assertGreaterEqual(result["alerts"],0)

    def test_all_stop_safe_but_not_useful(self):
        result=run_episode(19,"static","all_stop",100,0)
        self.assertEqual(result["verified_synthetic_attack_effects"],0)
        self.assertEqual(result["benign_success"],0)

    def test_matrix_counts(self):
        s=study([1,2],30,35,["static","reactive"],["fixed_light","game"])
        self.assertEqual(len(s["runs"]),8)
        self.assertEqual(len(s["summary"]),4)

    def test_no_leak_of_hidden_label_in_audit(self):
        record=run_episode(21,"reactive","game",40,60)
        for row in record["audit"]:
            self.assertNotIn("attack_kind",row)
            self.assertNotIn("ground_truth",row)

    def test_invalid_scenario(self):
        with self.assertRaises(ValueError):
            run_episode(1,"nonexistent","game",20,40)

    def test_no_requests(self):
        with self.assertRaises(ValueError):
            run_episode(1,"static","game",0,0)
