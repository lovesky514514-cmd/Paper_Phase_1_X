import unittest
from gameshield.model import Observation, hard_permit
from gameshield.threats import check_detects, make_attempt


class TestThreats(unittest.TestCase):
    def test_deterministic_fixture(self):
        self.assertEqual(make_attempt(7, 10, "cycle"),make_attempt(7, 10, "cycle"))

    def test_attempt_ground_truth_not_observed(self):
        a=make_attempt(7, 5, "switch")
        self.assertFalse(hasattr(a.view, "attack_kind"))

    def test_no_external_payloads(self):
        for i in range(120):
            a=make_attempt(7, i, "reactive", 3)
            self.assertNotIn("http", a.view.event_id)
            self.assertIn(a.attack_kind,("benign","indirect","metadata","memory","combo"))

    def test_source_and_user_bound(self):
        good=Observation("x","alice","sandbox/tickets","user-approved",.2,.1)
        self.assertTrue(hard_permit(good))
        self.assertFalse(hard_permit(Observation("x","mallory","sandbox/tickets","user-approved",.2,.1)))
        self.assertFalse(hard_permit(Observation("x","alice","sandbox/tickets","external-note",.2,.1)))

    def test_skip_does_not_inspect(self):
        for i in range(20):
            self.assertFalse(check_detects(1,make_attempt(5,i,"static"),"skip"))
