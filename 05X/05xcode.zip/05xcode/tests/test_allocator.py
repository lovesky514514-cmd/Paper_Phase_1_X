"""Test observable allocation behavior, not a particular implementation detail."""
import unittest
from gameshield.allocator import Allocator, POLICIES
from gameshield.model import Observation


def view(risk=.5):
    return Observation("one", "alice", "sandbox/tickets", "user-approved", risk, .2)


class TestAllocator(unittest.TestCase):
    def test_all_policies_exist(self):
        self.assertGreaterEqual(len(POLICIES), 8)
        for policy in POLICIES:
            self.assertIsInstance(Allocator(policy, 10, 3).choose(view()), str)

    def test_missing_signal_requires_evidence_or_stop(self):
        self.assertEqual(Allocator("no_extra", 0, 1).choose(view(None)), "stop")
        self.assertEqual(Allocator("no_extra", 4, 1).choose(view(None)), "deep")

    def test_budget_never_negative(self):
        for policy in POLICIES:
            a=Allocator(policy, 8, 3)
            for _ in range(40):
                check=a.choose(view(.8))
                if check != "stop":
                    a.charge(check)
                    if check != "review":
                        a.observe(check, False)
            self.assertGreaterEqual(a.remaining, 0)

    def test_charge_fails_closed(self):
        a=Allocator("fixed_deep", 1, 2)
        with self.assertRaises(ValueError):
            a.charge("deep")

    def test_seeded_mixed_strategy(self):
        def trace():
            a=Allocator("game", 1000, 11)
            return [a.choose(view(.66)) for _ in range(40)]
        self.assertEqual(trace(), trace())

    def test_invalid_config(self):
        with self.assertRaises(ValueError):
            Allocator("bogus", 2, 2)
        with self.assertRaises(ValueError):
            Allocator("game", -1, 2)
