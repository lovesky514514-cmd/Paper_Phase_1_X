package main

import (
	"crypto/subtle"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"strings"
	"time"

	"gameshield/gateway/guard"
)

func authorized(r *http.Request, key string) bool {
	received := strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer ")
	return len(received) == len(key) && subtle.ConstantTimeCompare([]byte(received), []byte(key)) == 1
}
func jsonResponse(w http.ResponseWriter, status int, value any) {
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(value)
}
func handler(g *guard.Guard, clientToken, adminToken string) http.Handler {
	m := http.NewServeMux()
	m.HandleFunc("GET /health", func(w http.ResponseWriter, r *http.Request) {
		jsonResponse(w, 200, map[string]string{"status": "ok", "mode": "local-sandbox"})
	})
	m.HandleFunc("POST /v1/execute", func(w http.ResponseWriter, r *http.Request) {
		if !authorized(r, clientToken) {
			jsonResponse(w, 401, map[string]string{"error": "unauthorized_client"})
			return
		}
		r.Body = http.MaxBytesReader(w, r.Body, 4096)
		defer r.Body.Close()
		var c guard.Call
		d := json.NewDecoder(r.Body)
		d.DisallowUnknownFields()
		if err := d.Decode(&c); err != nil {
			jsonResponse(w, 400, map[string]string{"error": "invalid_json"})
			return
		}
		if err := d.Decode(new(any)); err != io.EOF {
			jsonResponse(w, 400, map[string]string{"error": "trailing_content"})
			return
		}
		result := g.Execute(c)
		status := 200
		if result.Decision != "execute" {
			status = 403
		}
		if result.Replayed {
			status = 200
		}
		jsonResponse(w, status, result)
	})
	m.HandleFunc("POST /v1/revoke", func(w http.ResponseWriter, r *http.Request) {
		if !authorized(r, adminToken) {
			jsonResponse(w, 401, map[string]string{"error": "unauthorized_admin"})
			return
		}
		jsonResponse(w, 200, map[string]int{"policy_version": g.Revoke()})
	})
	m.HandleFunc("GET /v1/state", func(w http.ResponseWriter, r *http.Request) {
		if !authorized(r, adminToken) {
			jsonResponse(w, 401, map[string]string{"error": "unauthorized_admin"})
			return
		}
		jsonResponse(w, 200, map[string]int{"effects": g.Count()})
	})
	return m
}
func main() {
	clientToken := os.Getenv("GAMESHIELD_CLIENT_TOKEN")
	adminToken := os.Getenv("GAMESHIELD_ADMIN_TOKEN")
	if len(clientToken) < 24 || len(adminToken) < 24 || clientToken == adminToken {
		log.Fatal(guard.ErrMissingToken)
	}
	addr := os.Getenv("GAMESHIELD_ADDR")
	if addr == "" {
		addr = "127.0.0.1:8765"
	}
	if !strings.HasPrefix(addr, "127.0.0.1:") {
		log.Fatal("local sandbox must bind 127.0.0.1")
	}
	server := &http.Server{Addr: addr, Handler: handler(guard.New(), clientToken, adminToken), ReadHeaderTimeout: 4 * time.Second, ReadTimeout: 5 * time.Second, WriteTimeout: 5 * time.Second}
	fmt.Println("GameShield local sandbox on", addr)
	log.Fatal(server.ListenAndServe())
}
