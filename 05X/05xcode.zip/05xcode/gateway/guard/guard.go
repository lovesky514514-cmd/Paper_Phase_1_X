package guard

import (
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"strings"
	"sync"
)

// Call carries an untrusted request. SourceID identifies a trusted server-side provenance record.
type Call struct {
	RequestID string `json:"request_id"`
	Principal string `json:"principal"`
	Tool      string `json:"tool"`
	Resource  string `json:"resource"`
	SourceID  string `json:"source_id"`
	Text      string `json:"text"`
}

type Receipt struct {
	Decision     string `json:"decision"`
	Reason       string `json:"reason"`
	EventID      int    `json:"event_id"`
	GrantVersion int    `json:"grant_version"`
	Replayed     bool   `json:"replayed"`
}

type grant struct {
	principal, tool, resource string
	version                   int
	enabled                   bool
}

type remembered struct {
	fingerprint string
	receipt     Receipt
}

// Guard owns policy, idempotency and mock effects behind one lock.
// For a real remote backend, the policy check must move into the backend's transaction.
type Guard struct {
	mu         sync.Mutex
	grant      grant
	provenance map[string]string
	seen       map[string]remembered
	events     []Call
}

func New() *Guard {
	return &Guard{
		grant:      grant{principal: "alice", tool: "sim.ticket.create", resource: "sandbox/tickets", version: 1, enabled: true},
		provenance: map[string]string{"user-approved": "synthetic ticket", "user-approved-alt": "alternative ticket", "external-note": "untrusted synthetic text"},
		seen:       make(map[string]remembered),
	}
}

func canonical(s string) bool {
	if len(s) == 0 || len(s) > 96 || strings.TrimSpace(s) != s {
		return false
	}
	for _, r := range s {
		if !((r >= 'a' && r <= 'z') || (r >= '0' && r <= '9') || r == '-' || r == '_' || r == '.' || r == '/') {
			return false
		}
	}
	return !strings.Contains(s, "//") && !strings.Contains(s, "..")
}

func fingerprint(c Call) string {
	sum := sha256.Sum256([]byte(c.Principal + "\x00" + c.Tool + "\x00" + c.Resource + "\x00" + c.SourceID + "\x00" + c.Text))
	return hex.EncodeToString(sum[:])
}

// Execute rechecks current authorization before returning a previously saved result.
// The result never authorizes another side effect, even if a request is retried concurrently.
func (g *Guard) Execute(c Call) Receipt {
	g.mu.Lock()
	defer g.mu.Unlock()
	out := Receipt{Decision: "deny", GrantVersion: g.grant.version}
	if !canonical(c.Principal) || !canonical(c.Tool) || !canonical(c.Resource) || !canonical(c.RequestID) || !canonical(c.SourceID) || len(c.Text) > 1024 {
		out.Reason = "invalid_request"
		return out
	}
	if !g.grant.enabled || g.grant.principal != c.Principal || g.grant.tool != c.Tool || g.grant.resource != c.Resource {
		out.Reason = "not_authorized"
		return out
	}
	registeredContent, ok := g.provenance[c.SourceID]
	if !ok || c.Text != registeredContent || (c.SourceID != "user-approved" && c.SourceID != "user-approved-alt") {
		out.Reason = "untrusted_provenance"
		return out
	}
	key := c.Principal + "/" + c.RequestID
	sum := fingerprint(c)
	if prev, exists := g.seen[key]; exists {
		if prev.fingerprint != sum {
			out.Reason = "idempotency_conflict"
			return out
		}
		replay := prev.receipt
		replay.Replayed = true
		return replay
	}
	g.events = append(g.events, c)
	out = Receipt{Decision: "execute", Reason: "committed_in_memory", EventID: len(g.events), GrantVersion: g.grant.version}
	g.seen[key] = remembered{fingerprint: sum, receipt: out}
	return out
}

// Revoke shares the same linearization lock as Execute. Already committed effects remain.
func (g *Guard) Revoke() int {
	g.mu.Lock()
	defer g.mu.Unlock()
	g.grant.version++
	g.grant.enabled = false
	return g.grant.version
}
func (g *Guard) Count() int { g.mu.Lock(); defer g.mu.Unlock(); return len(g.events) }

var ErrMissingToken = errors.New("GAMESHIELD_CLIENT_TOKEN and GAMESHIELD_ADMIN_TOKEN must be set")
