package guard

import (
	"fmt"
	"sync"
	"testing"
)

func good(id string) Call {
	return Call{RequestID: id, Principal: "alice", Tool: "sim.ticket.create", Resource: "sandbox/tickets", SourceID: "user-approved", Text: "synthetic ticket"}
}
func TestPermit(t *testing.T) {
	g := New()
	r := g.Execute(good("task-1"))
	if r.Decision != "execute" || g.Count() != 1 {
		t.Fatal(r)
	}
	if r := g.Execute(Call{RequestID: "x", Principal: "bob", Tool: "sim.ticket.create", Resource: "sandbox/tickets", SourceID: "user-approved"}); r.Decision != "deny" {
		t.Fatal(r)
	}
}
func TestUntrustedSourceAndTraversal(t *testing.T) {
	g := New()
	c := good("x")
	c.SourceID = "external-note"
	if r := g.Execute(c); r.Reason != "untrusted_provenance" {
		t.Fatal(r)
	}
	c = good("x")
	c.Resource = "sandbox/../tickets"
	if r := g.Execute(c); r.Reason != "invalid_request" {
		t.Fatal(r)
	}
	c = good("fake-source")
	c.Text = "malicious with trusted source id"
	if r := g.Execute(c); r.Decision != "deny" {
		t.Fatal(r)
	}
	if g.Count() != 0 {
		t.Fatal("unexpected effect")
	}
}
func TestReplayAndConflict(t *testing.T) {
	g := New()
	first := g.Execute(good("a"))
	again := g.Execute(good("a"))
	if first.EventID != again.EventID || !again.Replayed || g.Count() != 1 {
		t.Fatal(first, again)
	}
	c := good("a")
	c.SourceID = "user-approved-alt"
	c.Text = "alternative ticket"
	if r := g.Execute(c); r.Reason != "idempotency_conflict" {
		t.Fatal(r)
	}
}
func TestConcurrentReplay(t *testing.T) {
	g := New()
	var wg sync.WaitGroup
	for i := 0; i < 64; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			r := g.Execute(good("same"))
			if r.Decision != "execute" {
				t.Error(r)
			}
		}()
	}
	wg.Wait()
	if got := g.Count(); got != 1 {
		t.Fatalf("effects=%d", got)
	}
}
func TestRevocation(t *testing.T) {
	g := New()
	g.Execute(good("old"))
	g.Revoke()
	for i := 0; i < 10; i++ {
		r := g.Execute(good(fmt.Sprintf("new-%d", i)))
		if r.Decision != "deny" {
			t.Fatal(r)
		}
	}
	if r := g.Execute(good("old")); r.Decision != "deny" {
		t.Fatal("revoked replay disclosed", r)
	}
	if g.Count() != 1 {
		t.Fatal("side effect after revocation")
	}
}
func TestRevokeRace(t *testing.T) {
	g := New()
	var wg sync.WaitGroup
	for i := 0; i < 32; i++ {
		wg.Add(1)
		go func(n int) { defer wg.Done(); g.Execute(good(fmt.Sprintf("k-%d", n))) }(i)
	}
	wg.Add(1)
	go func() { defer wg.Done(); g.Revoke() }()
	wg.Wait()
	before := g.Count()
	for i := 0; i < 50; i++ {
		g.Execute(good(fmt.Sprintf("after-%d", i)))
	}
	if g.Count() != before {
		t.Fatal("new effects after revoke")
	}
}
