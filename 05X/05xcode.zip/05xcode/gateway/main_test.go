package main

import (
	"gameshield/gateway/guard"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestHTTPAuthAndCommit(t *testing.T) {
	h := handler(guard.New(), strings.Repeat("c", 32), strings.Repeat("a", 32))
	body := `{"request_id":"r1","principal":"alice","tool":"sim.ticket.create","resource":"sandbox/tickets","source_id":"user-approved","text":"synthetic ticket"}`
	req := httptest.NewRequest("POST", "/v1/execute", strings.NewReader(body))
	r := httptest.NewRecorder()
	h.ServeHTTP(r, req)
	if r.Code != 401 {
		t.Fatal(r.Code)
	}
	req = httptest.NewRequest("POST", "/v1/execute", strings.NewReader(body))
	req.Header.Set("Authorization", "Bearer "+strings.Repeat("c", 32))
	r = httptest.NewRecorder()
	h.ServeHTTP(r, req)
	if r.Code != 200 {
		t.Fatal(r.Code, r.Body.String())
	}
	req = httptest.NewRequest("POST", "/v1/revoke", nil)
	req.Header.Set("Authorization", "Bearer "+strings.Repeat("a", 32))
	r = httptest.NewRecorder()
	h.ServeHTTP(r, req)
	if r.Code != 200 {
		t.Fatal(r.Code)
	}
	req = httptest.NewRequest("POST", "/v1/execute", strings.NewReader(body))
	req.Header.Set("Authorization", "Bearer "+strings.Repeat("c", 32))
	r = httptest.NewRecorder()
	h.ServeHTTP(r, req)
	if r.Code != 403 {
		t.Fatal(r.Code)
	}
}
