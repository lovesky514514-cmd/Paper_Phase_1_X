module gameshield/gateway

go 1.22
