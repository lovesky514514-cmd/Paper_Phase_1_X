"""GameShield research prototype: synthetic experiments, not production authorization."""
