"""Words shared by the generator, allocator and independent scorer."""
from __future__ import annotations
from dataclasses import dataclass

DEPTHS = ("skip", "light", "flow", "deep")
COST = {"skip": 0, "light": 1, "flow": 2, "deep": 4, "review": 6}
LATENCY = {"skip": 0, "light": 2, "flow": 5, "deep": 11, "review": 25}


@dataclass(frozen=True)
class Observation:
    event_id: str
    principal: str
    resource: str
    source_id: str
    risk_signal: float | None
    queue_pressure: float


@dataclass(frozen=True)
class Attempt:
    """Ground truth is deliberately not a member of Observation."""
    view: Observation
    attack_kind: str  # Synthetic oracle only. Must not reach the allocator.


def hard_permit(view: Observation) -> bool:
    """Offline approximation of Go's reference monitor, not the production authority."""
    return (view.principal == "alice" and view.resource == "sandbox/tickets"
            and view.source_id == "user-approved")
