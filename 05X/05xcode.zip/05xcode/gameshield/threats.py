"""Harmless marker-based attack families and reproducible nonstationary streams."""
from __future__ import annotations
import hashlib
from .model import Attempt, Observation

ATTACKS = ("indirect", "metadata", "memory", "combo")
ALL_KINDS = ("benign",) + ATTACKS


def coin(seed: int, event: str, salt: str) -> float:
    """Stable counter-based randomness keeps paired strategies comparable."""
    digest = hashlib.sha256(f"{seed}/{event}/{salt}".encode()).digest()
    return int.from_bytes(digest[:8], "big") / 2**64


def make_attempt(seed: int, index: int, scenario: str, prior_rejections: int = 0) -> Attempt:
    """The reactive attacker only sees a public rejection count, never policy internals."""
    if scenario not in ("static", "switch", "cycle", "reactive"):
        raise ValueError(f"unknown scenario {scenario}")
    p = coin(seed, str(index), "attack")
    kind = "benign"
    if p < 0.40:
        if scenario == "switch":
            active = "indirect" if index < 60 else "combo"
        elif scenario == "cycle":
            active = ATTACKS[(index // 30) % 4]
        elif scenario == "reactive":
            active = "metadata" if prior_rejections < (index // 8) else "memory"
        else:
            active = ATTACKS[index % 4]
        kind = active
    # Features are observable but noisy; no exact attack labels leak into them.
    signal = 0.10 + 0.55 * coin(seed, str(index), "signal")
    if kind != "benign":
        signal += 0.18 if kind in ("indirect", "memory") else 0.27
    signal = min(signal, 1.0)
    missing = coin(seed, str(index), "missing") < 0.04
    # A fraction of requests are denied by the deterministic policy regardless of check.
    forbidden = coin(seed, str(index), "forbidden") < 0.10
    untrusted = not forbidden and coin(seed, str(index), "untrusted") < 0.08
    view = Observation(
        event_id=f"s{seed}-e{index}",
        principal="mallory" if forbidden else "alice",
        resource="sandbox/tickets",
        source_id="external-note" if untrusted else "user-approved",
        risk_signal=None if missing else round(signal, 4),
        queue_pressure=round(coin(seed, str(index), "queue"), 3),
    )
    return Attempt(view=view, attack_kind=kind)


# Probabilities intentionally differ by attack type; this is a mock detector, not a learned model.
DETECTION = {
    "light": {"benign": .06, "indirect": .65, "metadata": .30, "memory": .18, "combo": .40},
    "flow": {"benign": .09, "indirect": .43, "metadata": .80, "memory": .50, "combo": .67},
    "deep": {"benign": .03, "indirect": .91, "metadata": .88, "memory": .84, "combo": .92},
}


def check_detects(seed: int, attempt: Attempt, check: str) -> bool:
    if check == "skip":
        return False
    return coin(seed, attempt.view.event_id, f"detector:{check}") < DETECTION[check][attempt.attack_kind]
