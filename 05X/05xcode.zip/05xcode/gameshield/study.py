"""Paired synthetic study with an oracle hidden from the allocator."""
from __future__ import annotations
import argparse
import json
import statistics
from pathlib import Path
from .allocator import Allocator, POLICIES
from .audit import Audit
from .model import COST, LATENCY, hard_permit
from .threats import check_detects, make_attempt


def percentile(values: list[int], quantile: float) -> float:
    ordered = sorted(values)
    return float(ordered[max(0, min(len(ordered)-1, int((len(ordered)-1)*quantile)))])


def run_episode(seed: int, scenario: str, policy: str, count: int, budget: int) -> dict:
    if count < 1:
        raise ValueError("count must be positive")
    allocator = Allocator(policy, budget, seed + 901)
    total_attack = harm = benign = authorized_benign = benign_success = false_blocks = forbidden = violations = 0
    alert_count = rejection_count = 0
    latencies: list[int] = []
    rows: list[dict] = []
    for index in range(count):
        attempt = make_attempt(seed, index, scenario, rejection_count)
        view = attempt.view
        attack = attempt.attack_kind != "benign"  # Ground truth: used *only* by scorer.
        benign += not attack
        if not hard_permit(view):
            forbidden += 1
            rejection_count += 1
            rows.append({"event": view.event_id, "decision": "hard_deny", "check": "none", "cost": 0})
            latencies.append(2)
            continue
        total_attack += attack
        authorized_benign += not attack
        check = allocator.choose(view)
        if check in ("stop", "review"):
            if check == "review":
                allocator.charge(check)
            if not attack:
                false_blocks += 1
            rejection_count += 1
            latencies.append(5 + LATENCY.get(check, 0))
            rows.append({"event": view.event_id, "decision": "escalate", "check": check, "cost": COST.get(check, 0)})
            continue
        cost = allocator.charge(check)
        flagged = check_detects(seed, attempt, check)
        if check != "skip":
            allocator.observe(check, flagged)
        alert_count += int(flagged)
        if flagged:
            if not attack:
                false_blocks += 1
            rejection_count += 1
        else:
            if not hard_permit(view):
                violations += 1
            if attack:
                harm += 1  # Simulated attack effect; this is not a Go or external write.
            else:
                benign_success += 1
        lat = 5 + LATENCY[check] + round(view.queue_pressure * 4)
        latencies.append(lat)
        rows.append({"event":view.event_id,"decision":"block" if flagged else "simulated_execute", "check":check,"cost":cost})
    spent = budget - allocator.remaining
    # The hard gate is checked before every simulated effect; forbidden paths never execute.
    return {
        "policy": policy, "seed": seed, "scenario": scenario, "requests": count,
        "permitted_attack_attempts": total_attack, "verified_synthetic_attack_effects": harm,
        "vasr": round(harm / total_attack, 4) if total_attack else None,
        "benign": benign, "authorized_benign": authorized_benign,
        "benign_success": benign_success,
        "benign_success_rate": round(benign_success / authorized_benign, 4) if authorized_benign else None,
        "false_block_rate": round(false_blocks / authorized_benign, 4) if authorized_benign else None,
        "false_blocks": false_blocks, "hard_denied": forbidden,
        "hard_policy_violations": violations,
        "alerts": alert_count, "escalations": sum(r["decision"]=="escalate" for r in rows),
        "budget": budget, "spent": spent, "p50_latency_units": percentile(latencies,.50),
        "p95_latency_units": percentile(latencies,.95),
        "audit": rows,
    }


def study(seeds: list[int], count: int, budget: int, scenarios: list[str], policies: list[str]) -> dict:
    results = [run_episode(seed, scenario, policy, count, budget)
               for scenario in scenarios for seed in seeds for policy in policies]
    summary = []
    for scenario in scenarios:
        for policy in policies:
            group = [r for r in results if r["scenario"]==scenario and r["policy"]==policy]
            summary.append({
                "scenario":scenario, "policy":policy, "runs":len(group),
                "vasr_mean":round(statistics.mean(r["vasr"] or 0 for r in group),4),
                "benign_success_mean":round(statistics.mean(r["benign_success_rate"] or 0 for r in group),4),
                "spent_mean":round(statistics.mean(r["spent"] for r in group),2),
                "p95_latency_units_mean":round(statistics.mean(r["p95_latency_units"] for r in group),2),
                "hard_policy_violations":sum(r["hard_policy_violations"] for r in group),
            })
    return {"scope":"synthetic offline simulator, not real MCP, not security guarantee",
            "detector_units":"synthetic cost and latency units, not CPU milliseconds or USD",
            "settings":{"seeds":seeds,"count":count,"budget":budget,"scenarios":scenarios,"policies":policies},
            "summary":summary,"runs":results}


def main() -> None:
    p=argparse.ArgumentParser(description="Compare budgeted defense strategies in a synthetic sandbox")
    p.add_argument("--count",type=int,default=100)
    p.add_argument("--seeds",default="7,19,41,73,101")
    p.add_argument("--budget",type=int,default=145)
    p.add_argument("--out",default="results/pilot.json")
    p.add_argument("--audit-db",help="optional SQLite hash-chained, redacted audit receipt database")
    args=p.parse_args()
    result=study([int(s) for s in args.seeds.split(",")],args.count,args.budget,
                 ["static","switch","cycle","reactive"], list(POLICIES))
    dst=Path(args.out);dst.parent.mkdir(parents=True,exist_ok=True)
    dst.write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    if args.audit_db:
        with Audit(args.audit_db) as audit:
            for run in result["runs"]:
                for event in run["audit"]:
                    audit.append({"event_id":event["event"],"policy":run["policy"],
                                  "decision":event["decision"], "check":event["check"],
                                  "cost":event["cost"],"grant_version":1})
            if not audit.verify():
                raise RuntimeError("audit chain verification failed")
    print(f"Wrote {len(result['runs'])} paired offline experiments to {dst}")
    for row in result["summary"]:
        if row["scenario"]=="reactive" and row["policy"] in ("fixed_light","bandit","game"):
            print(row)

if __name__ == "__main__":
    main()
