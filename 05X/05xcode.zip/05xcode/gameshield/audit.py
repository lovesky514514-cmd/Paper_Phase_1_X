"""Append-only local experiment receipts (audit evidence, not tamper-proof logging)."""
from __future__ import annotations
import hashlib
import json
import sqlite3
from pathlib import Path


class Audit:
    def __init__(self, path: str | Path):
        self.connection = sqlite3.connect(str(path))
        self.connection.execute("CREATE TABLE IF NOT EXISTS events (id INTEGER PRIMARY KEY, digest TEXT NOT NULL, prev_digest TEXT NOT NULL, record TEXT NOT NULL)")
        self.connection.commit()

    def append(self, record: dict) -> str:
        # Do not persist raw user data or authentication credentials.
        if set(record) - {"event_id", "policy", "decision", "check", "cost", "grant_version"}:
            raise ValueError("record contains fields outside the allowlist")
        payload=json.dumps(record,ensure_ascii=False,sort_keys=True,separators=(",",":"))
        with self.connection:
            previous=self.connection.execute("SELECT digest FROM events ORDER BY id DESC LIMIT 1").fetchone()
            parent=previous[0] if previous else "0"*64
            digest=hashlib.sha256((parent+payload).encode()).hexdigest()
            self.connection.execute("INSERT INTO events(digest,prev_digest,record) VALUES(?,?,?)",(digest,parent,payload))
        return digest

    def verify(self) -> bool:
        parent="0"*64
        for digest, prior, payload in self.connection.execute("SELECT digest,prev_digest,record FROM events ORDER BY id"):
            if parent!=prior or hashlib.sha256((parent+payload).encode()).hexdigest()!=digest:
                return False
            parent=digest
        return True

    def close(self) -> None:
        self.connection.close()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()
