"""Budget-aware online extra-check selection. It never grants tool permissions."""
from __future__ import annotations
from collections import deque
import math
import random
from .model import Observation, DEPTHS, COST

POLICIES = ("no_extra", "all_stop", "fixed_light", "fixed_deep", "random", "threshold", "bandit", "game", "game_no_drift", "game_no_mix")


class Allocator:
    def __init__(self, policy: str, budget: int, seed: int):
        if policy not in POLICIES:
            raise ValueError(policy)
        if budget < 0:
            raise ValueError("budget must be nonnegative")
        self.policy = policy
        self.remaining = budget
        self.rng = random.Random(seed)
        self.history: deque[tuple[str, bool, int]] = deque(maxlen=40)
        self.stats = {name: [0, 0.0] for name in DEPTHS}
        self.last_check = "skip"

    def _pick_bandit(self, risk: float) -> str:
        total = 1 + sum(x[0] for x in self.stats.values())
        scores = {}
        for name in DEPTHS:
            n, reward = self.stats[name]
            # Prior encourages checking risky calls without treating risk as a safety proof.
            prior = risk * {"skip": -1, "light": 1.8, "flow": 2.2, "deep": 2.6}[name]
            exploration = 0.45 * math.sqrt(math.log(total + 1) / (n + 1))
            scores[name] = (reward / n if n else 0) + prior + exploration - COST[name] * 0.12
        return max(DEPTHS, key=lambda name: scores[name])

    def _drift(self) -> bool:
        # Detection alerts are selective feedback; this signal is heuristic, not calibrated.
        if len(self.history) < 20:
            return False
        old = list(self.history)[:20]
        new = list(self.history)[-20:]
        old_rate = sum(flag for _, flag, _ in old) / len(old)
        new_rate = sum(flag for _, flag, _ in new) / len(new)
        return new_rate - old_rate > 0.22

    def choose(self, view: Observation) -> str:
        if self.policy == "all_stop":
            return "review" if self.remaining >= COST["review"] else "stop"
        risk = view.risk_signal
        if risk is None:
            return "deep" if self.remaining >= COST["deep"] else "stop"
        if self.policy == "no_extra":
            name = "skip"
        elif self.policy == "fixed_light":
            name = "light"
        elif self.policy == "fixed_deep":
            name = "deep"
        elif self.policy == "random":
            name = self.rng.choice(DEPTHS)
        elif self.policy == "threshold":
            name = "deep" if risk > .75 else "light" if risk > .45 else "skip"
        elif self.policy == "bandit":
            name = self._pick_bandit(risk)
        else:
            name = self._pick_bandit(risk)
            if self.policy != "game_no_drift" and self._drift() and risk > .5:
                name = "deep"
            # Mixed check depths: randomness changes inspection effort, never hard authorization.
            if self.policy != "game_no_mix" and self.rng.random() < .10 and risk > .3:
                name = self.rng.choice(("light", "flow", "deep"))
            if risk > .83 and name == "skip":
                name = "deep"
        if COST[name] > self.remaining:
            # High uncertainty may not turn into an unverified permit on budget exhaustion.
            return "stop" if risk > .7 else "skip"
        return name

    def charge(self, check: str) -> int:
        cost = COST[check]
        if cost > self.remaining:
            raise ValueError("budget exceeded")
        self.remaining -= cost
        self.last_check = check
        return cost

    def observe(self, check: str, flagged: bool) -> None:
        """Only detector alerts are observable. This never consumes hidden attack_kind."""
        self.history.append((check, flagged, COST[check]))
        n, accumulated = self.stats[check]
        proxy_reward = (3.5 if flagged else 0.0) - COST[check] * .25
        self.stats[check] = [n + 1, accumulated + proxy_reward]
