# 代码约定

参考提供的 Skills：codebase-design、domain-modeling、tdd、code-review、diagnosing-bugs。

- **独立边界**：Go `Guard.Execute` 拥有授权与提交；Python `Allocator.choose` 只负责花费预算、选择检查，不能改变 Go 权限。
- **薄接口**：`run_episode(seed, scenario, policy, count, budget)` 即科研入口；`Guard.Execute(call)` 即模拟写入口。
- **不可混同**：hard-deny 不是检测器拦截，simulation vASR 不是未授权工具越权率。
- **可信信息**：攻击类别只进合成 oracle；策略只能读 Observation；Go 从服务端登记内容核查来源。
- **测试行为**：守住有限预算、幂等、撤权原子性、敏感字段不入账、相同种子重复。
- **代码形式**：按责任划分模块，函数名说业务词；注释说明限制/原因，不写装饰性分隔符。
