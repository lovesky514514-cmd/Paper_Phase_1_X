# 交叉学科 SCI 研究报告 05：Agent × 网络安全 × 博弈论

> **题目建议**：**GameShield-Gate: Budget-Constrained Adaptive Security Games for Tool-Using LLM Agents with Enforced Execution Invariants**  
> 中文：**面向工具调用智能体的预算约束自适应安全博弈与执行不变量保障网关**  
> **研究状态**：选题与方案设计；**尚无算法性能结果、尚无形式化证明、尚未投稿**。  
> 文献核查时间：2026-10-20。周期/费用是检索当期快照，不是保证。  
> 研究用途：防御性系统、完全隔离的模拟工具；不在真实系统执行攻击。

## 0. 三句话结论

1. **主观点**：Agent 网关的安全策略长期公开且固定时，适应性攻击者能够根据防御反馈改变攻击方式；只封禁危险内容既可能漏防，又可能牺牲合法任务完成率。  
2. **主创新目标**：在**确定性执行授权永不让步**的前提下，用**受资源预算约束的非平稳攻防博弈**动态配置额外检测、检查深度、人工审批和延迟验证资源，同时报告可审计的安全—效用—延迟曲线。  
3. **最重要的边界**：博弈模型的风险估计不是严格安全证明。**执行硬约束由可验证的策略和网关机制执行**；统计策略只优化硬边界之外的成本/效用。

## 1. 选题背景、交叉学科价值和核心科学问题

**交叉链条**：LLM Agent 工具执行（人工智能） → API/MCP 网关（分布式后端） → 最小权限与参考监视器（网络安全） → 部分可观测重复安全博弈（博弈论） → 在线决策/排队与预算约束（运筹优化） → 形式化不变量（软件验证）。

**为何不能只做“提示注入检测”**：检测器处理输入内容；实际事故发生在 tool-call 的授权、资源解析、数据流向、撤权和外部副作用。这些都需要独立于 Agent 模型的执行边界。CaMeL、Progent、MiniScope、Fides、ShieldMCP 已经覆盖部分这一层，论文不能把“加个权限网关”作为独创。

**新问题 Q1**：工具调用的风险与攻击者策略随时间变化；如何利用少量反馈来选择额外防御，又不违反每一步确定性权限控制？  
**Q2**：如何在有限 token、CPU、验证调用、P95 延迟及人工复核预算下保证**合法任务效用**？  
**Q3**：攻击者能观察到拒绝/允许、延迟、错误响应等侧信道；策略是否因可预测性而失效？  
**Q4**：当概率模型漂移或者证据不足，是否应退回保守确定性策略，并明确哪些保证仍有效？

### 1.1 威胁模型（立项后必须冻结）

- **可信**：网关的策略引擎、服务端授权元数据、审计日志、隔离沙箱和签名化任务身份。可信的前提需要测试，不可直接假定所有插件可信。
- **潜在不可信**：工具描述、工具返回文本、检索文档、外部资源、第三方 MCP 服务、Agent 的自然语言自述。
- **攻击者能力**：可改变允许范围内的工具返回内容或工具元数据，观察部分防御结果并重复试探；不可直接修改可信网关策略或伪造根身份（那属于另一威胁模型）。
- **防守者能力**：拒绝、限制权限、内容隔离、沙箱验证、增加检查深度、人工批准、审计、终止会话。权限检查必须先于外部副作用。
- **排除**：内核 0-day、越权获得网关管理员密钥、通过不可见旁路直接调用后端，这些不在当前实验保证之内；需要在局限性中公开。

### 1.2 与第四篇、第三篇纯计算机报告的区别

- 第三篇 MCP 安全验证：侧重**静态权限组合和执行前授权正确性**。
- 本文：假定可用确定性授权底座，主要研究**攻击者适应时如何最经济地分配额外防御资源**。
- 与第五篇普通 Agent RCA：本文关注**攻防对抗及决策**，不把根因定位作为主贡献。

## 2. 候选论文题目、主创新点与可检验假设

**中文题目（首选）**：《面向工具调用智能体的自适应攻防博弈与预算约束执行保障方法》。  
**英文题目（首选）**：*GameShield-Gate: Budget-Constrained Adaptive Security Games for Tool-Using LLM Agents with Enforced Execution Invariants*。

| 层级 | 创新点候选 | 与已有研究的关系 | 必须交付的实证结果 |
|---|---|---|---|
| I，必要 | **双层决策**：确定性 allow/deny 核心 + 博弈分配额外检查资源 | Progent/Fides/CaMeL 已有前半部分，本文贡献只能是联合资源优化 | 关键不变量零违反（在测试覆盖/威胁模型内），且良性任务成功率高于全拒绝 |
| II，主要 | **受约束的非平稳对抗决策**：攻击模式漂移、预算、部分可观测 | 静态 Stackelberg、在线 bandit 和普通自适应检测均已存在 | 多个漂移强度、多个攻击者类型下的 Pareto 曲线、预算达标 |
| III，增强 | **防御可预测性控制**：固定策略与混合策略比较 | 经典安全博弈已有随机化，必须证明网关场景特有差异 | 已知防御机制的适应性攻击下防御退化幅度 |
| IV，增强 | **可审计风险信号与安全回退** | 运行时 shield 已存在 | 分布漂移或证据缺失时拒绝违规动作，记录弃权/升级率 |

#### H1（主要）：
在相同**硬安全策略、平均检查预算**下，相比固定高/低检查、基于风险阈值和随机检查，在线防御选择器能在攻防策略漂移时改善合法任务完成率或降低成功攻击率的联合指标。**这是待验证假设，不是已实现的提升。**

#### H2（理论目标）：
若所有敏感工具调用经不可绕过的参考监视器、授权身份与资源归一化可靠，并且检查/执行之间状态不变，则可以证明“未授权工具调用不执行”。注意授权政策是否能完整捕捉恶意目的仍是不确定的。

#### H3（稳健性）：
在攻击者具有部分防御观测和一定试探预算时，随机化资源分配优于确定性可预测方案；但对比攻击者观察到完整策略的极端情况，优势可能消失。

## 3. 研究模型与数学目标

### 3.1 决策变量

时间步 t 的**可观测上下文**：`x_t = (tool_scope, action_class, provenance_label, past_failures, remaining_budget, queue_pressure, drift_score)`。

**防御动作集合** D：`{基础策略检查、附加轻量检测、跨工具数据流检查、沙箱预测、人工审批、阻断}`。  
**攻击策略集合** A：`{正常请求、工具返回注入、工具元数据欺骗、记忆污染、授权边界试探、组合策略}`。所有攻击仅在实验模拟环境下生成无害标记，不包含对真实账号的利用。

**硬约束**：`Permit(tool, principal, resource, args, provenance, grant)`。如果结果为假，任何学习型决策器均不得改为放行。

**研究性效用函数**（不是已经求得的最优结果）：

```text
U_D = w1 * benign_task_success
    - w2 * verified_attack_success
    - w3 * detector_cost
    - w4 * latency_penalty
    - w5 * false_block_cost
```

`argmax(policy) E[sum_t U_D]`，满足 `sum_t detector_cost_t <= B`、`P95_latency <= L`（采用软约束或尾延迟监测时应区分硬 SLA 和经验约束），以及**每次执行必须满足 Permit**。攻击者效用不一定等于 `-U_D`，应视作非零和博弈并通过敏感性分析验证假设。

### 3.2 从什么算法开始

- **M0 最小原型**：启发式上下文风险评分 + 贪心预算配额 + 硬权限门；这是最便宜的可复现版，不要一开始训练 RL。
- **M1 主要算法**：滑动窗口上下文 bandit / 带预算的 primal-dual 在线分配；每个训练 episode 只调整附加检查强度，不修改核心授权策略。
- **M2 高级算法（时间允许）**：部分可观测 Stackelberg/贝叶斯攻防博弈，估计攻击者类型、观察概率、非平稳度，用限制性多策略混合控制检查配置。
- **M3 理论（可选）**：明示所需噪声、平稳性与已知损失边界，尝试推导动态 regret / 预算超限上界；**没有证明就不能写 guarantee**。

### 3.3 关键设计风险

1. **攻击检测概率不是客观事实**：需要校准、bootstrap 置信区间和跨攻击族验证。  
2. **随机化不是安全许可**：随机的是附加验证深度，不是是否允许未授权操作。  
3. **安全游戏不等于零和博弈**：双方目标和可观察信息必须具体化；不应生造“纳什均衡一定存在且可快速计算”。  
4. **反馈偏差**：被拦截的动作没有真实后果标签，存在选择性标记（selective labels）。需要沙箱回放或离线标注来降低偏差。  
5. **多步副作用**：必须记录不可逆写入、重试幂等性、审批与实际提交之间的竞态；不做这些，网关所谓“安全性”是不完整的。

## 4. 可实现的软件系统

```text
User / Agent
    |
    v
MCP / REST Adapter — canonical identity, resource, tool & args
    |
    v
Deterministic Reference Monitor — scope / grant / data-flow invariants
    |                      \-> DENY + audit (永远不可学习绕过)
    v
Context Collector — current task, provenance, queue, budget
    |
    v
Game-Theoretic Resource Allocator (研究创新主体)
    |
    +-> cheap validation    +-> independent tool/result checker
    +-> isolated sandbox    +-> human approval / escalate
    |
    v
Execution + immutable test receipt + structured audit
    |
    v
Budget & Drift Estimator (只调整未来的附加检查)
```

**工程约束**：Python 快速原型；FastAPI/Starlette 提供拦截接口，SQLite 持久化不可变事件 ID，后期高并发可以换 Go/Rust。强制声明系统只拦截已接入工具，**对内部偷偷发起的网络调用不提供任何保证**。生产级声明需结合出站网络隔离、容器沙箱与服务端权限。

## 5. 八个可选交叉子课题（从易到难）

| 交叉领域 | 具体方向 | 算法突破 | 主要实验 | 难度 |
|---|---|---|---|---|
| 博弈论 × API 安全 | 多租户 Agent 受预算对抗防御 | 混合策略与不公平损失约束 | 租户差异、P95、误封率 | 中 |
| 运筹学 × 网络安全 | 验证预算背包问题 | 在线 primal-dual 分配 | 预算超限、任务收益 | 中 |
| 控制理论 × 网络安全 | 风险反馈与自适应检查频率 | 稳定性/振荡控制 | 阶跃攻击负载、漂移恢复 | 中高 |
| 信息论 × 网络安全 | 攻击者防御策略推断 | 可观测性降低与随机化 | 攻击者推断精度 | 高 |
| 因果推断 × 检测 | 策略改变是否导致攻击降低 | 随机化干预/反事实 | 匹配任务上的实验对照 | 高 |
| 软件工程 × 形式化方法 | 网关执行不可越权不变量 | reference monitor + 性质测试 | 授权与撤权、TOCTOU | 中 |
| 经济学 × 计算 | 不完全信息 Stackelberg 博弈 | 类型分布漂移与鲁棒最优化 | 误设先验条件下表现 | 高 |
| 人机交互 × 安全 | 人工审批预算及疲劳 | 最优升级策略 | 审批负担/决策准确率 | 中 |

**学弟优先切入**：`预算背包 + 动态检测选择 + 强制最小权限`。有数学/控制合作方再扩展非平稳博弈理论，不要同时开八个课题。

## 6. 与最接近论文逐篇对比（避免撞题）

| 相近工作 | 已解决什么 | 不能声称首次提出 | 本文须真正回答的问题 |
|---|---|---|---|
| ShieldMCP（2026） | MCP 工具层运行时防护 | 第一个 MCP 防护网关 | 固定网关与动态预算分配的可验证收益 |
| CaMeL（2025） | 以能力与数据控制流防护注入 | 用 capability 保护 Agent | 对外加验证成本如何分配 |
| Progent（2025） | 可编程最小权限与自适应政策生成 | 最小权限/动态权限本身 | 持续对抗、预算下的防御效用 |
| MiniScope（2025） | 自动化工具调用最小授权 | 工具 scope 约束 | 固定授权上层的额外检查资源 |
| Fides（2025） | 确定性信息流控制 | 污点传播和防护 | 欠预算检测如何优化，同时不破坏 Fides 基线 |
| CM-PIUG（2026） | 跨模态注入建模 + Stackelberg 防御 | Stackelberg + 注入首次结合 | 面向 MCP **实际执行**、非平稳策略/多租户预算的创新 |
| Han & Zhu（2025） | jailbreak 攻防动态博弈 | 第一个智能体安全博弈 | 多工具执行授权和成本约束 |
| AgentDojo（2024） | 动态攻击测试基准 | 第一个攻防测试集 | 新的动态/适应性评测协议与网关机制 |
| ASB（2025） | 多阶段攻击/防御测试 | 多攻击族结合 | 防御耗费、误封、长时间漂移 |
| 2026 自适应外部防御评测 | 警告静态基准高估稳健性 | 首次要求自适应攻击验证 | 强攻击者协议下确实提升 |

**发表必要条件**：至少与 3 种工具执行权限基线 + 3 种资源选择基线进行公平对照；如果只有一套提示检测器的消融，就更像工程总结而非高水平算法论文。

## 7. 数据、公开基准与故障注入设计

### 7.1 数据资源

| 资源 | 用途 | 限制及复现提示 |
|---|---|---|
| [AgentDojo](https://github.com/ethz-spylab/agentdojo) | 工具返回注入 + 合法任务 | 原始基准与扩展攻击均保存，不得混合训练/测试 |
| [ASB](https://github.com/agiresearch/ASB) | 多阶段攻击与良性任务 | 部分工具是模拟，不能宣称真实服务安全 |
| [MCPTox](https://ojs.aaai.org/index.php/AAAI/article/view/40895) | MCP 工具元数据风险 | 核对原作者数据许可及复现指引 |
| [BIPIA](https://github.com/microsoft/BIPIA) | 间接注入类别扩展 | 主体不全是工具执行，不能代替 MCP 结果 |
| [ToolEmu](https://github.com/ryoungj/ToolEmu) | 虚拟工具行为/后果 | 模拟器可能与真实工具行为不一致 |
| [CybORG](https://arxiv.org/abs/2002.10667) | 攻防博弈外部效度 | 网络攻击 Gym 与 MCP 网关场景不同，应单独报告 |

### 7.2 合成但可审计的动态场景

- **静态场景**：攻击分布不变；检验学习开销是否白费。
- **突变场景**：测试中途攻击者从低风险工具转向高敏感操作，比较适应速度。
- **周期漂移**：攻击者在 2–3 种攻击类别之间循环，以检验追踪策略是否过拟合。
- **反应型攻击者**：根据最近 N 次拒绝/延迟选择下一回合攻击类别；允许观察的量由威胁模型固定。
- **双重约束**：高峰队列下 `CPU budget + P95 latency + human approval` 同时受限。
- **正常请求反例**：有很多和恶意内容相似但合法的任务，防止通过全拒绝虚假提高安全分。

**安全要求**：所有测试目标均使用合成身份、沙箱 API、假数据、无害 marker，禁止真实目标资产或生产账户被攻击；默认关闭外部写入。**反应型攻击者可以先用离散策略生成器实现，不需要生成真实恶意载荷**。

### 7.3 样本划分与统计

建议首轮用 **100 个合法任务 × 4 种攻击情境 × 5 个随机种子** 的配置验证脚本可复现性；这只是工程启动规模，不是统计效能保证。正式论文应按攻击族、工具类型、时间窗口、租户类型留出 OOD 集，并报告置信区间。每个模型的 token 费用、检测器运行时间、硬件、seed 与缓存设置必须统一。

## 8. 评价指标和消融实验（SCI 必备）

**绝不可只报告 ASR。** 至少报告：

1. `Verified Attack Success Rate (vASR)`：在隔离工具内，检测到实际越权效果才计成功；文本声称成功不算。
2. `Authorized-Tool-Invocation Violation`：真实执行违反可判定 policy 的比率；零违规只在覆盖的测试与威胁模型中成立。
3. `Benign Task Success` 与误封率 `FBR`，另报告攻击存在时的合法任务效用。
4. `Cost per successful legitimate task`（token/CPU/额外验证/人工时）；适合实际网关工程。
5. `P50 / P95 / P99 end-to-end latency` 与吞吐、CPU 峰值。
6. `Dynamic Regret`（有清晰对比 oracle 时）或漂移后恢复步数。
7. `Worst-case vASR`：攻击者在预算范围内适应后的最坏表现；不能只报均值。
8. `Grant/revocation race violation` 与 side effect 重放；必须测试撤权—执行窗口。

**对照组**：无防御、全拒绝、静态权限 + 无额外检查、静态权限 + 固定轻量检测、静态权限 + 固定深度检查、Progent 或 Fides 可复现实现（需披露无法复现实验时的替代方案）、随机资源分配、风险分值阈值、普通上下文 bandit、本文方法。

**主要消融**：移除漂移检测、移除对手建模、移除随机化、移除预算、移除审计数据关联、移除可信信号校准、替换在线算法、关闭高级工具沙箱。**不允许**关闭硬安全内核后仍对外宣称同等安全保证；可以仅作为“危险失效示例”在隔离环境测试。

**统计**：每设置最少 5–10 独立种子作技术复现起点，正式样本量需功效分析；二分类率采用 Wilson/Bootstrap 区间，任务级配对比较，跨场景使用层级 bootstrap；报告 p 值与效应量而非只报显著性。

### 8.1 必须具备的论文主图

- 图 1：双层网关架构；图 2：硬安全内核状态机；图 3：预算—vASR—合法任务成功率 Pareto 面；图 4：攻击策略漂移后的时间序列；图 5：高峰流量 P95 与预算消耗；图 6：不同攻击者可观测性下的退化；图 7：撤权和不变量结果；表 1：直接竞争工作；表 2：消融与显著性。

## 9. 算法草案与基线实现路线

```python
# 概念级伪代码：需结合实际库实现，不是已测可运行程序
def defense_gateway(request, principal, budget, telemetry):
    call = canonicalize_and_authenticate(request, principal)
    if not deterministic_policy_permits(call):
        return deny_and_audit(call, reason="unauthorized")

    context = read_only_context(call, telemetry, budget)
    selected_checks = online_allocator.choose(context, max_cost=budget.remaining)
    verdict = enforce_optional_checks_in_sandbox(call, selected_checks)

    if not verdict.safe_or_approved:
        return deny_or_escalate_and_audit(call, verdict)

    # 提交前重新检查授权/撤权；真实系统需原子性或服务端授权保证
    if not deterministic_policy_permits(call):
        return deny_and_audit(call, reason="grant_changed")

    outcome = guarded_tool_execute(call)
    audit_receipt(call, selected_checks, verdict, outcome)
    update_allocator_from_verified_feedback(outcome)
    return outcome
```

**V0 一周内最小可行实现**：3–5 个沙箱工具（读取模拟档案、写入模拟票据、发送模拟消息等）、显式最小权限策略、单个混合攻击策略生成器、可控检测成本、JSONL 审计、Pytest 不变量测试。安全敏感真实服务不在 V0 中集成。

## 10. 选刊：免费优先、速度第二、适配第一

**免费定义**：首选混合出版期刊的**订阅发表（subscription/non-OA）**；通常免文章处理费 APC，但仍必须核查彩页/超页/特别版面费及单位 OA 强制要求。**不是免费开放获取，也不是不收投稿处理费的绝对承诺**。Elsevier 官方说明混合期刊订阅模式通常不收费，详见 https://www.elsevier.com/about/policies-and-standards/pricing 。

**审稿术语**：`submission to first decision` 可能是编辑初筛；`decision after review` 才是外审后决定；`submission to acceptance` 为从投稿到录用的历史统计，可能包括返修，不能看作纯审稿时长。

| 期刊 | 研究契合性 | 最新检索可得“投稿→录用”历史值 | 免 APC 路线 / 收录证据 | 应如何定位 |
|---|---|---|---|---|
| **Computers & Security (C&S)** | 极高：实际网关权限与安全实验 | **约 162 天**；首决约 2 天、外审后决定约 56 天 | Elsevier 混合期刊，可订阅发表；期刊 Insight 第三方镜像列出 SCIE，投稿前查 MJL | **主投**：强安全设计 + 自适应威胁模型 |
| **Journal of Information Security and Applications (JISA)** | 很高：应用型 Agent 安全 | **约 162 天**（二级聚合显示；与其他镜像口径冲突，可靠性中） | 有订阅期刊，Elsevier；SCIE 状态投稿前查 MJL | **务实备选**：可复现实验 + 真实服务边界 |
| **Computer Networks** | 中高：网络/API 网关流量策略 | **约 173 天**（二级整理，非官方直达） | Elsevier 混合出版通常可订阅，投稿前复核具体期刊政策 | 偏向流量、延迟、拥塞和可扩展性 |
| **Journal of Network and Computer Applications (JNCA)** | 高：跨服务 API 网关 | **约 187–194 天**（不同历史样本，非统一官方值） | Elsevier 订阅路线待该刊逐项核对 | 有多租户/网络系统真实性才推荐 |
| **Future Generation Computer Systems (FGCS)** | 中高：分布式 Agent 平台 | **约 183 天**（先前整理，需重新核实当前官方数据） | Elsevier 混合出版通常可订阅；SCIE 复核 | 系统扩展性与资源成本突出时选 |
| **International Journal of Information Security** | 高：博弈/安全建模 | **未查得可核实的统一录用周期** | Springer Hybrid 候选，具体费用/SCIE 待复核 | 理论模型扎实时选，不能宣称“快” |
| **Expert Systems with Applications (ESWA)** | 中：需要强的学习算法新意 | **约 147 天**（历史整理，投稿前复核） | Elsevier 混合出版通常可订阅；SCIE 复核 | 算法证据明显强于网关工程时才考虑 |

**重要排除**：*Security and Communication Networks* 已明确为全 OA 且有 APC，不作为零付费主投，见 https://onlinelibrary.wiley.com/page/journal/2037/homepage/open-access 。

### 10.1 投稿成本与数据可信度逐项核查清单

- [ ] 在 [Clarivate Master Journal List](https://mjl.clarivate.com/) 确认当年 **Science Citation Index Expanded (SCIE)** 收录；不要混淆 ESCI/Scopus 或仅有影响因子。  
- [ ] 查看目标期刊作者指南 `Publishing options` 是否仍允许 subscription/non-OA。  
- [ ] 核对提交费、彩图、长度、超页、附录等额外费用；不将免 APC 等同所有费用均为 0。  
- [ ] 打开出版社**官方 Journal Insights**，核对 first decision / reviewed decision / acceptance 的时间口径。  
- [ ] 记录查询日期与截图；2026 年不同采集平台存在数据冲突，不把 162 天视为保证。  
- [ ] 检查你的导师/单位对 OA、分区、预印本与数据的要求；CAS 中科院分区与 JCR 分区不是一回事。  
- [ ] 投稿策略：C&S → JISA / JNCA（看结果再选），不允许一稿多投。

## 11. 12 周实验计划（从零起步）

| 周数 | 交付件 | 准入条件 |
|---|---|---|
| 1–2 | 35+ 篇文献笔记、冻结威胁模型/授权对象、人工标注 50 个沙箱任务 | 同伴能复述可信边界与已有创新 |
| 3–4 | V0 网关、5 个工具沙箱、不可绕过授权、审计脚本 | 硬权限拒绝的单元测试全过 |
| 5–6 | 固定/随机/阈值/上下文 bandit 4 类基线 | 已有可绘图的合法任务与风险数据 |
| 7–8 | 攻击者漂移模拟器 + 预算选择器 v1 | 测试完全隔离，训练/测试分割冻结 |
| 9 | 弹性成本曲线、P95 和高负载实验 | 对应配置可用脚本一键重现 |
| 10 | 适应性对手、可观测性与鲁棒性分析 | 至少一种场景证明方法局限性 |
| 11 | 消融、bootstrap、误差案例和资源计费 | 所有核心表格有原始 CSV 和种子 |
| 12 | 论文初稿 + artifact/匿名仓库 | 创新点与直接竞争结果逐项对应 |

**失败即调整路线的 Gate**：若第 6 周本文策略在静态分布下甚至不能稳定接近随机/固定方案，暂不继续高复杂博弈；若第 9 周“自适应攻击 + 预算”场景下无稳健收益，则优先转工程系统论文或者降低投稿目标。防御性能绝不能编造。

## 12. 论文结构（可直接用于初稿）

1. Introduction：攻击者适应 + 防御成本 + 工具执行的双重边界  
2. Related Work：Agent 安全、MCP 权限、博弈、资源受限在线学习  
3. System & Threat Model：真实能力、可观测性、数据信任和实验范围  
4. Game Formulation：非零和、非平稳、预算与不可绕过的不变量  
5. GameShield-Gate Design：调度、风险分层、回退与审计  
6. Experimental Setup：基准、模拟器、攻击者、复现实验、费用表  
7. Results：安全/效用/成本/延迟的多维结果，强基线与漂移对照  
8. Theorem & Limitations：若无严谨形式化定理则用“可执行不变量测试”，不写可证明安全  
9. Discussion：实际部署边界、伦理与复现、威胁模型不足  
10. Conclusion：方法结论不能超出实验范围。

## 13. 投稿前必须诚实回答的十大问题

1. 为什么不是 Progent/CaMeL/Fides/ShieldMCP 的简单组合？  
2. “自适应攻击者”有没有具体可重现策略与信息限制？  
3. 一样的总预算下，是否显著优于普通带预算 bandit？  
4. 学习器会不会放行不该执行的动作？  
5. 检测器误报导致合法任务失败是否被正确计数？  
6. 功能差异是否来自额外 LLM/token 消耗，而非算法？  
7. 是否验证 TOCTOU、撤权和外部副作用？  
8. 是否与至少一个 2025–2026 年强防护基线公平复现？  
9. 漂移、不完全信息、非零和支付的设定是否真实？  
10. 如果所有方法都安全但本文更慢/更贵，研究还能成立吗？

## 14. 文献分级说明

下列文献经 2026-10-20 联网检索核对题名及公开落地链接，**“原文 arXiv”并不自动等于已同行评审**；为避免误导，正式会议信息只在查到会议官方页或期刊官网时标注。年度为首公开或所列正式发表年份；正式引用务必从最终论文 PDF 导出作者、DOI、卷页，避免 arXiv 版本与正式版本差异。**总计 41 条相互独立的参考研究**，其中 A 组为直接竞争/实验，G 组为博弈理论与攻防仿真，M 组为约束优化/运行时安全。

### A. Agent 网关安全、直接竞争与基准

- **[A01] [AgentDojo: A Dynamic Environment to Evaluate Prompt Injection Attacks and Defenses for LLM Agents](https://proceedings.nips.cc/paper_files/paper/2024/hash/97091a5177d8dc64b1da8bf3e1f6fb54-Abstract-Datasets_and_Benchmarks_Track.html)**（2024；NeurIPS 2024 / 同行评审）。关联作用：动态攻防测试平台；威胁模型和正常任务保真度基线。
- **[A02] [InjecAgent: Benchmarking Indirect Prompt Injections in Tool-Integrated Large Language Model Agents](https://arxiv.org/abs/2403.02691)**（2024；arXiv 原文；正式出版状态另查）。关联作用：工具反馈中的间接提示注入。
- **[A03] [Agent Security Bench (ASB): Formalizing and Benchmarking Attacks and Defenses in LLM-based Agents](https://proceedings.iclr.cc/paper_files/paper/2025/hash/5750f91d8fb9d5c02bd8ad2c3b44456b-Abstract-Conference.html)**（2025；ICLR 2025 / 同行评审）。关联作用：多种攻击与防御、效用/安全权衡。
- **[A04] [AgentHarm: A Benchmark for Measuring Harmfulness of LLM Agents](https://proceedings.iclr.cc/paper_files/paper/2025/hash/c493d23af93118975cdbc32cbe7323f5-Abstract-Conference.html)**（2025；ICLR 2025 / 同行评审）。关联作用：多步任务的安全结果与正常任务基线。
- **[A05] [MCPTox: A Benchmark for Tool Poisoning on Real-World MCP Servers](https://ojs.aaai.org/index.php/AAAI/article/view/40895)**（2026；AAAI 2026 / 同行评审）。关联作用：真实 MCP 元数据与工具投毒场景。
- **[A06] [Securing the Tool Layer: A Threat Taxonomy and Runtime Defense Framework for Model Context Protocol Deployments](https://aclanthology.org/2026.acl-industry.58/)**（2026；ACL 2026 Industry / 同行评审）。关联作用：ShieldMCP；直接竞争的中间件与拦截框架。
- **[A07] [Defeating Prompt Injections by Design](https://arxiv.org/abs/2503.18813)**（2025；arXiv；CaMeL）。关联作用：能力与数据/控制流隔离；应作为强基线。
- **[A08] [Progent: Programmable Privilege Control for LLM Agents](https://arxiv.org/abs/2504.11703)**（2025；arXiv；正式出版状态另查）。关联作用：细粒度可编程权限策略；强基线。
- **[A09] [MiniScope: A Least Privilege Framework for Authorizing Tool Calling Agents](https://arxiv.org/abs/2512.11147)**（2025；arXiv；正式出版状态另查）。关联作用：自动最小权限；别将最小权限称为新颖贡献。
- **[A10] [Securing AI Agents with Information-Flow Control](https://arxiv.org/abs/2505.23643)**（2025；arXiv；Fides）。关联作用：执行时完整性/机密性标签与控制保证。
- **[A11] [The Task Shield: Enforcing Task Alignment to Defend Against Indirect Prompt Injection in LLM Agents](https://aclanthology.org/2025.acl-long.1435/)**（2025；ACL 2025 / 同行评审）。关联作用：任务一致性验证与低误封。
- **[A12] [Adaptive Evaluation of Out-of-Band Defenses Against Prompt Injection in LLM Agents](https://arxiv.org/abs/2606.26479)**（2026；arXiv 预印本）。关联作用：静态基准不足；自适应、知晓防御的攻击测试。
- **[A13] [From Tool Connection to Execution Control: Benchmarking Security Invariants in MCP-Style Agent Runtimes](https://arxiv.org/abs/2606.29073)**（2026；arXiv 预印本）。关联作用：执行级不变量与参考运行时；直接竞争。
- **[A14] [AgentPoison: Red-teaming LLM Agents via Poisoning Memory or Knowledge Bases](https://arxiv.org/abs/2407.12784)**（2024；arXiv；正式出版状态另查）。关联作用：记忆与检索污染；可作为攻击类别。
- **[A15] [Identifying the Risks of LM Agents with an LM-Emulated Sandbox](https://github.com/ryoungj/ToolEmu)**（2024；ICLR 2024 / 同行评审（ToolEmu））。关联作用：工具沙箱评估；风险场景与模拟方法。
- **[A16] [Benchmarking and Defending Against Indirect Prompt Injection Attacks on Large Language Models](https://arxiv.org/abs/2312.14197)**（2025；KDD 2025；原文 arXiv）。关联作用：BIPIA；通用间接注入测试。
- **[A17] [Not what you've signed up for: Compromising Real-World LLM-Integrated Applications with Indirect Prompt Injection](https://arxiv.org/abs/2302.12173)**（2023；arXiv；相关正式论文）。关联作用：间接注入问题定义与攻击面。
- **[A18] [Defending against Indirect Prompt Injection by Instruction Detection](https://arxiv.org/abs/2505.06311)**（2025；arXiv；正式出版状态另查）。关联作用：内容检测型基线，不等同工具执行授权。
- **[A19] [Evaluating Indirect Prompt Injection Defenses in Tool-Using LLM Agents: Security, Utility, and Replication](https://doi.org/10.3390/computers15090570)**（2026；Computers / 同行评审）。关联作用：强调安全、效用和复现，防止只报 ASR。
- **[A20] [A Multi-Agent LLM Defense Pipeline Against Prompt Injection Attacks](https://arxiv.org/abs/2509.14285)**（2025；arXiv 预印本）。关联作用：检测器集成方案，与策略网关区分。

### B. 安全博弈、动态攻防与经济学

- **[G01] [CM-PIUG: Cross-modal prompt injection unified modeling and game-theoretic defense strategies](https://doi.org/10.1016/j.patcog.2026.113661)**（2026；Pattern Recognition / 期刊论文（分配 2026-11 卷期））。关联作用：非常直接：提示注入 + Stackelberg；必须突出不同研究问题。
- **[G02] [Toward a Dynamic Stackelberg Game-Theoretic Framework for Agentic AI Defense Against LLM Jailbreaking](https://arxiv.org/abs/2507.08207)**（2025；arXiv 预印本）。关联作用：博弈用于 jailbreak，非首次思想。
- **[G03] [Game Theory Meets LLM and Agentic AI: Reimagining Cybersecurity for the Age of Intelligent Threats](https://arxiv.org/abs/2507.10621)**（2025；arXiv 综述/章节草稿）。关联作用：博弈和智能体的整体研究图谱。
- **[G04] [Stackelberg Security Games: Looking Beyond a Decade of Success](https://www.ijcai.org/proceedings/2018/775)**（2018；IJCAI 2018 综述 / 同行评审）。关联作用：领导者-跟随者博弈原理。
- **[G05] [Security Games with Limited Surveillance](https://doi.org/10.1609/aaai.v26i1.8236)**（2012；AAAI / 同行评审）。关联作用：攻击者不能完全观察防御概率。
- **[G06] [Designing the Game to Play: Optimizing Payoff Structure in Security Games](https://www.ijcai.org/proceedings/2018/71)**（2018；IJCAI 2018 / 同行评审）。关联作用：防御者预算下改变攻击收益结构。
- **[G07] [A survey: When moving target defense meets game theory](https://doi.org/10.1016/j.cosrev.2023.100544)**（2023；Computer Science Review / 期刊综述）。关联作用：策略随机化与攻防适应。
- **[G08] [A Survey of Game Theory as Applied to Network Security](https://doi.org/10.1109/HICSS.2010.35)**（2010；HICSS / 同行评审）。关联作用：博弈模型、支付矩阵与威胁建模。
- **[G09] [Dynamic defense strategies for cyber-physical systems using Stackelberg games and deep reinforcement learning in discrete and continuous time](https://doi.org/10.1007/s10207-026-01328-9)**（2026；International Journal of Information Security / 期刊论文）。关联作用：动态博弈 + RL：非首次组合。
- **[G10] [Beyond Reinforcement Learning for network security: A comprehensive survey and tutorial](https://doi.org/10.1016/j.jisa.2025.104294)**（2026；Journal of Information Security and Applications / 期刊综述）。关联作用：适应性防御评估背景。
- **[G11] [CybORG: An Autonomous Cyber Operations Research Gym](https://arxiv.org/abs/2002.10667)**（2020；arXiv 预印本）。关联作用：攻防 Gym 研究环境；非 Agent 网关专属。
- **[G12] [CybORG: A Gym for the Development of Autonomous Cyber Agents](https://arxiv.org/abs/2108.09118)**（2021；arXiv 预印本）。关联作用：攻防双智能体仿真；与 G11 相关但不同文献。

### C. 预算在线学习、控制与形式化屏障

- **[M01] [Constrained Policy Optimization](https://proceedings.mlr.press/v70/achiam17a.html)**（2017；ICML / 同行评审）。关联作用：约束型策略优化数学底座。
- **[M02] [An efficient algorithm for contextual bandits with knapsacks, and an extension to concave objectives](https://proceedings.mlr.press/v49/agrawal16.html)**（2016；COLT / 同行评审）。关联作用：预算约束下在线策略；不是安全保证。
- **[M03] [Non-stationary Bandits with Knapsacks](https://arxiv.org/abs/2205.12427)**（2022；arXiv；正式出版状态另查）。关联作用：变化环境与资源预算。
- **[M04] [Contextual Bandits with Knapsacks for a Conversion Model](https://papers.neurips.cc/paper_files/paper/2022/hash/e75a1c8af8d9438df1057fdaa42913eb-Abstract-Conference.html)**（2022；NeurIPS / 同行评审）。关联作用：业务效用与花费约束的学习方法。
- **[M05] [Episodic Contextual Bandits with Knapsacks under Conversion Models](https://arxiv.org/abs/2507.06859)**（2025；arXiv 预印本）。关联作用：跨任务重置预算、任务域漂移。
- **[M06] [Online shielding for reinforcement learning](https://doi.org/10.1007/s11334-022-00480-4)**（2022；Innovations in Systems and Software Engineering / 期刊论文）。关联作用：运行时保护层；不能声称新发明 shield。
- **[M07] [Dynamic Shielding for Reinforcement Learning in Black-Box Environments](https://arxiv.org/abs/2207.13446)**（2022；arXiv 预印本）。关联作用：环境动态变化下的在线保护。
- **[M08] [Easy-to-Use Shielding for Reinforcement Learning](https://arxiv.org/abs/2606.03804)**（2026；arXiv 预印本）。关联作用：已有可落地屏障库，需对比复杂度。
- **[M09] [Robust Shielding for Safe Reinforcement Learning](https://arxiv.org/abs/2606.00270)**（2026；arXiv 预印本）。关联作用：未知转移下的鲁棒概率安全屏障。

## 15. 来源核验入口与最后声明

- 期刊官方政策：Elsevier [Pricing](https://www.elsevier.com/about/policies-and-standards/pricing) / [Choice of publishing](https://www.elsevier.com/researcher/author/open-access/choice)，[SCIE 收录核查](https://mjl.clarivate.com/)。
- C&S 周期交叉核对：期刊资讯页 [Journal Insights 镜像](https://computersandsecurity.org/journal-insights/) 与 [Elsevier Journal Finder](https://journalfinder.elsevier.com/)。前者并非 `sciencedirect.com` 官方域名，不应当作官方一手证据；若编辑部页面与聚合页冲突，以出版商官方数据为准。
- JISA 约 162 天的二级整理：[JournalCompass](https://journalcompass.com/journals/journal-of-information-security-and-applications-22142126.html)；Computer Networks 约 173 天的二级整理：[SciScribe](https://sciscribe.dev/latex-template/journal/computer-networks-journal/)；JNCA 样本统计：[CrushSci](https://www.crushsci.com/en/journal/1238)。来源采样与统计年份不同，不能直接横向当作统一速度排名。
- 全 OA 非免费实例：[Security and Communication Networks APC 官方说明](https://onlinelibrary.wiley.com/page/journal/2037/homepage/open-access)。

> **结论**：这是一项具备明确学术切入点的**研究计划**，不代表方法已证明安全或能够保证 SCI 录用。实现可靠的最小权限执行边界是实验底线；真正可发表的创新需要来自**预算受限、攻击自适应与正常任务性能同时成立时的可复现实证/理论增量**。对于学弟，先实现 M0，再由实验决定是否升级 M1/M2，成本和研究风险都更可控。
