# 03xcode · GridUQ-Gate

**Agent × 电力系统 × 优化控制**：对工具提出的发电机调度动作做离线 DC/AC、多步、不确定性和指定 N-1 安全检查。
这是合成研究原型，**不是电网控制软件，不连接 SCADA，不代表 IEEE 测试网络或工程安全认证**。

## 安装与启动

需要 **Python 3.11+**，首次联网安装依赖：

```bash
python -m pip install -r requirements.txt
```

| 功能 | Windows | Linux / macOS |
|---|---|---|
| 自检 | 双击 `scripts\check_windows.bat` | `sh scripts/check.sh` |
| 本地演示 | `python scripts/cli.py demo` | `python3 scripts/cli.py demo` |
| 六策略实验 | `python scripts/cli.py study` | `python3 scripts/cli.py study` |
| 启动 HTTP 沙箱 | 双击 `scripts\start_windows.bat` | `sh scripts/start.sh` |

本地服务绑定 `127.0.0.1:8768`；`GET /health`、`GET /state`、`POST /action`。
HTTP 只接受动作提案，**不接受 Agent 自报的传感器数据或风险分数**。

```json
{"proposal":{"request_id":"job-01","grid_id":"toy5","state_version":0,"setpoint_mw":50,"future_setpoints_mw":[50]}}
```

请求需 HTTP 头：`Authorization: Bearer local-demo-token`（仅本机演示，运行前可设置环境变量 `GRIDUQ_LOCAL_TOKEN`）。

## 去哪里看

- `griduq/physics.py`：小电网 AC/DC 潮流；`oracle.py`：隔离真实扰动的独立评分实现。
- `griduq/checks.py`：B0–B5 对照及验证预算；`gateway.py`：SQLite 幂等、状态版本与原子提交。
- `griduq/study.py`：固定种子的合成实验；`results/pilot.json`：原始结果；`docs/RESEARCH_STATUS.md`：三种随机种子的如实报告。
- `docs/DEBUG_INDEX.md`：逐文件排查与修复；`docs/QUALITY.md`：测试与未实现边界。

**当前限制**：只有 `toy5` 合成五母线，不是 IEEE 14/30/118；未接 pandapower、Grid2Op、真实 Agent、OPF 或独立电力软件 oracle。N-1 仅检查指定 2/7 条线路；结果只说明所检范围，不能宣称全部 N-1 安全。风险区间是经验误差集合，未获得真实安全保证。
