# 实验协议与指标

执行 `python scripts/cli.py study --cases 48 --seed 19 --output results/pilot.json`。

- 每个案例有三个连续时间步；各策略在**同一候选、同一观察、同一隐藏工况**下独立运行，中途不重置各自状态。
- 训练/校准误差只由独立的先前随机序列生成，不读取测试的真实误差。
- `b0_stop` 全部停止；`b1_direct` 仅沙箱直接执行；`b2_dc` 单步 DC；`b3_ac` 单步 AC；`b4_sequential` 两步 AC；`b5_uq_gate` 两步 UQ + DC/AC + 指定两条 N-1。
- `false_safe_rate = 已放行且oracle不安全 / 全部oracle不安全候选`；如分母为 0 返回 `null`。
- `completed_safe_tasks`：一个三步任务的每步均被允许且 oracle 判为安全；**不等于达到真实调度经济目标**。
- `mean_budget_units`：每次候选的抽象求解预算平均值，不能与真正的 CPU 时间或费用混用。
- `empirical_calibration_coverage`：合成测试误差落在过去样本分位数区间内的比例；有分布漂移时不保证名义覆盖。
- N-1 覆盖审计为 2/7 所指定线路的尝试数；有提前拒绝时会更少。没有全网故障保障或 N-2 测试。

独立测试仅用样例 `toy5`，并不是论文级的 IEEE 网络基准、真实历史数据或正式 OPF/MPC 与强模型对照。没有外推准确率保证。
