# 架构与边界

```text
Agent / scripted proposer (no direct execute permission)
      | typed proposal; expected version
      v
HTTP localhost -> SQLite gateway -> physical checks -> atomic commit
                                 | DC 1 unit
                                 | AC 3 units
                                 | next 2 setpoints
                                 | +/- historical error band
                                 | N-1 on L01 and L02
                                 v
                         allow / block / abstain

Offline study keeps hidden load errors and outage/derating in oracle.py.
A returned ALLOW commits only one current action; future steps must be resubmitted.
```

`checks.decide()` is a pure decision interface; `gateway.apply()` handles idempotency, trust, replay and state versions. `oracle.evaluate()` is called only by `study.py`, not by any runtime authorization path.

The DC check ignores losses, Q and voltage. The AC check uses a PQ-bus steady-state approximation solved by SciPy, but has no protection, reactive controls, generator Q limits, tap-changing transformers or transient stability. Oracle uses independent numerical code and hidden parameters, but still the *same simplified equations*. This is deliberately **not** a second qualified utility solver.

No export or write protocol exists for a real grid. HTTP only uses hard-coded `toy5` and local state. `B1 direct` is a study-only policy forbidden in `gateway.apply()`.
