# results/pilot.json

**常见现象**：数值无法复现。

**检查和修复**：使用相同 seed=19 cases=48；若修改算法需新生成 pilot.json，并保留旧结果。

**定位命令**：`python scripts/cli.py study --cases 48 --seed 19 --output results/pilot.json`

请先保留触发问题的合成输入和错误栈，再修改源文件并重跑全量自检。
