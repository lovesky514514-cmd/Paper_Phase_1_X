# docs/ARCHITECTURE.md

**常见现象**：架构图与系统边界不一致。

**检查和修复**：比对 gateway.apply 和 study.evaluate_policies 接口，不要把隐藏真值引入在线授权。

**定位命令**：`python scripts/cli.py demo`

请先保留触发问题的合成输入和错误栈，再修改源文件并重跑全量自检。
