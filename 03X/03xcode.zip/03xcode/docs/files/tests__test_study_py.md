# tests/test_study.py

**常见现象**：实验数量或随机性不一致。

**检查和修复**：确认每个案例包含三个步骤、各策略共享隐藏标签；检查随机种子和修改记录。

**定位命令**：`python -m unittest discover -s tests -p test_study.py`

请先保留触发问题的合成输入和错误栈，再修改源文件并重跑全量自检。
