# scripts/check.sh

**常见现象**：Permission denied / python3 not found。

**检查和修复**：直接执行 sh scripts/check.sh；确认系统 python3 与 pip 安装在同一环境。

**定位命令**：`sh scripts/check.sh`

请先保留触发问题的合成输入和错误栈，再修改源文件并重跑全量自检。
