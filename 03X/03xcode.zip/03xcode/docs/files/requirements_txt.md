# requirements.txt

**常见现象**：pip 安装失败。

**检查和修复**：先检查网络、Python 版本与 pip 安装位置；不要在离线环境误称依赖已经安装。

**定位命令**：`python -m pip install -r requirements.txt`

请先保留触发问题的合成输入和错误栈，再修改源文件并重跑全量自检。
