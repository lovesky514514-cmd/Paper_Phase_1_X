# griduq/oracle.py

**常见现象**：评分与网关结果不一致。

**检查和修复**：独立 oracle 使用隐藏负荷/退额，故意与决策模型不同；对 nominal 对照确认数值方程。

**定位命令**：`python -m unittest discover -s tests -p test_physics.py`

请先保留触发问题的合成输入和错误栈，再修改源文件并重跑全量自检。
