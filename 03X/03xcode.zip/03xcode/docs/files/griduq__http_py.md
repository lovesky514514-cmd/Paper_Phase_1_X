# griduq/http.py

**常见现象**：401、400 或端口占用。

**检查和修复**：401 检查本地 token，400 查看 proposal JSON 类型；8768 被占用可用 --port 8769；只监听回环接口。

**定位命令**：`python -m unittest discover -s tests -p test_http.py`

请先保留触发问题的合成输入和错误栈，再修改源文件并重跑全量自检。
