# scripts/cli.py

**常见现象**：找不到 griduq 或命令参数不认识。

**检查和修复**：保持脚本路径和根目录布局，用 python scripts/cli.py --help 查看参数。

**定位命令**：`python scripts/cli.py demo`

请先保留触发问题的合成输入和错误栈，再修改源文件并重跑全量自检。
