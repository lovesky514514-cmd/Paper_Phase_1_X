# griduq/checks.py

**常见现象**：明明 DC 通过却被 N-1 阻止。

**检查和修复**：先读 reason、实际计算预算和 checked_outages；DC/AC/N-1 的判定范围不同，勿绕过后级。

**定位命令**：`python -m unittest discover -s tests -p test_checks.py`

请先保留触发问题的合成输入和错误栈，再修改源文件并重跑全量自检。
