# GLOSSARY.md

**常见现象**：同名术语在研究与实现中含义不一致。

**检查和修复**：先查 state version、oracle、risk band 的规范定义；修改时同步更新代码与测试。

**定位命令**：`python scripts/check.py`

请先保留触发问题的合成输入和错误栈，再修改源文件并重跑全量自检。
