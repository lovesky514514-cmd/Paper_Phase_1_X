# tests/test_http.py

**常见现象**：HTTP 测试监听失败。

**检查和修复**：确认本机可绑定 127.0.0.1 临时端口，没有防火墙/杀软阻断；服务需能接收授权头。

**定位命令**：`python -m unittest discover -s tests -p test_http.py`

请先保留触发问题的合成输入和错误栈，再修改源文件并重跑全量自检。
