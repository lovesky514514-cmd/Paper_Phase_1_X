# scripts/start_windows.bat

**常见现象**：Windows HTTP 服务立即关闭。

**检查和修复**：从 CMD 启动，检查 pip 依赖、8768 端口及数据库写权限；保持命令行窗口打开。

**定位命令**：`scripts\start_windows.bat`

请先保留触发问题的合成输入和错误栈，再修改源文件并重跑全量自检。
