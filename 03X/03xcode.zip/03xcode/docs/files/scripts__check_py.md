# scripts/check.py

**常见现象**：自检失败或依赖缺少。

**检查和修复**：先 pip install -r requirements.txt，确认 Python3.11+ 与 scipy 可用；找到第一条 FAIL 而非忽略。

**定位命令**：`python scripts/check.py`

请先保留触发问题的合成输入和错误栈，再修改源文件并重跑全量自检。
