# griduq/__init__.py

**常见现象**：包导入失败。

**检查和修复**：请从项目根目录运行 scripts/cli.py 或将根目录加入 PYTHONPATH；不要改包名。

**定位命令**：`python -c "import griduq; print(griduq.__version__)"`

请先保留触发问题的合成输入和错误栈，再修改源文件并重跑全量自检。
