# griduq/physics.py

**常见现象**：AC 不收敛或线路潮流异常。

**检查和修复**：确认潮流残差阈值、PQ 母线、slack 设置与单位；试运行 nominal 解，失败必须 BLOCK。

**定位命令**：`python -m unittest discover -s tests -p test_physics.py`

请先保留触发问题的合成输入和错误栈，再修改源文件并重跑全量自检。
