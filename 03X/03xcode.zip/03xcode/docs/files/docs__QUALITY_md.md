# docs/QUALITY.md

**常见现象**：自检记录过时。

**检查和修复**：重新跑 scripts/check.py、ZIP 解压复测；记录真实未覆盖项，不写虚构成功。

**定位命令**：`python scripts/check.py`

请先保留触发问题的合成输入和错误栈，再修改源文件并重跑全量自检。
