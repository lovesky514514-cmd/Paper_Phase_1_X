# griduq/calibration.py

**常见现象**：提示校准样本不足或区间离谱。

**检查和修复**：检查历史误差为非负有限值；alpha 设置需满足 rank <= n；不得使用测试数据拟合。

**定位命令**：`python -m unittest discover -s tests -p test_checks.py`

请先保留触发问题的合成输入和错误栈，再修改源文件并重跑全量自检。
