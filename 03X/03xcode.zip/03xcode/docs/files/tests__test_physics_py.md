# tests/test_physics.py

**常见现象**：物理行为用例失败。

**检查和修复**：检查 toy5 已知数值、隐藏退额和各方向热负荷，不要改断言以迎合新结果。

**定位命令**：`python -m unittest discover -s tests -p test_physics.py`

请先保留触发问题的合成输入和错误栈，再修改源文件并重跑全量自检。
