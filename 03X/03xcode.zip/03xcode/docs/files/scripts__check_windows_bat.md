# scripts/check_windows.bat

**常见现象**：双击窗口退出或 Python 不在 PATH。

**检查和修复**：从 CMD 运行脚本读取报错；安装 Python 并勾选 Add to PATH；请确保中文系统支持 UTF-8。

**定位命令**：`scripts\check_windows.bat`

请先保留触发问题的合成输入和错误栈，再修改源文件并重跑全量自检。
