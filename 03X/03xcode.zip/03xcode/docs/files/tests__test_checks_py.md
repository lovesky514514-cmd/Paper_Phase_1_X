# tests/test_checks.py

**常见现象**：选定 N-1 或预算测试失败。

**检查和修复**：检查验算顺序、DC=1/AC=3 成本与 fail-closed；别把 budget 超额当 ALLOW。

**定位命令**：`python -m unittest discover -s tests -p test_checks.py`

请先保留触发问题的合成输入和错误栈，再修改源文件并重跑全量自检。
