# griduq/model.py

**常见现象**：母线或线路参数显示单位错误。

**检查和修复**：检查 MW/Mvar/MVA 与 pu、BASE_MVA=100 和线路编号；不得把 toy5 当 IEEE 网络。

**定位命令**：`python -m unittest discover -s tests -p test_physics.py`

请先保留触发问题的合成输入和错误栈，再修改源文件并重跑全量自检。
