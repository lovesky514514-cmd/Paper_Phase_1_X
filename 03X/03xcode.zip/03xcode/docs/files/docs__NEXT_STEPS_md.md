# docs/NEXT_STEPS.md

**常见现象**：实验计划无法落地。

**检查和修复**：先确认 pandapower/公开 IEEE 模型获得许可且环境可用，再规划迁移；不声明原型已经接入。

**定位命令**：`python scripts/cli.py demo`

请先保留触发问题的合成输入和错误栈，再修改源文件并重跑全量自检。
