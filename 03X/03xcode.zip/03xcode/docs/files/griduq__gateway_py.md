# griduq/gateway.py

**常见现象**：旧版本、重复请求或 database locked。

**检查和修复**：核查 request_id、state_version；删除测试数据库只能在停止服务后进行；检查 SQLite busy_timeout 和事务。

**定位命令**：`python -m unittest discover -s tests -p test_gateway.py`

请先保留触发问题的合成输入和错误栈，再修改源文件并重跑全量自检。
