# docs/EXPERIMENT.md

**常见现象**：结果与文字口径不一致。

**检查和修复**：对照结果 JSON 的 accepted、oracle_unsafe、false_safe 分母；区分估计成本与实测延迟。

**定位命令**：`python scripts/cli.py study --cases 48 --seed 19`

请先保留触发问题的合成输入和错误栈，再修改源文件并重跑全量自检。
