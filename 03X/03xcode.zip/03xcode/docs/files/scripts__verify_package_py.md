# scripts/verify_package.py

**常见现象**：SHA256 校验报错。

**检查和修复**：确认文件没有被手改；重新取得原包；本脚本不能用于给篡改文件重新签名。

**定位命令**：`python scripts/verify_package.py`

请先保留触发问题的合成输入和错误栈，再修改源文件并重跑全量自检。
