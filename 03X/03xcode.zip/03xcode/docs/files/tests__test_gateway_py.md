# tests/test_gateway.py

**常见现象**：并发用例偶发失败。

**检查和修复**：确保 SQLite 使用 BEGIN IMMEDIATE，重复 id 可回放、冲突请求只能一条提交；检查连接关闭。

**定位命令**：`python -m unittest discover -s tests -p test_gateway.py`

请先保留触发问题的合成输入和错误栈，再修改源文件并重跑全量自检。
