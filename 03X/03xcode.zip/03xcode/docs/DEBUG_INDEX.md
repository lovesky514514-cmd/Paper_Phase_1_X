# 文件排错索引

一般顺序：确认 Python 和 NumPy/SciPy → 执行 `python scripts/check.py` → 对照下面相应文件的排错说明。

| 文件 | 排查说明 |
|---|---|
| `CODING_STANDARDS.md` | [`CODING_STANDARDS_md.md`](files/CODING_STANDARDS_md.md) |
| `GLOSSARY.md` | [`GLOSSARY_md.md`](files/GLOSSARY_md.md) |
| `README.md` | [`README_md.md`](files/README_md.md) |
| `docs/ARCHITECTURE.md` | [`docs__ARCHITECTURE_md.md`](files/docs__ARCHITECTURE_md.md) |
| `docs/EXPERIMENT.md` | [`docs__EXPERIMENT_md.md`](files/docs__EXPERIMENT_md.md) |
| `docs/NEXT_STEPS.md` | [`docs__NEXT_STEPS_md.md`](files/docs__NEXT_STEPS_md.md) |
| `docs/QUALITY.md` | [`docs__QUALITY_md.md`](files/docs__QUALITY_md.md) |
| `griduq/__init__.py` | [`griduq____init___py.md`](files/griduq____init___py.md) |
| `griduq/calibration.py` | [`griduq__calibration_py.md`](files/griduq__calibration_py.md) |
| `griduq/checks.py` | [`griduq__checks_py.md`](files/griduq__checks_py.md) |
| `griduq/gateway.py` | [`griduq__gateway_py.md`](files/griduq__gateway_py.md) |
| `griduq/http.py` | [`griduq__http_py.md`](files/griduq__http_py.md) |
| `griduq/model.py` | [`griduq__model_py.md`](files/griduq__model_py.md) |
| `griduq/oracle.py` | [`griduq__oracle_py.md`](files/griduq__oracle_py.md) |
| `griduq/physics.py` | [`griduq__physics_py.md`](files/griduq__physics_py.md) |
| `griduq/study.py` | [`griduq__study_py.md`](files/griduq__study_py.md) |
| `requirements.txt` | [`requirements_txt.md`](files/requirements_txt.md) |
| `research/03x_original.md` | [`research__03x_original_md.md`](files/research__03x_original_md.md) |
| `results/pilot.json` | [`results__pilot_json.md`](files/results__pilot_json.md) |
| `scripts/check.py` | [`scripts__check_py.md`](files/scripts__check_py.md) |
| `scripts/check.sh` | [`scripts__check_sh.md`](files/scripts__check_sh.md) |
| `scripts/check_windows.bat` | [`scripts__check_windows_bat.md`](files/scripts__check_windows_bat.md) |
| `scripts/cli.py` | [`scripts__cli_py.md`](files/scripts__cli_py.md) |
| `scripts/start.sh` | [`scripts__start_sh.md`](files/scripts__start_sh.md) |
| `scripts/start_windows.bat` | [`scripts__start_windows_bat.md`](files/scripts__start_windows_bat.md) |
| `scripts/verify_package.py` | [`scripts__verify_package_py.md`](files/scripts__verify_package_py.md) |
| `tests/test_checks.py` | [`tests__test_checks_py.md`](files/tests__test_checks_py.md) |
| `tests/test_gateway.py` | [`tests__test_gateway_py.md`](files/tests__test_gateway_py.md) |
| `tests/test_http.py` | [`tests__test_http_py.md`](files/tests__test_http_py.md) |
| `tests/test_physics.py` | [`tests__test_physics_py.md`](files/tests__test_physics_py.md) |
| `tests/test_study.py` | [`tests__test_study_py.md`](files/tests__test_study_py.md) |
