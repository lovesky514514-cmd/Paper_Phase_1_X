"""Run from anywhere: python scripts/cli.py {demo,study,server}."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from griduq.calibration import fit_errors
from griduq.gateway import LocalGateway
from griduq.http import serve
from griduq.model import Proposal
from griduq.study import export


def main() -> None:
    parser = argparse.ArgumentParser(description="GridUQ-Gate offline synthetic testbed")
    parser.add_argument("command", choices=("demo", "study", "server"))
    parser.add_argument("--cases", type=int, default=48)
    parser.add_argument("--seed", type=int, default=19)
    parser.add_argument("--output", default=str(ROOT / "results" / "pilot.json"))
    parser.add_argument("--database", default=str(ROOT / "results" / "sandbox.db"))
    parser.add_argument("--port", type=int, default=8768)
    args = parser.parse_args()
    if args.command == "study":
        result = export(args.output, cases=args.cases, seed=args.seed)
        print(json.dumps(result["policies"], ensure_ascii=False, indent=2))
        print(f"Synthetic experiment saved: {args.output}")
    elif args.command == "server":
        serve(args.database, port=args.port)
    else:
        with tempfile.TemporaryDirectory() as workdir:
            gate = LocalGateway(Path(workdir) / "sample.db",
                                band=fit_errors([0.02 + i * 0.0005 for i in range(80)]))
            p = Proposal("demo-1", "toy5", 0, 45.0, (50.0,))
            first = gate.apply(p, observed_factor=1.0)
            second = gate.apply(p, observed_factor=1.0)
            print(json.dumps({"first": first, "repeat": second, "state": vars(gate.state())},
                             ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
