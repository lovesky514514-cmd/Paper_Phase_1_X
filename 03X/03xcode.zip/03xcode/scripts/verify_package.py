"""Verify shipped bytes against the package manifest, excluding itself."""
from __future__ import annotations

from hashlib import sha256
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    manifest = json.loads((ROOT / 'PACKAGE_SHA256.json').read_text(encoding='utf-8'))
    for relative, expected in manifest['sha256'].items():
        file = ROOT / relative
        if not file.is_file() or sha256(file.read_bytes()).hexdigest() != expected:
            raise SystemExit(f'FAILED: {relative}')
    print(f"Verified {len(manifest['sha256'])} shipped files")


if __name__ == '__main__':
    main()
