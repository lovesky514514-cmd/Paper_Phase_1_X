@echo off
setlocal
cd /d "%~dp0.."
chcp 65001 >nul
python scripts\cli.py server
if errorlevel 1 (
  echo [FAILED] Check docs\DEBUG_INDEX.md
  pause
  exit /b 1
)
