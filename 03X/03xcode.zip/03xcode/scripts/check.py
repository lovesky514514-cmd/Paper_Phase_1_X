"""Portable one-command, offline self-check (tests + demo + replay)."""
from __future__ import annotations

import compileall
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]


def call(*args: str) -> None:
    print('Running:', ' '.join(args), flush=True)
    subprocess.run((sys.executable, *args), cwd=ROOT, check=True)


def main() -> None:
    import numpy
    import scipy
    print(f'Python {sys.version.split()[0]}, numpy {numpy.__version__}, scipy {scipy.__version__}', flush=True)
    if not compileall.compile_dir(str(ROOT / 'griduq'), quiet=1, force=True):
        raise SystemExit('Python syntax check failed')
    call('-W', 'error::ResourceWarning', '-m', 'unittest', 'discover', '-s', 'tests', '-v')
    call('scripts/cli.py', 'demo')
    call('scripts/cli.py', 'study', '--cases', '12', '--seed', '19',
         '--output', str(ROOT / 'results' / 'selfcheck.json'))
    print('All local self-checks passed.', flush=True)


if __name__ == '__main__':
    main()
