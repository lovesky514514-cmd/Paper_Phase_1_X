"""Independent DC approximation and nonlinear steady-state AC power flow.

AC solver: unknown complex voltages at PQ buses, fixed slack V=1.02 pu.
SciPy root finds P/Q bus mismatches; line MVA uses both directions.
The model has no transformer, protection, generator Q limits or dynamics.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.optimize import root

from .model import BASE_MVA, Grid


@dataclass(frozen=True)
class Flow:
    converged: bool
    voltages_pu: tuple[float, ...]
    line_mva: dict[str, float]
    message: str = ""


def admittance(grid: Grid, outage: str | None = None) -> np.ndarray:
    n = len(grid.demand_mw)
    y = np.zeros((n, n), dtype=np.complex128)
    for line in grid.lines:
        if line.name == outage:
            continue
        a, b = line.source, line.target
        value = 1 / complex(line.r_pu, line.x_pu)
        y[a, a] += value
        y[b, b] += value
        y[a, b] -= value
        y[b, a] -= value
    return y


def injections(grid: Grid, load_factor: float, generation_mw: float) -> np.ndarray:
    p = -np.asarray(grid.demand_mw, dtype=float) * load_factor
    q = -np.asarray(grid.demand_mvar, dtype=float) * load_factor
    p[grid.generator_bus] += generation_mw
    return (p + 1j * q) / BASE_MVA


def solve_ac(grid: Grid, load_factor: float, generation_mw: float,
             outage: str | None = None) -> Flow:
    """Run actual AC Newton-type nonlinear equations for the research sandbox."""
    y = admittance(grid, outage)
    desired = injections(grid, load_factor, generation_mw)
    n = len(grid.demand_mw)

    def residual(x: np.ndarray) -> np.ndarray:
        angles = np.r_[0.0, x[:n - 1]]
        mags = np.r_[1.02, x[n - 1:]]
        v = mags * np.exp(1j * angles)
        actual = v * np.conjugate(y @ v)
        delta = actual[1:] - desired[1:]
        return np.r_[delta.real, delta.imag]

    start = np.r_[np.zeros(n - 1), np.ones(n - 1)]
    try:
        answer = root(residual, start, method="hybr", tol=1e-10)
    except (ValueError, FloatingPointError, np.linalg.LinAlgError) as exc:
        return Flow(False, (), {}, str(exc))
    if not answer.success or not np.all(np.isfinite(answer.x)) or np.max(np.abs(residual(answer.x))) > 1e-7:
        return Flow(False, (), {}, "AC power flow did not converge")
    angles = np.r_[0.0, answer.x[:n - 1]]
    mags = np.r_[1.02, answer.x[n - 1:]]
    if np.any(mags <= 0):
        return Flow(False, (), {}, "nonphysical voltage")
    v = mags * np.exp(1j * angles)
    flows = {}
    for line in grid.lines:
        if line.name == outage:
            continue
        current = (v[line.source] - v[line.target]) / complex(line.r_pu, line.x_pu)
        forward = v[line.source] * np.conjugate(current) * BASE_MVA
        reverse = v[line.target] * np.conjugate(-current) * BASE_MVA
        flows[line.name] = float(max(abs(forward), abs(reverse)))
    return Flow(True, tuple(float(m) for m in mags), flows)


def solve_dc(grid: Grid, load_factor: float, generation_mw: float,
             outage: str | None = None) -> Flow:
    """Lossless, fixed-voltage approximation; does NOT check AC voltage."""
    n = len(grid.demand_mw)
    b = np.zeros((n, n))
    for line in grid.lines:
        if line.name == outage:
            continue
        weight = 1 / line.x_pu
        a, c = line.source, line.target
        b[a, a] += weight
        b[c, c] += weight
        b[a, c] -= weight
        b[c, a] -= weight
    p = injections(grid, load_factor, generation_mw).real
    try:
        theta = np.r_[0.0, np.linalg.solve(b[1:, 1:], p[1:])]
    except np.linalg.LinAlgError:
        return Flow(False, (), {}, "DC network disconnected")
    flows = {
        line.name: abs(theta[line.source] - theta[line.target]) / line.x_pu * BASE_MVA
        for line in grid.lines if line.name != outage
    }
    return Flow(True, tuple(1.0 for _ in range(n)), flows)


def safety_problem(grid: Grid, flow: Flow, *, outage: str | None = None,
                   derating: dict[str, float] | None = None, check_voltage: bool = True) -> str | None:
    """Return first explicit violated constraint; unknown results fail closed."""
    if not flow.converged:
        return flow.message or "solver failure"
    derating = derating or {}
    if check_voltage:
        for bus, value in enumerate(flow.voltages_pu[1:], start=1):
            if not grid.min_voltage_pu <= value <= grid.max_voltage_pu:
                return f"voltage out of range at bus {bus}: {value:.4f} pu"
    for line in grid.lines:
        if line.name == outage:
            continue
        if flow.line_mva[line.name] > line.rating_mva * derating.get(line.name, 1.0) + 1e-8:
            return f"thermal overload on {line.name}"
    return None
