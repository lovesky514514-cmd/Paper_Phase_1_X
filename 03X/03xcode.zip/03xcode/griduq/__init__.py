"""GridUQ-Gate: an offline, synthetic-grid research prototype."""

__version__ = "0.1.0"
