"""Paired synthetic evaluation; no LLM, production data or public IEEE cases.

Each policy sees identical proposals/observations. Hidden truth and derating
are generated independently from the *past-only* calibration observations.
"""
from __future__ import annotations

from dataclasses import asdict, replace
import json
from pathlib import Path
import random

from .calibration import fit_errors
from .checks import POLICIES, CheckConfig, decide
from .model import Proposal, State, toy5
from .oracle import evaluate


def evaluate_policies(cases: int = 48, seed: int = 19,
                      config: CheckConfig = CheckConfig()) -> dict:
    if not 1 <= cases <= 10000:
        raise ValueError("cases outside supported experiment range")
    rng = random.Random(seed)
    # Chronologically separate synthetic calibration sequence, not test residuals.
    history_rng = random.Random(seed + 100000)
    historical = [abs(history_rng.gauss(0, 0.045)) for _ in range(80)]
    band = fit_errors(historical, alpha=0.1)
    grid = toy5()
    events = []
    for case_id in range(cases):
        # Every policy starts each case at the same initial state, and proceeds
        # through 3 steps without resetting after a rejected proposal.
        observed = [rng.uniform(0.94, 1.12) + 0.025 * t for t in range(3)]
        deviation = [rng.gauss(0, 0.06 if case_id % 5 else 0.16) for _ in range(3)]
        hidden_factors = [max(0.3, a + b) for a, b in zip(observed, deviation)]
        hidden_derating = {"L01": 0.72} if case_id % 7 == 0 else {}
        hidden_outage = "L03" if case_id % 11 == 0 else None
        # Policy-independent candidate generator; deliberately not an OPF optimizer.
        first = rng.choice((15.0, 25.0, 35.0, 45.0, 50.0))
        # Correlated proposals represent a 3-step plan rather than unrelated draws.
        suggested = [first]
        for _ in range(2):
            suggested.append(max(0.0, min(70.0, suggested[-1] + rng.choice((-5.0, 0.0, 5.0)))))
        for policy in POLICIES:
            current = State()
            for step in range(3):
                proposal = Proposal(
                    request_id=f"{case_id}-{step}", grid_id="toy5",
                    state_version=current.version, setpoint_mw=suggested[step],
                    future_setpoints_mw=(suggested[step + 1],) if step < 2 else (suggested[step],),
                )
                decision = decide(policy, grid, current, proposal, observed[step], band, config)
                # Independently score the proposed action, including declined cases.
                truth = evaluate(grid, suggested[step], hidden_factors[step],
                                 outage=hidden_outage, derating=hidden_derating)
                allowed = decision.verdict == "ALLOW"
                events.append({
                    "case": case_id, "step": step, "policy": policy,
                    "allowed": allowed, "verdict": decision.verdict,
                    "reason": decision.reason, "oracle_safe": truth.safe,
                    "false_safe": allowed and not truth.safe,
                    "ac_calls": decision.ac_calls, "dc_calls": decision.dc_calls,
                    "units": decision.budget_spent,
                    "checked_outages": list(decision.checked_outages),
                    "hidden_outage": hidden_outage,
                    "calibration_covered": abs(deviation[step]) <= band.size,
                })
                # Only the current action is applied; time still progresses.
                current = replace(current, tick=current.tick + 1,
                                  version=current.version + int(allowed),
                                  generator_mw=suggested[step] if allowed else current.generator_mw)
    summary = {}
    for policy in POLICIES:
        rows = [row for row in events if row["policy"] == policy]
        negative = sum(not row["oracle_safe"] for row in rows)
        released_unsafe = sum(row["false_safe"] for row in rows)
        completed = sum(
            all(row["allowed"] and row["oracle_safe"]
                for row in rows if row["case"] == case_id)
            for case_id in range(cases)
        )
        summary[policy] = {
            "candidates": len(rows), "oracle_unsafe": negative,
            "false_safe": released_unsafe,
            "false_safe_rate": released_unsafe / negative if negative else None,
            "accepted": sum(row["allowed"] for row in rows),
            "abstained": sum(row["verdict"] == "ABSTAIN" for row in rows),
            "completed_safe_tasks": completed,
            "mean_budget_units": round(sum(row["units"] for row in rows) / len(rows), 3),
            "mean_ac_calls": round(sum(row["ac_calls"] for row in rows) / len(rows), 3),
            "mean_checked_contingencies": round(sum(len(row["checked_outages"]) for row in rows) / len(rows), 3),
        }
    return {
        "label": "SYNTHETIC toy5, NOT IEEE or operational safety evidence",
        "seed": seed, "cases": cases, "calibration": asdict(band),
        "empirical_calibration_coverage": round(
            sum(row["calibration_covered"] for row in events if row["policy"] == "b0_stop") / (cases * 3), 4),
        "policies": summary, "events": events,
    }


def export(path: str | Path, cases: int = 48, seed: int = 19) -> dict:
    output = evaluate_policies(cases, seed)
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(output, ensure_ascii=False, indent=2, allow_nan=False) + "\n",
                          encoding="utf-8")
    return output
