"""Held-out physical evaluator for synthetic experiments.

This scorer has hidden load/topology/rating data not passed to decide().
It uses a separately coded voltage residual and SciPy least_squares, but
shares the simplified AC equations: NOT an independent utility-grade solver.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.optimize import least_squares

from .model import BASE_MVA, Grid


@dataclass(frozen=True)
class Truth:
    safe: bool
    reason: str
    max_line_usage: float


def evaluate(grid: Grid, generation_mw: float, actual_factor: float,
             outage: str | None = None, derating: dict[str, float] | None = None) -> Truth:
    n = len(grid.demand_mw)
    y = np.zeros((n, n), dtype=complex)
    for line in grid.lines:
        if line.name == outage:
            continue
        conductivity = complex(line.r_pu, -line.x_pu) / (line.r_pu**2 + line.x_pu**2)
        a, b = line.source, line.target
        y[a, a] += conductivity
        y[b, b] += conductivity
        y[a, b] -= conductivity
        y[b, a] -= conductivity
    desired_real = [-load * actual_factor / BASE_MVA for load in grid.demand_mw]
    desired_real[grid.generator_bus] += generation_mw / BASE_MVA
    desired_imag = [-load * actual_factor / BASE_MVA for load in grid.demand_mvar]

    def differences(x: np.ndarray) -> np.ndarray:
        voltage = np.empty(n, complex)
        voltage[0] = 1.02
        for k in range(1, n):
            voltage[k] = x[k - 1] + 1j * x[n + k - 2]
        mismatch = voltage * np.conjugate(y @ voltage)
        return np.r_[mismatch.real[1:] - desired_real[1:],
                     mismatch.imag[1:] - desired_imag[1:]]

    initial = np.r_[np.ones(n - 1), np.zeros(n - 1)]
    try:
        solution = least_squares(differences, initial, xtol=1e-12, ftol=1e-12, gtol=1e-12, max_nfev=200)
    except (ValueError, FloatingPointError, np.linalg.LinAlgError):
        return Truth(False, "oracle solver error", float("inf"))
    if not solution.success or max(abs(differences(solution.x))) > 1e-6:
        return Truth(False, "oracle did not converge", float("inf"))
    voltage = np.r_[complex(1.02), solution.x[:n - 1] + 1j * solution.x[n - 1:]]
    mags = abs(voltage)
    if any(m < grid.min_voltage_pu or m > grid.max_voltage_pu for m in mags[1:]):
        return Truth(False, "oracle voltage violation", float("inf"))
    scale = derating or {}
    usage = 0.0
    for line in grid.lines:
        if line.name == outage:
            continue
        delta = voltage[line.source] - voltage[line.target]
        current = delta / complex(line.r_pu, line.x_pu)
        forward = abs(voltage[line.source] * np.conjugate(current)) * BASE_MVA
        backward = abs(voltage[line.target] * np.conjugate(current)) * BASE_MVA
        ratio = max(forward, backward) / (line.rating_mva * scale.get(line.name, 1.0))
        usage = max(usage, ratio)
        if ratio > 1 + 1e-8:
            return Truth(False, f"oracle thermal violation {line.name}", float(ratio))
    return Truth(True, "passed synthetic oracle", float(usage))
