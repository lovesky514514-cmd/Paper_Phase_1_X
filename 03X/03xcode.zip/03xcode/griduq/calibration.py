"""Past-only absolute-error quantiles; a heuristic uncertainty set, not a certificate."""
from __future__ import annotations

from dataclasses import dataclass
from math import ceil, isfinite


@dataclass(frozen=True)
class ErrorBand:
    size: float
    sample_count: int
    alpha: float

    def factors(self, observed_load_factor: float) -> tuple[float, float]:
        return (max(0.1, observed_load_factor - self.size), observed_load_factor + self.size)


def fit_errors(past_absolute_errors: list[float], alpha: float = 0.1) -> ErrorBand:
    """Split-conformal quantile under exchangeability, with no future/test labels.

    If there are too few observations for the specified alpha, fail closed.
    """
    if not 0 < alpha < 1:
        raise ValueError("alpha must be between zero and one")
    if not past_absolute_errors or any(not isfinite(x) or x < 0 for x in past_absolute_errors):
        raise ValueError("historical errors must be finite, nonnegative and nonempty")
    values = sorted(past_absolute_errors)
    rank = ceil((len(values) + 1) * (1 - alpha))
    if rank > len(values):
        raise ValueError("insufficient calibration observations for chosen alpha")
    return ErrorBand(values[rank - 1], len(values), alpha)
