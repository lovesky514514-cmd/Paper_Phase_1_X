"""Policy decisions use the visible (estimated) state only.

No policy receives hidden evaluation data. ALLOW means all *selected*
checks passed; it is not a physical-system safety certificate.
"""
from __future__ import annotations

from dataclasses import dataclass
from math import isfinite

from .calibration import ErrorBand
from .model import Decision, Grid, Proposal, State
from .physics import safety_problem, solve_ac, solve_dc

POLICIES = ("b0_stop", "b1_direct", "b2_dc", "b3_ac", "b4_sequential", "b5_uq_gate")


@dataclass(frozen=True)
class CheckConfig:
    horizon: int = 2
    budget_units: int = 45
    max_observation_age_s: float = 60
    contingencies: tuple[str, ...] = ("L01", "L02")


class Meter:
    """Research accounting units: DC=1, AC=3 (not real wall-time)."""

    def __init__(self, limit: int):
        self.limit = limit
        self.spent = 0
        self.dc = 0
        self.ac = 0

    def charge(self, kind: str) -> bool:
        price = 1 if kind == "dc" else 3
        if self.spent + price > self.limit:
            return False
        self.spent += price
        if kind == "dc":
            self.dc += 1
        else:
            self.ac += 1
        return True


def decide(policy: str, grid: Grid, state: State, proposal: Proposal,
           observed_factor: float, band: ErrorBand | None,
           config: CheckConfig = CheckConfig()) -> Decision:
    """Check a proposed current setpoint and its declared future sequence.

    The caller must enforce idempotency, authorization and version checks.
    b1_direct is allowed for offline comparison ONLY, never by HTTP gateway.
    """
    if policy not in POLICIES:
        raise ValueError("unknown policy")
    if (not isfinite(observed_factor) or observed_factor <= 0
            or not isfinite(proposal.setpoint_mw)):
        return Decision("BLOCK", "invalid numeric request")
    if state.observation_age_s > config.max_observation_age_s:
        return Decision("ABSTAIN", "observation too old")
    horizon = config.horizon if policy in ("b4_sequential", "b5_uq_gate") else 1
    if horizon < 1 or len(proposal.future_setpoints_mw) < horizon - 1:
        return Decision("ABSTAIN", "future schedule missing")
    trajectory = (proposal.setpoint_mw,) + proposal.future_setpoints_mw[:horizon - 1]
    previous = state.generator_mw
    for value in trajectory:
        if not isfinite(value) or not grid.min_generation_mw <= value <= grid.max_generation_mw:
            return Decision("BLOCK", "generator setpoint outside hard bounds")
        if abs(value - previous) > grid.max_ramp_mw:
            return Decision("BLOCK", "generator ramp limit")
        previous = value
    if policy == "b0_stop":
        return Decision("ABSTAIN", "conservative stop baseline")
    if policy == "b1_direct":
        return Decision("ALLOW", "offline unverified direct baseline")
    if policy == "b5_uq_gate" and band is None:
        return Decision("ABSTAIN", "uncertainty evidence missing")
    if any(c not in grid.line_names() for c in config.contingencies):
        return Decision("ABSTAIN", "unknown requested contingency")
    meter = Meter(config.budget_units)
    verified_outages: set[str] = set()
    steps = 0
    factors_seen: set[float] = set()

    def result(verdict: str, reason: str) -> Decision:
        return Decision(verdict, reason, meter.dc, meter.ac, meter.spent,
                        tuple(sorted(verified_outages)), steps,
                        tuple(sorted(factors_seen)))

    # Future demand is a declared forecast, never claimed to be real observation.
    for t, setpoint in enumerate(trajectory):
        forecast_factor = observed_factor + 0.035 * t
        factors = (forecast_factor,)
        if policy == "b5_uq_gate":
            factors = band.factors(forecast_factor)  # type: ignore[union-attr]
        for factor in factors:
            if policy in ("b2_dc", "b5_uq_gate"):
                if not meter.charge("dc"):
                    return result("ABSTAIN", "verification budget exhausted")
                dc = solve_dc(grid, factor, setpoint)
                problem = safety_problem(grid, dc, check_voltage=False)
                if problem:
                    return result("BLOCK", f"DC: {problem}")
            if policy != "b2_dc":
                if not meter.charge("ac"):
                    return result("ABSTAIN", "verification budget exhausted")
                ac = solve_ac(grid, factor, setpoint)
                problem = safety_problem(grid, ac)
                if problem:
                    return result("BLOCK", f"AC: {problem}")
            factors_seen.add(round(float(factor), 6))
            if policy == "b5_uq_gate":
                for outage in config.contingencies:
                    if not meter.charge("ac"):
                        return result("ABSTAIN", "contingency budget exhausted")
                    fault = solve_ac(grid, factor, setpoint, outage=outage)
                    verified_outages.add(outage)
                    problem = safety_problem(grid, fault, outage=outage)
                    if problem:
                        return result("BLOCK", f"N-1 {outage}: {problem}")
        steps += 1
    return result("ALLOW", "selected verification scope passed")
