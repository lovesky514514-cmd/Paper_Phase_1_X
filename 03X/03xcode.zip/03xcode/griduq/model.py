"""Types and the intentionally small synthetic grid.

All powers are MW/Mvar; admittances use a 100 MVA per-unit base.
No part of this model is connected to a physical grid.
"""
from __future__ import annotations

from dataclasses import dataclass

BASE_MVA = 100.0


@dataclass(frozen=True)
class Line:
    name: str
    source: int
    target: int
    r_pu: float
    x_pu: float
    rating_mva: float


@dataclass(frozen=True)
class Grid:
    name: str
    demand_mw: tuple[float, ...]
    demand_mvar: tuple[float, ...]
    lines: tuple[Line, ...]
    generator_bus: int = 2
    min_generation_mw: float = 0.0
    max_generation_mw: float = 70.0
    max_ramp_mw: float = 25.0
    min_voltage_pu: float = 0.94
    max_voltage_pu: float = 1.06

    def line_names(self) -> tuple[str, ...]:
        return tuple(line.name for line in self.lines)


def toy5() -> Grid:
    """Five-bus meshed *synthetic* case; not an IEEE test system."""
    lines = (
        Line("L01", 0, 1, 0.012, 0.075, 49),
        Line("L02", 0, 2, 0.015, 0.085, 47),
        Line("L03", 0, 3, 0.020, 0.120, 45),
        Line("L12", 1, 2, 0.010, 0.080, 28),
        Line("L13", 1, 3, 0.017, 0.100, 33),
        Line("L24", 2, 4, 0.018, 0.110, 33),
        Line("L34", 3, 4, 0.012, 0.090, 30),
    )
    return Grid(
        name="toy5", demand_mw=(0, 25, 35, 30, 20),
        demand_mvar=(0, 8, 11, 10, 7), lines=lines,
    )


@dataclass(frozen=True)
class State:
    version: int = 0
    tick: int = 0
    generator_mw: float = 25.0
    # Real-data timestamps are out of scope; this represents age of a synthetic measurement.
    observation_age_s: float = 0.0


@dataclass(frozen=True)
class Proposal:
    request_id: str
    grid_id: str
    state_version: int
    setpoint_mw: float
    future_setpoints_mw: tuple[float, ...] = ()
    expires_at: float | None = None


@dataclass(frozen=True)
class Decision:
    verdict: str
    reason: str
    dc_calls: int = 0
    ac_calls: int = 0
    budget_spent: int = 0
    checked_outages: tuple[str, ...] = ()
    checked_steps: int = 0
    checked_load_factors: tuple[float, ...] = ()

    def as_dict(self) -> dict:
        return {
            "verdict": self.verdict, "reason": self.reason,
            "dc_calls": self.dc_calls, "ac_calls": self.ac_calls,
            "budget_spent": self.budget_spent,
            "checked_outages": list(self.checked_outages),
            "checked_steps": self.checked_steps,
            "checked_load_factors": list(self.checked_load_factors),
        }
