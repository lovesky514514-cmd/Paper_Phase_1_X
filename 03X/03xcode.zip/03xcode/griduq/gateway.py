"""Versioned, idempotent local sandbox gate backed by SQLite.

Version and receipt are rechecked inside BEGIN IMMEDIATE. This prevents
concurrent proposals validated against the same snapshot from both committing.
No production electrical control endpoint exists in this package.
"""
from __future__ import annotations

from dataclasses import asdict
from contextlib import closing
from hashlib import sha256
import json
from math import isfinite
from pathlib import Path
import re
import sqlite3
import time

from .calibration import ErrorBand
from .checks import CheckConfig, decide
from .model import Proposal, State, toy5

ID_PATTERN = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9_-]{0,63}$")


class LocalGateway:
    def __init__(self, path: str | Path, config: CheckConfig = CheckConfig(),
                 band: ErrorBand | None = None):
        self.path = str(path)
        self.config = config
        # Trusted demonstration calibration only. Never sourced from an Agent field.
        self.band = band
        with closing(self._db()) as db:
            db.execute("""CREATE TABLE IF NOT EXISTS state
                (slot INTEGER PRIMARY KEY CHECK(slot=1), version INTEGER NOT NULL,
                 tick INTEGER NOT NULL, generator_mw REAL NOT NULL)""")
            db.execute("""CREATE TABLE IF NOT EXISTS receipts
                (request_id TEXT PRIMARY KEY, fingerprint TEXT NOT NULL,
                 response TEXT NOT NULL)""")
            db.execute("INSERT OR IGNORE INTO state VALUES(1,0,0,25.0)")

    def _db(self) -> sqlite3.Connection:
        db = sqlite3.connect(self.path, timeout=10, isolation_level=None)
        db.execute("PRAGMA busy_timeout=10000")
        return db

    def state(self) -> State:
        with closing(self._db()) as db:
            row = db.execute("SELECT version,tick,generator_mw FROM state WHERE slot=1").fetchone()
            return State(*row)

    def apply(self, proposal: Proposal, policy: str = "b5_uq_gate",
              observed_factor: float = 1.0, observation_age_s: float = 0.0,
              now: float | None = None) -> dict:
        """Apply one step only; future actions are rechecked on later calls.

        Policy b1_direct is forbidden in this execution path.
        """
        if (not isinstance(proposal.request_id, str)
                or not ID_PATTERN.fullmatch(proposal.request_id)
                or proposal.grid_id != "toy5"
                or type(proposal.state_version) is not int or proposal.state_version < 0
                or policy not in ("b2_dc", "b3_ac", "b4_sequential", "b5_uq_gate")
                or not isinstance(proposal.setpoint_mw, (int, float))
                or not isfinite(proposal.setpoint_mw)
                or not isinstance(proposal.future_setpoints_mw, (tuple, list))
                or any(not isinstance(v, (int, float)) or not isfinite(v)
                       for v in proposal.future_setpoints_mw)
                or len(proposal.future_setpoints_mw) > 8
                or not isfinite(observed_factor) or not isfinite(observation_age_s)
                or not 0.2 <= observed_factor <= 3.0 or observation_age_s < 0):
            return {"verdict": "BLOCK", "reason": "invalid or unauthorized request"}
        if proposal.expires_at is not None and not isfinite(proposal.expires_at):
            return {"verdict": "BLOCK", "reason": "invalid expiry"}
        # Idempotency identifies the logical request, not a mutable sensor snapshot.
        payload = {"proposal": asdict(proposal), "policy": policy}
        digest = sha256(json.dumps(payload, sort_keys=True, allow_nan=False).encode()).hexdigest()

        def existing(db: sqlite3.Connection) -> dict | None:
            record = db.execute("SELECT fingerprint,response FROM receipts WHERE request_id=?",
                                (proposal.request_id,)).fetchone()
            if record is None:
                return None
            if record[0] != digest:
                return {"verdict": "BLOCK", "reason": "request_id reused with different payload"}
            return dict(json.loads(record[1]), replayed=True)

        with closing(self._db()) as db:
            replay = existing(db)
            if replay is not None:
                return replay
            snapshot = State(*db.execute("SELECT version,tick,generator_mw FROM state WHERE slot=1").fetchone(),
                             observation_age_s=observation_age_s)
        now = time.time() if now is None else now
        if not isfinite(now):
            return {"verdict": "BLOCK", "reason": "invalid clock"}
        if proposal.expires_at is not None and proposal.expires_at <= now:
            return {"verdict": "BLOCK", "reason": "request expired"}
        if proposal.state_version != snapshot.version:
            return {"verdict": "BLOCK", "reason": "stale state version", "current_version": snapshot.version}

        decision = decide(policy, toy5(), snapshot, proposal, observed_factor, self.band, self.config)
        response = decision.as_dict()
        with closing(self._db()) as db:
            try:
                db.execute("BEGIN IMMEDIATE")
                replay = existing(db)
                if replay is not None:
                    db.rollback()
                    return replay
                current = State(*db.execute("SELECT version,tick,generator_mw FROM state WHERE slot=1").fetchone())
                if current.version != snapshot.version:
                    db.rollback()
                    return {"verdict": "BLOCK", "reason": "state changed during verification",
                            "current_version": current.version}
                if proposal.expires_at is not None and proposal.expires_at <= time.time():
                    db.rollback()
                    return {"verdict": "BLOCK", "reason": "request expired before commit"}
                response["observed_load_factor"] = observed_factor
                response["observation_age_s"] = observation_age_s
                response["version_before"] = current.version
                response["version_after"] = current.version + int(decision.verdict == "ALLOW")
                response["replayed"] = False
                response["n1_coverage"] = {
                    "checked": len(decision.checked_outages), "total": len(toy5().lines)
                }
                if decision.verdict == "ALLOW":
                    db.execute("UPDATE state SET version=?,tick=?,generator_mw=? WHERE slot=1",
                               (current.version + 1, current.tick + 1, proposal.setpoint_mw))
                db.execute("INSERT INTO receipts VALUES(?,?,?)",
                           (proposal.request_id, digest, json.dumps(response, sort_keys=True)))
                db.commit()
                return response
            except Exception:
                db.rollback()
                raise
