import json
import tempfile
import unittest
from pathlib import Path

from griduq.study import evaluate_policies, export


class StudyTests(unittest.TestCase):
    def test_reproducible_seeded_counts(self):
        first = evaluate_policies(12, 19)
        second = evaluate_policies(12, 19)
        self.assertEqual(first, second)
        self.assertEqual(first['policies']['b5_uq_gate']['candidates'], 36)

    def test_same_hidden_oracle_labels_for_each_policy(self):
        result = evaluate_policies(7, 19)
        for key in ((case, step) for case in range(7) for step in range(3)):
            labels = {event['oracle_safe'] for event in result['events']
                      if (event['case'], event['step']) == key}
            self.assertEqual(len(labels), 1)

    def test_no_unsafe_direct_execution_path(self):
        result = evaluate_policies(12, 19)
        self.assertTrue(all(not row['allowed'] for row in result['events']
                            if row['policy'] == 'b0_stop'))

    def test_export_is_valid_json(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'results.json'
            produced = export(path, 8, 20)
            self.assertEqual(json.loads(path.read_text('utf-8')), produced)

    def test_held_out_calibration_is_reported(self):
        report = evaluate_policies(9, 19)
        self.assertIn('empirical_calibration_coverage', report)
        self.assertLessEqual(report['empirical_calibration_coverage'], 1.0)


if __name__ == '__main__':
    unittest.main()
