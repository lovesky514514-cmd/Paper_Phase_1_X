import unittest

from griduq.calibration import fit_errors
from griduq.checks import CheckConfig, decide
from griduq.model import Proposal, State, toy5


class ChecksTests(unittest.TestCase):
    def setUp(self):
        self.grid = toy5()
        self.state = State()
        self.band = fit_errors([0.015 + k * 0.0005 for k in range(80)])
        self.proposal = Proposal('x', 'toy5', 0, 45., (45.,))

    def run_policy(self, policy, **changes):
        config = CheckConfig(**changes)
        return decide(policy, self.grid, self.state, self.proposal, 1.0, self.band, config)

    def test_strict_gate_passes_and_reports_partial_contingency_scope(self):
        result = self.run_policy('b5_uq_gate')
        self.assertEqual(result.verdict, 'ALLOW')
        self.assertEqual(result.checked_outages, ('L01', 'L02'))
        self.assertEqual(result.checked_steps, 2)
        self.assertGreater(result.ac_calls, 0)
        self.assertLessEqual(result.budget_spent, 45)

    def test_unknown_risk_estimate_must_abstain(self):
        result = decide('b5_uq_gate', self.grid, self.state, self.proposal, 1.0, None)
        self.assertEqual(result.verdict, 'ABSTAIN')

    def test_insufficient_solver_budget_abstains(self):
        result = self.run_policy('b5_uq_gate', budget_units=2)
        self.assertEqual(result.verdict, 'ABSTAIN')
        self.assertLessEqual(result.budget_spent, 2)

    def test_sensor_stale_fails_closed(self):
        result = decide('b5_uq_gate', self.grid, State(observation_age_s=90),
                        self.proposal, 1., self.band)
        self.assertEqual(result.verdict, 'ABSTAIN')

    def test_over_ramp_fails_before_solver(self):
        proposal = Proposal('x', 'toy5', 0, 70., (70.,))
        outcome = decide('b5_uq_gate', self.grid, self.state, proposal, 1., self.band)
        self.assertEqual(outcome.verdict, 'BLOCK')
        self.assertEqual(outcome.budget_spent, 0)

    def test_future_ramp_fails_before_solver(self):
        proposal = Proposal('x', 'toy5', 0, 45., (0.,))
        self.assertEqual(decide('b5_uq_gate', self.grid, self.state, proposal,
                                1., self.band).verdict, 'BLOCK')

    def test_future_absence_abstains(self):
        proposal = Proposal('x', 'toy5', 0, 45., ())
        self.assertEqual(decide('b5_uq_gate', self.grid, self.state, proposal,
                                1., self.band).verdict, 'ABSTAIN')

    def test_unsafe_n1_is_blocked(self):
        proposal = Proposal('x', 'toy5', 0, 25., (25.,))
        result = decide('b5_uq_gate', self.grid, self.state, proposal, 1., self.band)
        self.assertEqual(result.verdict, 'BLOCK')
        self.assertIn('N-1', result.reason)

    def test_missing_contingency_fails_closed(self):
        self.assertEqual(self.run_policy('b5_uq_gate', contingencies=('NO_LINE',)).verdict, 'ABSTAIN')

    def test_quantile_requires_past_samples(self):
        with self.assertRaises(ValueError):
            fit_errors([0.01] * 3, alpha=0.01)

    def test_no_false_absolute_safety_claims(self):
        outcome = self.run_policy('b5_uq_gate')
        self.assertNotIn('certified', outcome.reason.lower())


if __name__ == '__main__':
    unittest.main()
