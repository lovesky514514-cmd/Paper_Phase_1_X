from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import tempfile
import time
import unittest

from griduq.calibration import fit_errors
from griduq.gateway import LocalGateway
from griduq.model import Proposal


class GatewayTests(unittest.TestCase):
    def setUp(self):
        self.workdir = tempfile.TemporaryDirectory()
        self.addCleanup(self.workdir.cleanup)
        self.path = Path(self.workdir.name) / 'gate.sqlite'
        band = fit_errors([0.02 + i * 0.0005 for i in range(80)])
        self.gateway = LocalGateway(self.path, band=band)
        self.proposal = Proposal('good', 'toy5', 0, 45., (45.,))

    def test_allow_only_commits_one_step(self):
        response = self.gateway.apply(self.proposal)
        self.assertEqual(response['verdict'], 'ALLOW')
        self.assertEqual(self.gateway.state().version, 1)
        self.assertEqual(self.gateway.state().generator_mw, 45)

    def test_exact_replay_survives_restart(self):
        first = self.gateway.apply(self.proposal)
        fresh = LocalGateway(self.path, band=self.gateway.band)
        second = fresh.apply(self.proposal)
        self.assertEqual(first['version_after'], second['version_after'])
        self.assertTrue(second['replayed'])
        self.assertEqual(fresh.state().tick, 1)

    def test_same_request_id_other_effect_fails(self):
        self.gateway.apply(self.proposal)
        changed = Proposal('good', 'toy5', 0, 46., (46.,))
        result = self.gateway.apply(changed)
        self.assertEqual(result['verdict'], 'BLOCK')
        self.assertIn('different', result['reason'])

    def test_expired_and_stale_do_not_commit(self):
        expired = Proposal('expiry', 'toy5', 0, 45., (45.,), time.time() - 10)
        self.assertEqual(self.gateway.apply(expired)['verdict'], 'BLOCK')
        stale = Proposal('stale', 'toy5', 2, 45., (45.,))
        self.assertEqual(self.gateway.apply(stale)['verdict'], 'BLOCK')
        self.assertEqual(self.gateway.state().version, 0)

    def test_direct_policy_denied_on_execution_path(self):
        self.assertEqual(self.gateway.apply(self.proposal, policy='b1_direct')['verdict'], 'BLOCK')

    def test_invalid_numeric_setpoint_fails_without_exception(self):
        invalid = Proposal('bad-nan', 'toy5', 0, float('nan'), (45.,))
        self.assertEqual(self.gateway.apply(invalid)['verdict'], 'BLOCK')

    def test_replay_uses_intent_not_mutable_sensor_readback(self):
        self.assertEqual(self.gateway.apply(self.proposal, observed_factor=1.0)['verdict'], 'ALLOW')
        second = self.gateway.apply(self.proposal, observed_factor=1.035)
        self.assertTrue(second['replayed'])
        self.assertEqual(self.gateway.state().version, 1)

    def test_unknown_grid_and_nonfinite_factor_rejected(self):
        wrong = Proposal('other', 'ieee14', 0, 45., (45.,))
        self.assertEqual(self.gateway.apply(wrong)['verdict'], 'BLOCK')
        self.assertEqual(self.gateway.apply(self.proposal, observed_factor=float('nan'))['verdict'], 'BLOCK')

    def test_concurrent_same_snapshot_cannot_both_commit(self):
        another = Proposal('second', 'toy5', 0, 45., (45.,))
        with ThreadPoolExecutor(max_workers=2) as pool:
            futures = [pool.submit(self.gateway.apply, p) for p in (self.proposal, another)]
            verdicts = [future.result()['verdict'] for future in futures]
        self.assertEqual(verdicts.count('ALLOW'), 1)
        self.assertEqual(self.gateway.state().version, 1)


if __name__ == '__main__':
    unittest.main()
