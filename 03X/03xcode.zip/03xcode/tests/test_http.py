import http.client
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import time
import unittest

ROOT = Path(__file__).resolve().parents[1]


class HttpTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.workdir = tempfile.TemporaryDirectory()
        with socket.socket() as s:
            s.bind(('127.0.0.1', 0))
            cls.port = s.getsockname()[1]
        cls.process = subprocess.Popen(
            [sys.executable, str(ROOT / 'scripts' / 'cli.py'), 'server',
             '--database', str(Path(cls.workdir.name) / 'http.db'), '--port', str(cls.port)],
            cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
            env={**os.environ, 'GRIDUQ_LOCAL_TOKEN': 'unit-test-token'})
        for _ in range(70):
            try:
                c = http.client.HTTPConnection('127.0.0.1', cls.port, timeout=1)
                c.request('GET', '/health')
                status = c.getresponse().status
                c.close()
                if status == 200:
                    break
            except OSError:
                time.sleep(0.05)
        else:
            cls.process.kill()
            raise RuntimeError('test server did not start')

    @classmethod
    def tearDownClass(cls):
        cls.process.terminate()
        try:
            cls.process.communicate(timeout=4)
        except subprocess.TimeoutExpired:
            cls.process.kill()
            cls.process.communicate()
        cls.workdir.cleanup()

    def request(self, method, route, data=None, token='unit-test-token'):
        connection = http.client.HTTPConnection('127.0.0.1', self.port, timeout=5)
        body = None if data is None else json.dumps(data)
        headers = {'Content-Type': 'application/json'}
        if token:
            headers['Authorization'] = 'Bearer ' + token
        connection.request(method, route, body, headers)
        response = connection.getresponse()
        status, content = response.status, json.loads(response.read())
        connection.close()
        return status, content

    @staticmethod
    def sample(request_id='http-demo', version=0):
        return {'proposal': {'request_id': request_id, 'grid_id': 'toy5',
                             'state_version': version, 'setpoint_mw': 50,
                             'future_setpoints_mw': [50]}}

    def test_bad_token_denied(self):
        self.assertEqual(self.request('POST', '/action', self.sample(), token='bad')[0], 401)

    def test_agent_cannot_supply_fake_sensor_or_policy(self):
        forged = self.sample('fake')
        forged['observed_factor'] = 0.1
        self.assertEqual(self.request('POST', '/action', forged)[0], 400)
        forged.pop('observed_factor')
        forged['policy'] = 'b1_direct'
        self.assertEqual(self.request('POST', '/action', forged)[0], 400)

    def test_request_runs_and_replays(self):
        status, first = self.request('POST', '/action', self.sample('http-demo'))
        self.assertEqual(status, 200)
        self.assertEqual(first['verdict'], 'ALLOW')
        _, replay = self.request('POST', '/action', self.sample('http-demo'))
        self.assertTrue(replay['replayed'])
        self.assertEqual(self.request('GET', '/state')[1]['version'], 1)

    def test_invalid_grid_denied(self):
        payload = self.sample('never')
        payload['proposal']['grid_id'] = 'ieee14'
        self.assertEqual(self.request('POST', '/action', payload)[1]['verdict'], 'BLOCK')


if __name__ == '__main__':
    unittest.main()
