"""Behavior tests assert known outcomes, not implementation call counts."""
import unittest

from griduq.model import toy5
from griduq.oracle import evaluate
from griduq.physics import safety_problem, solve_ac, solve_dc


class PhysicsTests(unittest.TestCase):
    def setUp(self):
        self.grid = toy5()

    def test_synthetic_nominal_ac_solution(self):
        ac = solve_ac(self.grid, 1.0, 45.0)
        self.assertTrue(ac.converged)
        self.assertIsNone(safety_problem(self.grid, ac))
        self.assertEqual(len(ac.voltages_pu), 5)
        self.assertTrue(all(0.94 <= v <= 1.06 for v in ac.voltages_pu))

    def test_dc_not_same_as_ac(self):
        dc = solve_dc(self.grid, 1.0, 45.0)
        ac = solve_ac(self.grid, 1.0, 45.0)
        self.assertTrue(dc.converged)
        self.assertGreater(abs(ac.line_mva['L02'] - dc.line_mva['L02']), 0.01)

    def test_outage_changes_flow(self):
        nominal = solve_ac(self.grid, 1.0, 25.0)
        outage = solve_ac(self.grid, 1.0, 25.0, outage='L02')
        self.assertTrue(outage.converged)
        self.assertNotIn('L02', outage.line_mva)
        self.assertGreater(outage.line_mva['L01'], nominal.line_mva['L01'])

    def test_real_physics_oracle_consistent_at_nominal(self):
        for generation in (10., 25., 40., 50.):
            normal = solve_ac(self.grid, 1.0, generation)
            independent = evaluate(self.grid, generation, 1.0)
            self.assertEqual(safety_problem(self.grid, normal) is None, independent.safe)

    def test_hidden_derating_is_detectable_by_oracle(self):
        self.assertTrue(evaluate(self.grid, 25., 1.).safe)
        self.assertFalse(evaluate(self.grid, 25., 1., derating={'L01': 0.60}).safe)

    def test_invalid_ac_outage_or_island_fails(self):
        # Small mesh stays connected when one line is lost.
        for name in self.grid.line_names():
            self.assertTrue(solve_ac(self.grid, 1.0, 45., outage=name).converged)


if __name__ == '__main__':
    unittest.main()
