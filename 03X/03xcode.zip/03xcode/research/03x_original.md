# 交叉学科 SCI 研究报告 03｜Agent × 电力系统 × 优化控制

> 研究计划版本：立项评估版｜资料检索截点：2026-10-20  
> **性质**：创新假设 + 可执行实验设计 + 已查到的相关研究与候选期刊；**不是**已完成实验、已验证算法或已获得投稿资格。  
> **面向**：Agent / 后端网关方向学生 + 有电力系统基础的共同作者。  
> **目标约束**：优先 SCIE、可选择无 APC 的传统/订阅发表、公开工具可复现、总经费尽量低。

## 0. 执行摘要

**建议论文题目（工作名，非已发表成果）：**  
**GridUQ-Gate: Uncertainty-Calibrated Sequential Safety Validation for Agent-Assisted Power Dispatch**  
**中文：面向智能体辅助电力调度的不确定性校准与多步安全验证网关。**

**一个主观点**：电力调度中的 *Agent 能解释目标、编排工具和提议方案*，但**是否能放行某一项调度行为，应由具有状态版本控制的独立物理校验器来决定**；而且单步的“看起来安全”并不足以保证连续多个动作在负荷扰动、模型误差与线路故障下仍可行。

**最值得检验的研究命题**：在相近求解预算与执行时延下，相比单次 DC 安全筛选和无筛选 Agent，`多步时域评估 + 状态不确定性校准 + 分层 AC/N-1 检查 + 明确拒绝/退回` 能否显著减少 *false-safe（错误放行）*，同时维持有用任务完成率与调度经济性？

**新颖性警报：** 2026 年的 TwinGridShield 已测试 DC 数字孪生动作放行及模型失配；PowerAgentBench-SS 已提供隐藏物理验证、工具调用预算和风险评分；VeraGrid-Agent、Grid-Agent、PFAgent、LLMs for Smart Grids Tutorial 已覆盖“Agent + 求解器 + 检查”核心范式。因此不应声称“首个 Agent 电网安全网关”。要提出**新的约束形式、方法与跨工况的公平比较**。详见 §5 与文献 [A02]、[A03]、[A09]、[A12]。

### 推荐科研路线

- **最小可交付：** Python 网关 + pandapower + IEEE 14/30/118 节点仿真 + 5 个基础策略 + 规则、状态噪声与断线故障注入；只在**离线仿真**下运行。
- **学术增强：** Grid2Op 顺序决策 + N-1 保障 + AC 潮流重算 + 不确定性集校准 + 2–3 个公开独立网络留出测试。
- **冲高要求版本：** 面向新能源波动的概率约束/鲁棒优化理论，外加跨网络迁移和统计区间；若只是给模型加安全规则，不适合投高层级电力期刊。

### 一句话选刊结论

有明显的电网调度经济收益和跨场景物理验证时，才值得将 **Applied Energy** 作为高目标；以配网/输电网调度算法为主，优先 **Electric Power Systems Research** 或 **Sustainable Energy, Grids and Networks**；以后端执行与分布式系统创新为主，可考虑 **Computers & Electrical Engineering / FGCS**。不要把 **IJEPES** 误列成零 APC（该刊已转为全 OA）。

---

## 1. 问题背景：为何不是“让 Agent 自动调电”

经典的电力优化关注出力、拓扑、潮流、电压、线路热稳定及 N-1 安全性。近年来 LLM Agent 擅长接收自然语言运行目标，组合潮流/OPF 工具，恢复错误，但容易混淆网架、单位、工况、容量及动作副作用。研究的关键不是文本准确率，而是**最终物理系统在干预后的状态是否满足工程约束**。

几个需要明确区分的层级：

| 层级 | Agent 可以负责 | 必须有何种独立证据 | 不应声称 |
|---|---|---|---|
| L0 信息查询 | 生成解释和检索 | 确认数据源及版本 | 查询正确等于调度安全 |
| L1 离线提案 | 给出设定值、候选措施 | 求解器潮流和约束检查 | 通过单一 DC 模型等于真实电网安全 |
| L2 仿真连续执行 | 连续多步选择策略 | 状态逐步更新、N-1/AC 重算 | 一次可行 = 全流程可行 |
| L3 数字孪生决策辅助 | 估计不确定性并给出建议 | 校准集、量测时间戳、授权审计 | 校准覆盖率 = 确定性零事故 |
| L4 真实电网闭环控制 | **当前不做** | 电网运营单位、硬件安全链、法规认证 | 学术模拟可代替生产安全认证 |

**安全定位**：本研究应仅使用离线数字仿真或获授权的实验台；网关不具有 SCADA/现场控制执行权限。对真实物理系统的动作，一律需要独立、合法的运营审批。

## 2. 研究问题与可证伪假设

- **RQ1（错误放行）**：在网架、负荷、状态估计和限额存在失配时，相比单点 DC 网关，所提方法能否减少经独立 AC/真实扰动 oracle 认定的越限动作？
- **RQ2（顺序效应）**：在不允许中途作弊式重置状态的前提下，加入未来 `H` 步可行性判断，是否比逐步贪心放行有更低的故障累积率？
- **RQ3（效率）**：相同的物理求解调用额度下，分层验证（静态筛选→AC→重要 N-1）是否更高效？是否有显著优于“对所有动作都检查全部约束”的性价比区间？
- **RQ4（收益）**：错误放行减少时，电费、切负荷、电池循环、线路重构成本和任务完成率是否恶化到不可接受？
- **RQ5（可信度）**：模型置信度不够时，网关能否明确弃权/转人工；弃权是否优于给出错误的“安全”结论？

**建议预注册假设（不应伪造为结果）**：H1 在强模型失配测试组降低错误放行概率；H2 用相同预算提高通过外部物理校验的任务成功率；H3 不出现未授权穿透执行路径。具体提升目标须先根据 baseline 预实验确定，不能提前写“下降 90%”。

## 3. 总体架构和责任边界

```text
                ┌──────────────────────┐
用户运行目标 ───→│ Agent: 理解任务、提案 │
                └──────────┬───────────┘
                           ↓ (无执行权限)
               ┌────────────────────────┐
               │ 网关 / typed action API │
               │ 版本号、权限、幂等、期限  │
               └──────────┬─────────────┘
                          ↓
         ┌────────────────────────────────┐
         │ GridUQ-Gate：研究方法主体       │
         │ 1. 物理可行性筛选              │
         │ 2. 不确定性/失配状态解释       │
         │ 3. 多步约束与N-1核查           │
         │ 4. 分层求解预算及弃权           │
         └───────────────┬────────────────┘
                         ↓
          ┌────────────────────────────────┐
          │ 放行 / 重新优化 / 拒绝 / 转人工 │
          └─────────────┬──────────────────┘
                        ↓
          仿真动作执行 → 独立AC复算 → 状态更新
                        ↓
                 可复核的审计日志
```

**不可混淆的主体：** Agent 负责*建议*，优化器负责*数值求解*，校验器负责*确定是否符合显式约束*，独立的外部 oracle 负责*最终实验评分*。不能让提案优化器与评测 oracle 共用同一套失配数据或完全同一误差参数，否则错误放行率会被人为压低。

### 3.1 网关 action schema（最小）

```json
{
  "request_id": "opaque-id",
  "grid_id": "ieee14",
  "state_version": 105,
  "action_type": "generator_redispatch",
  "target_id": "gen_2",
  "setpoint_mw": 32.0,
  "expires_at": "simulated-time",
  "declared_objective": "reduce_thermal_overload"
}
```

一旦 state_version 发生变化，该决定不再自动生效；必须基于新状态重新计算。审计需保留数据版本、约束集摘要、solver 版本、返回码与拒绝原因，不保留生产环境秘密。

## 4. 方法主创新与数学形式

### 创新点 I：状态失配下的“条件安全放行”

传统单次校验读取估计状态 `x_hat_t`，对提案 `a_t` 执行一次潮流。本文提出区分：观测 `y_t`、真实但不可完全观测的 `x_t`、网络模型 `M_t`，以及不确定性集 `U_t`。由只使用过去数据拟合的校准器产生 `U_t`，在有界集合内验算最差越限情况。

**示意模型（优化建模假设，非已经证明）**：

\[
\max_{u\in U_t} g_i(F_{M_t}(\hat x_t,a_t,u)) \le 0,\quad \forall i \in \mathcal H
\]

其中 `g_i` 是线路容量、母线电压、机组爬坡、储能 SOC 等**硬约束的裕度函数**；`F` 是选择的潮流/状态转移模型。若 AC 潮流不收敛、约束配置未知、数据过期或高风险分支未检查，返回 `ABSTAIN/ESCALATE`，不假设“未知就是安全”。

需要公开限定：若真实状态不在 `U_t`、拓扑报告错误、故障模型遗漏或执行链绕过网关，**不提供绝对安全保证**。概率覆盖只能在恰当的数据交换性、漂移和校准条件下讨论，不能机械宣称有 `1-alpha` 的物理安全率。

### 创新点 II：多步依赖与 N-1 联合约束

单步检查无法反映储能电量耗尽、机组爬坡、回路切换后的连锁线路拥塞。对当前候选生成有限长度的可行滚动策略，逐步更新 SOC、拓扑和功率流；每次实际执行后以最新量测重新规划。

\[
\min_{a_t,\ldots,a_{t+H-1}} \sum_{k=t}^{t+H-1}C(x_k,a_k)
\]
\[
\text{s.t.}\quad x_{k+1}=F(x_k,a_k,\xi_k),\qquad
 g_i(x_k,a_k,\xi_k,c)\le0,
\quad c\in\mathcal C_{N-1}.
\]

这里的 `N-1` 是指定且覆盖率可审计的单个故障集合，并不自动意味着所有未知故障均被检查。为了控制计算成本，可以先识别关键故障集合，但必须记录未覆盖部分，不能把子集检查叫完整 N-1 认证。

### 创新点 III：验证预算分配（质量—延迟—成本）

设计三个验证层：静态类型/物理单位与限额检查 → DC 快速筛选 → AC 潮流以及关键 N-1 重算；允许为更高风险候选分配更多求解预算。当检查预算耗尽时返回“验证不足”，而不是自动放行。

**总目标可设为**：软性能目标最小化

\[
J = \mathbb E[C_{\text{op}}] + \lambda_1\mathrm{CVaR}_{\alpha}(L_{\text{soft}})
+ \lambda_2 C_{\text{verify}} + \lambda_3 C_{\text{delay}},
\]

同时将 `\mathcal H` 中的安全限额作为**硬约束**，而不是用一个有限的惩罚系数兑换违规许可。严重情况下弃权、选择已验证的应急策略或人工处置；注意 `no-op` 只有通过当前工况的校验才可作为安全回退。

### 4.1 创新点之间的优先关系

- **主创新必须选一个**：建议把“**对失配敏感的有限时域、多预算分层校验**”作为主贡献。
- 将 AC/N-1 统一进网关、审计日志和 API 设计作为支撑贡献；它们单独不足以写成算法突破。
- 理论贡献可尝试“给定模型误差上界时的条件可行性结论”，但是必须说明误差集合构建、求解器收敛、数值容差和状态同步假设。没有严格证明时只能写“经实验支持的安全过滤”，不能称 certified safety。

## 5. 最直接的撞题分析（请第一周读完）

| 最近研究 | 已做的事情 | 本课题的可验证差异 | 避免的虚假创新 |
|---|---|---|---|
| TwinGridShield (A12, 2026) | DC 网络数字孪生动作授权，含模型失配试验 | 多动作滚动约束、可校准失配集、AC/N-1 物理核查及统一计算预算 | 不是第一个在动作前筛选 |
| PowerAgentBench-SS (A09, 2026) | 动作预算、隐藏求解、证据与 false-safe 指标 | 在相同 benchmark 上做**新方法**；新增多时步和模型失配试验 | 不是第一个提出验证预算或隐藏 oracle |
| PowerAgentBench-Dyn (A10, 2026) | 动态稳定性分析和工具预算 | 若未引入动态时域仿真，只能声称稳态约束安全 | 不能把稳态 N-1 当暂态稳定性 |
| LLMs and Agentic AI Systems for Smart Grids (A02, 2026) | solver-grounded 验证理念与多个案例 | 不确定性集、序列安全与量化选择策略 | 不能把 trusted solver 说成首创 |
| Grid-Agent (A03, 2025) | 多 Agent 规划、求解、沙箱检查 | 跨场景压力测试和独立校准误差模型 | 不是第一个多 Agent 调度框架 |
| VeraGrid-Agent (A06, 2026) | LLM+OPF 求解器 | 关注行动放行与连续安全，而非答案准确率 | 不是“首次模型连接求解器” |
| Safe RL VPP (C04, 2023) | 电力场景投影式安全 shield | 对语言工具 Agent + AC 多步误差研究 | 不是第一次把 RL 接电网安全层 |
| PFAgent (A13, 2026) | 交互潮流和迭代修复 | 外部误差及安全边界审计 | 不是首次纠错与可追溯运行 |

**go/no-go 判据**：假如仅在 IEEE 14 母线、与标签同源的 DC 验证器上达到“0 次不安全放行”，其证据强度基本不能支撑此新论文；应首先完成跨状态/跨模型外部 oracle 的独立评价。

---

## 6. 交叉学科可做的 8 个子课题

| 子方向 | 可形成的研究问题 | 需要掌握 | 单学生适配 |
|---|---|---|---|
| 电力系统×鲁棒优化 | 状态不确定集下的安全调度和验证 | 潮流、凸优化/鲁棒优化 | 中 |
| 电力系统×控制理论 | MPC 滚动调度与风险屏障组合 | MPC、时序约束 | 中高 |
| 电力系统×可靠性工程 | N-1 风险优先筛查与动态应急组合 | 故障概率、可靠性指标 | 高 |
| 电力系统×排队调度 | 求解器拥塞与验证调用预算联合分配 | 网关后端、排队模型 | 高 |
| 电力系统×因果诊断 | 动作导致的连锁越限归因 | 因果/反事实、干预 | 中高 |
| 电力系统×网络安全 | 工况篡改、重放请求对物理放行的影响 | API 鉴权/签名、威胁建模 | 高 |
| 电力系统×运筹学 | EV/储能/VPP 多时段机会约束调度 | MILP、随机优化 | 中 |
| 电力系统×数字孪生 | 模型漂移时的安全更新和再校准 | 状态估计、漂移监测 | 中高 |

本报告**聚焦第 1 + 2 + 4 个**（鲁棒调度、有限滚动时域、后端验证预算）；其余作为后续扩展，不建议一篇论文全部堆进去。

## 7. 实验与对照方案（不需要真实电网设备）

### 7.1 环境

1. 初版：`pandapower`（Python 统一建模/AC 潮流）；小网络 IEEE 14、30；IEEE 118 用于扩容/迁移。
2. 连续决策：`Grid2Op`；若考虑配电网储能/电压，可改用 `Gym-ANM` 或 `PowerGym`，不混用不兼容的 action space。
3. 第二套独立求解：`MATPOWER`、`PowerModels.jl` 或 PyPSA（按软件许可和实现成本选择）；与主求解器不同的 oracle 优先。
4. 时间序列：公开/合成负荷与可再生出力序列；合成曲线必须公开生成方法及随机种子，不可称“来自真实运行数据”。
5. 所有仿真工况写入版本号，保存网络拓扑、线路额定、母线基值、潮流容差、求解日志和重复次数。

### 7.2 5–7 个对照策略

| Baseline | 描述 | 用途 |
|---|---|---|
| B0 仅规则 | 固定阈值/保守不动作 | 安全但任务不一定完成 |
| B1 Agent-direct | Agent 提案，不设置物理拦截（仅沙箱模拟） | 度量风险缺口 |
| B2 DC-one-step | DC 单步越限校验 | 对齐 TwinGridShield 的概念基线（实现细节需公开） |
| B3 AC-all | 每个请求做 AC 检查，无智能预算 | 安全与延迟参考 |
| B4 Sequential-no-UQ | 多步预测但不使用误差校准 | 验证失配模块 |
| B5 Proposed | 多步 + UQ + AC/N-1 + 预算/弃权 | 完整方法 |
| B6 Optimizer-only | OPF/MPC 直接求解可行策略（无 LLM） | **必不可少**：回答 Agent 是否带来额外任务价值 |

**公平比较**：使用同一候选动作、同一任务和网架、同样硬约束及相近 solver 调用预算；给 Agent-direct 的操作始终限制在完全隔离的仿真环境。加入“相同时间预算”和“相同 solver 调用次数预算”两种设置。

### 7.3 故障注入维度

- 参数错配：负荷测量 ±5%、±10%、±20%，线路容量减额，线路导纳、变压器状态偏差；这只是设计水平而非真实分布假设。
- 拓扑故障：单线路退出、错误拓扑报告、开关状态迟延；严格区分 N-1 与 N-2。
- 时序不一致：Agent 请求使用过期 state_version；传感器滞后，候选动作超时。
- 经济压力：电价、负荷与可再生发电突变；提高切负荷惩罚，衡量经济后悔值。
- 对抗性操作（在仿真器中）：越限 setpoint、单位错位、重复调用、越权工具选择；只用于防御评估。

### 7.4 核心指标，不能只展示成功率

| 指标 | 计算口径 | 为什么重要 |
|---|---|---|
| False-safe rate | 不安全却被放行的动作数 / 独立 oracle 判定为不安全的候选动作数 | 直接衡量保护失败；也报每 1000 次操作 unsafe releases |
| Constraint violation | 经过真实仿真转移后的线路/电压/机组/SOC 越限频度与幅度 | 物理安全性 |
| Feasible-task completion | 在全部强约束下完成目标的任务比例 | 避免“全拒绝 = 最安全” |
| Load shed (MWh) | 按时间步积分 | 电力特有损失 |
| Operational cost | 发电成本、弃风弃光、储能磨损、线路重构 | 经济收益 |
| Regret | 相对具备同等信息和预算的优化基线（清楚说明 oracle 设定） | 性能竞争力 |
| Verified N-1 coverage | 被完整检查的单故障比例 | 防止虚假认证 |
| Abstain/escalate rate | 因证据不足拒绝/升级比例 | 衡量保守代价 |
| Runtime / P50 P95 | 网关延迟、求解调用、token 成本 | 工程部署可行性 |
| Drift calibration | 校准期与测试期误差集覆盖率 | 概率声明是否可靠 |

**统计**：建议每组至少多个独立种子、配对场景比较，报告 bootstrap 95% CI（或精确二项区间）、分网络结果、最坏组表现；罕见事件使用更大的独立故障注入样本。不能把 0/1000 直接当“零风险”，0 次的单侧 95% 上界近似为 `3/n`（独立同分布等前提）。

### 7.5 消融表

| 版本 | UQ | 多步 | AC | N-1 | 预算策略 | 目的 |
|---|---|---|---|---|---|---|
| M0 | × | × | DC | × | 固定 | 原始单次模型 |
| M1 | ✓ | × | DC | × | 固定 | 不确定性收益 |
| M2 | × | ✓ | AC | × | 固定 | 时序收益 |
| M3 | ✓ | ✓ | AC | × | 固定 | 核心方法不含故障 |
| M4 | ✓ | ✓ | AC | ✓ | 固定 | N-1 收益 |
| M5 | ✓ | ✓ | AC | ✓ | 自适应 | 完整版预算贡献 |

### 7.6 结果可信度审计

- 训练/校准/测试按时间与网架同时划分；不允许同网络同序列细微变体泄漏到不同 split。
- 独立 oracle 必须比给 Agent 的近似模型“更接近真值”；若两者都是相同 AC 网络参数，只能证明符合所编码约束。
- 求解不收敛、工具报错、超时、缺失量测一律单独统计，不可从分母剔除。
- 跨网络实验中保留负面结果：真实约束发现不可能同时做到安全 + 高完成率时，诚实报告 Pareto 权衡。
- 记录 GPU/CPU、RAM、单次求解成本和 API 账单；做真正的资源受限比较。

## 8. 代码设计（不进入不必要的重型训练）

```text
griduq-gate/
  README.md
  requirements.txt
  configs/
    networks.yaml
    hard_limits.yaml
    experiment.yaml
  grid_data/
    public_cases.md
  src/
    schema.py              # typed action + validated state version
    gateway.py             # request gate / idempotency / auth
    state_estimator.py     # 时间戳/量测一致性
    uncertainty.py         # 校准误差集合
    safety_checks.py       # static/DC/AC/N-1
    multi_step.py          # 滚动时域约束
    verifier_budget.py     # 验证开销分配
    fallback.py            # safe fallback / escalate
    evidence.py            # 审计与哈希
    oracle.py              # 独立评分器（不同参数/实现）
  agents/
    llm_adapter.py         # 可替换的模型接口
    scripted_planner.py    # 可重复的非 LLM 基线
  experiments/
    prepare_splits.py
    inject_faults.py
    run_ablation.py
    compute_metrics.py
  tests/
    test_no_bypass.py
    test_state_staleness.py
    test_physical_constraints.py
    test_oracle_independence.py
```

**推荐技术组合**：Python + FastAPI + pandapower + numpy/scipy；对电力优化用 CVXPY / Pyomo / HiGHS 等已有求解器。只在性能确实成为瓶颈时，把热路径写成 Go/Rust；不为“多语言”而增加复杂度。

## 9. 12 周可执行研究计划与停损标准

| 周期 | 任务 | 交付物 | 决策门槛 |
|---|---|---|---|
| 1–2 | 读完 A02/A03/A09/A12/A15 + 电网基础 | 撞题矩阵、物理变量字典、仿真成功运行 | 能解释 DC 与 AC 的适用差异 |
| 3 | 实装 typed API、状态版本、AC 真值检查 | `tests` 可复跑，结构化证据日志 | 不存在绕过网关的写入路径 |
| 4 | 实现 B0–B3 强基线 | IEEE14/30 基准表 | 不可只有自家算法无对照 |
| 5–6 | 构造非泄漏的负荷/额定/拓扑失配 | 预注册扰动种子、独立 oracle | baseline 下有非平凡 false-safe |
| 7 | 多步约束与低成本检查 | B4 与第一轮消融 | 相同预算下证明额外价值，否则缩题 |
| 8 | UQ/误差集校准 | coverage 和拒绝率曲线 | 若校准无效，不能宣称风险概率保证 |
| 9 | N-1 筛查与自适应预算 | B5 及不同预算曲线 | 说明未检查故障覆盖范围 |
| 10 | Grid2Op 或 Gym-ANM 连续运行 | 长时序与迁移实验 | 不止单步 DC 演示 |
| 11 | 统计、失败案例、复现包 | CI、表格、脚本、误差条 | 可信反例与局限齐全 |
| 12 | 论文写作、选刊二次核验 | 初稿、投稿清单 | 指向一项清晰、可重复的方法贡献 |

**停止或转向条件**：① 若 AC-all 比所提方法同样快且显著更安全，承认预算模块无效；② 若同一模型误差下新方法的 false-safe 无显著改善，缩减算法主张；③ 若 optimizer-only 稳定胜出且 Agent 并不提供新的任务功能，将论文重心转成安全优化而非强行做 Agent。

## 10. SCI 选刊：优先免费且周期透明

> **费用约束解释**：Elsevier 的混合出版期刊通常可选择**订阅（传统）发表，免 APC**；这不等于所有服务绝对免费。仍需核对超页、彩图、作者协议及政策变更。IEEE TSG 传统发表不需 OA APC，但可能收超页费。**论文是否 SCIE/当前中科院几区，应在正式投稿当天查 Clarivate MJL/JCR + 当年分区表，不能拿旧分区当永久事实。**
>
> **周期统计口径**：下列“投稿→录用”来自 2026-10 检索到的第三方期刊资料对出版商 Journal Insights 的*转录*，它们不是本次直接访问 Elsevier 原始页面得到的证据（ScienceDirect 部分页面抓取受限）。有冲突则显示区间；不能当保证，更不能把“首次决定”当录用天数。

| 期刊（电力/计算交叉相关性） | 免 APC 路径 | 参考投稿→录用时间 | 证据等级及适配意见 |
|---|---|---:|---|
| **Applied Energy** | 订阅发表 | **约 127 天** | 第三方转录；**高目标**，必须有能源收益、经济性和多个真实/标准网络工况 |
| **Energy Conversion and Management** | 订阅发表 | **约 107 天** | 第三方转录；只有多能源系统/转化与调度贡献扎实时适配，单纯工具 Agent 不适合 |
| **Electric Power Systems Research** | 订阅发表 | **约 117–183 天**（不同转录结果冲突） | 专业匹配高；对系统/调度实验更友好，须复核官方页面 |
| **Sustainable Energy, Grids and Networks** | 订阅发表 | **暂不提供可稳健核实的单一周期** | 电网 + 信息通信 + 不确定优化契合；不接收简单元启发式算法堆砌 |
| **Computers & Electrical Engineering** | 订阅发表 | **约 169 天** | 第三方转录；适合后端网关/电气计算交叉；请核实预警、收录和投稿政策 |
| **Future Generation Computer Systems** | 订阅发表 | **约 183 天** | 第三方转录；要突出分布式网关、资源和吞吐调度，而非泛化电网仿真 |
| **IEEE Transactions on Smart Grid** | Traditional（无 OA APC） | **官方称努力在约 3 个月完成审稿；不是录用周期** | 高目标；**超过指定篇幅有超页费**，故非无条件零支出 |
| **International Journal of Electrical Power & Energy Systems** | **无常规订阅免 APC 路线** | 不作为免费期刊 | 已转全 OA，须付 APC/依赖合规资助减免；不推荐给零费用约束 |

### 10.1 选刊优先级与条件

- **高要求冲刺**：Applied Energy。需要强调真实能源系统的经济收益、可复现风险建模与多场景鲁棒性，不建议仅凭“模型是 Agent”投。
- **专业主线**：Electric Power Systems Research / Sustainable Energy, Grids and Networks。适合明确的电力系统方法改进和物理仿真。
- **后端工程主线**：Computers & Electrical Engineering / FGCS。若验证预算、请求调度、尾延迟以及网关系统设计更突出。
- **理论偏强再考虑**：IEEE Transactions on Smart Grid。重视数学定义、可靠性、广泛严谨对比和论证，注意可能的超页费。

### 10.2 如何在投稿当天核验

1. Clarivate [Master Journal List](https://mjl.clarivate.com/) 通过标准 ISSN 查询当日 SCIE 收录；分区以所用评价体系的**明确年份**为准。
2. 期刊的正式 `Guide for Authors` / `Journal Insights`：逐项记录是否支持 `Subscription/Traditional`、额外页费及首轮/终审数据，截图存档。
3. 记录 `Submission to first decision`、`Submission to decision after review`、`Submission to acceptance` 三列，拒绝用第一列冒充第三列。
4. 投稿适配优先于速度：例如没有可量化的能源效益，*Applied Energy* 未必是正确目标；没有新方法，只靠案例，*SEGAN* 也明确可能不收。

### 10.3 出版政策、选刊原始参考

- Elsevier [Publishing options & subscription no-cost rule](https://www.elsevier.com/researcher/author/open-access/choice)
- Elsevier [Pricing / hybrid policy](https://www.elsevier.com/about/policies-and-standards/pricing)
- Elsevier [如何查 Journal Insights 审稿与出版周期](https://www.elsevier.support/publishing/answer/when-can-i-expect-a-decision-from-the-editor)
- Elsevier 官方 [Applied Energy](https://shop.elsevier.com/journals/applied-energy/0306-2619)
- Elsevier 官方 [Electric Power Systems Research](https://shop.elsevier.com/journals/electric-power-systems-research/0378-7796)
- Elsevier 官方 [Sustainable Energy, Grids and Networks](https://shop.elsevier.com/journals/sustainable-energy-grids-and-networks/2352-4677)
- IEEE PES 官方 [IEEE Transactions on Smart Grid 投稿和超页费说明](https://ieee-pes.org/publications/transactions-on-smart-grid/)
- 本轮第三方 **JournalCompass**（不可当出版商官方数据）：[Applied Energy](https://journalcompass.com/journals/applied-energy-03062619.html)、[ECM](https://journalcompass.com/journals/energy-conversion-and-management-01968904.html)、[EPSR](https://journalcompass.com/journals/electric-power-systems-research-03787796.html)、[C&EE](https://journalcompass.com/journals/computers-electrical-engineering-00457906.html)、[FGCS](https://journalcompass.com/journals/future-generation-computer-systems-the-international-journal-of-escien-0167739x.html)
- **特别排除**：网上有仿照 ScienceDirect 页面设计的第三方域名；不把这些页面视为 Elsevier 官方证据。

---

## 11. 文献检索说明与分级

本清单优先列出此次已搜索到的作者/出版机构页面、DOI、arXiv 原始条目，以及会议论文入口；按论文标题逐项校对关联性。**“预印本”不代表已被 SCI 同行评审**；会议/期刊论文也不代表目标研究一定有新颖性。与主课题最接近的先阅读 [A09]、[A12]、[A02]、[A03]、[A06]、[C04]、[B01]。正式写论文时还应更新 BibTeX、论文版本、DOI、已发表期刊信息。

### 11.1 直接竞争与 Agent+电网论文

- **[A01]** Operating smart grids by customizing large model agents（2026，正式期刊）。[原文/DOI](https://www.nature.com/articles/s44172-026-00709-1)。**关联**：电网大模型 Agent 与真实调度语境。**论文提示**：不能以“LLM 操作电网”作为新颖性本身。
- **[A02]** LLMs and Agentic AI Systems for Smart Grids: A Tutorial on Architectures and Applications（2026，预印本）。[原文/DOI](https://arxiv.org/abs/2607.18147)。**关联**：四类电网案例；求解器可信落地和验证门控。**论文提示**：求解器+验证门控已经被系统化提出。
- **[A03]** Semantic Reasoning Meets Numerical Precision: An LLM-Powered Multi-Agent System for Power Grid Control（2025，预印本）。[原文/DOI](https://arxiv.org/abs/2508.05702)。**关联**：Grid-Agent：多 Agent、数值求解、验证/回滚。**论文提示**：不能以“规划 Agent+验证 Agent”当作唯一贡献。
- **[A04]** SafePowerGraph-LLM: Novel Power Grid Graph Embedding and Optimization with Large Language Models（2025，预印本）。[原文/DOI](https://arxiv.org/abs/2501.07639)。**关联**：LLM 参与 OPF 和电网结构表示。**论文提示**：必须比较准确性、可行性和方法适用边界。
- **[A05]** Large Language Models integration in Smart Grids（2025，预印本）。[原文/DOI](https://arxiv.org/abs/2504.09059)。**关联**：智能电网 LLM 应用场景、困难及风险综述。**论文提示**：用于定位问题，不是实验方法本身。
- **[A06]** VeraGrid-Agent: Tool-Augmented LLMs for Distribution Optimal Power Flow at the Grid Edge（2026，预印本）。[原文/DOI](https://arxiv.org/abs/2607.25155)。**关联**：LLM 通过 VeraGrid 求解 D-OPF。**论文提示**：“接入 OPF 工具就能回答”已有工作。
- **[A07]** Enhancing LLMs for Power System Simulations: A Feedback-driven Multi-agent Framework（2024，预印本）。[原文/DOI](https://arxiv.org/abs/2411.16707)。**关联**：RAG、执行反馈、多 Agent 电力仿真。**论文提示**：仿真脚本生成与纠错不能再当唯一创新。
- **[A08]** Agentic Application in Power Grid Static Analysis: Automatic Code Generation and Error Correction（2026，预印本）。[原文/DOI](https://arxiv.org/abs/2604.09995)。**关联**：MCP + MATPOWER 自动静态分析和纠错。**论文提示**：MCP 接入已被探索。
- **[A09]** PowerAgentBench-SS: A Benchmark for Agentic AI in Power System Steady-State Studies（2026，预印本）。[原文/DOI](https://arxiv.org/abs/2606.18789)。**关联**：可执行稳态评价、有限验证预算和风险敏感分数。**论文提示**：本课题必须报告超过现有 benchmark 的独立贡献。
- **[A10]** PowerAgentBench-Dyn: A Benchmark for Agentic AI in Power System Dynamic Studies（2026，预印本）。[原文/DOI](https://arxiv.org/abs/2606.20401)。**关联**：动态研究任务与受限工具预算。**论文提示**：不要把稳态检查混称动态稳定性保障。
- **[A11]** RestoreBench: Can AI Agents Restore Power Flow Convergence?（2026，预印本）。[原文/DOI](https://arxiv.org/abs/2609.00384)。**关联**：潮流不收敛恢复基准、动作预算和工具反馈。**论文提示**：恢复动作和动态监测须另行对比。
- **[A12]** TwinGridShield: Consequence-Aware Runtime Authorization for LLM Grid-Agent Actions（2026，会议相关/预印本）。[原文/DOI](https://arxiv.org/abs/2608.15391)。**关联**：IEEE 14 母线 DC 数字孪生对动作做放行门控，并测试模型失配。**论文提示**：**直接竞争者**；仅复现单步验证无法构成新贡献。
- **[A13]** PFAgent: A Tractable and Self-Evolving Power-Flow Agent for Interactive Grid Analysis（2026，预印本）。[原文/DOI](https://arxiv.org/abs/2604.10846)。**关联**：潮流工具链、验证驱动修复与可追踪日志。**论文提示**：工具执行日志和自纠错已经有研究。
- **[A14]** GridMind: LLMs-Powered Agents for Power System Analysis and Operations（2025，正式会议）。[原文/DOI](https://doi.org/10.1145/3731599.3767409)。**关联**：电力系统分析与高性能计算 Agent。**论文提示**：对照平台工程化与系统贡献。
- **[A15]** Power Systems Agent Benchmark: Executable Evaluation of AI Agents in Electric Power Engineering（2026，预印本）。[原文/DOI](https://arxiv.org/abs/2606.20950)。**关联**：41 类可执行电力工程任务和外部验证。**论文提示**：评测必须基于物理后果，不只看文本。
- **[A16]** Large Language Model-based power dispatch agent: Framework, application and challenges（2026，正式期刊）。[原文/DOI](https://doi.org/10.1016/j.ijepes.2026.111653)。**关联**：大模型电力调度 Agent 框架和挑战。**论文提示**：需要区别于宏观框架讨论。

### 11.2 电力优化、公开基准和数值求解

- **[B01]** Learning to run a power network challenge for training topology controllers（2020，正式期刊）。[原文/DOI](https://doi.org/10.1016/j.epsr.2020.106635)。**关联**：L2RPN 任务和拓扑控制设置。**论文提示**：用于顺序调度与故障基线。
- **[B02]** Learning to Run a Power Network Challenge: a Retrospective Analysis（2021，正式会议）。[原文/DOI](https://proceedings.mlr.press/v133/marot21a.html)。**关联**：Grid2Op 公开测试框架。**论文提示**：多步任务优先的实验基础。
- **[B03]** Gym-ANM: Reinforcement Learning Environments for Active Network Management Tasks in Electricity Distribution Systems（2021，正式期刊）。[原文/DOI](https://doi.org/10.1016/j.egyai.2021.100092)。**关联**：主动配电网管理环境。**论文提示**：适合储能和可再生出力。
- **[B04]** Gym-ANM: Open-source software to leverage reinforcement learning for power system management in research and education（2021，软件论文）。[原文/DOI](https://doi.org/10.1016/j.simpa.2021.100092)。**关联**：Gym-ANM 软件实现。**论文提示**：与 B03 不同篇，可用于复现。
- **[B05]** PowerGym: A Reinforcement Learning Environment for Volt-Var Control in Power Distribution Systems（2022，正式会议）。[原文/DOI](https://proceedings.mlr.press/v168/fan22a.html)。**关联**：Volt-VAR 控制环境。**论文提示**：可拓展配网电压约束。
- **[B06]** MATPOWER: Steady-State Operations, Planning, and Analysis Tools for Power Systems Research and Education（2011，正式期刊）。[原文/DOI](https://doi.org/10.1109/TPWRS.2010.2051168)。**关联**：潮流/OPF 标准工具。**论文提示**：强基线和数值核验。
- **[B07]** Pandapower—An Open-Source Python Tool for Convenient Modeling, Analysis, and Optimization of Electric Power Systems（2018，正式期刊）。[原文/DOI](https://doi.org/10.1109/TPWRS.2018.2829021)。**关联**：Python 电力仿真及 OPF。**论文提示**：初期推荐使用。
- **[B08]** PowerModels.jl: An Open-Source Framework for Exploring Power Flow Formulations（2018，正式会议）。[原文/DOI](https://doi.org/10.23919/PSCC.2018.8442948)。**关联**：Julia 的 OPF 多建模表述。**论文提示**：独立优化对照。
- **[B09]** Zero Duality Gap in Optimal Power Flow Problem（2012，正式期刊）。[原文/DOI](https://authors.library.caltech.edu/records/89psq-3c794)。**关联**：OPF 凸优化理论。**论文提示**：避免把近似解误当严格可行。
- **[B10]** Convex Relaxation of Optimal Power Flow—Part I: Formulations and Equivalence（2014，正式期刊）。[原文/DOI](https://doi.org/10.1109/TCNS.2014.2309732)。**关联**：潮流建模与松弛等价。**论文提示**：提供严格数学工具。
- **[B11]** Convex Relaxation of Optimal Power Flow—Part II: Exactness（2014，正式期刊）。[原文/DOI](https://doi.org/10.1109/TCNS.2014.2323634)。**关联**：凸松弛何时精确。**论文提示**：了解优化保证的条件。
- **[B12]** Risk-limiting dispatch for integrating renewable power（2013，正式期刊）。[原文/DOI](https://doi.org/10.1016/j.ijepes.2012.07.048)。**关联**：多阶段风险约束调度。**论文提示**：风险预算思想并非新概念。
- **[B13]** Neural networks for power flow: Graph neural solver（2020，正式期刊）。[原文/DOI](https://doi.org/10.1016/j.epsr.2020.106547)。**关联**：GNN 潮流预测且关注物理损失。**论文提示**：近似模型不能替代独立真值求解器。

### 11.3 安全控制与 Agent 基础

- **[C01]** Constrained Policy Optimization（2017，正式会议）。[原文/DOI](https://proceedings.mlr.press/v70/achiam17a)。**关联**：CMDP 与优化过程的近约束保证。**论文提示**：用作安全 RL 对照。
- **[C02]** Safe Exploration in Continuous Action Spaces（2018，预印本）。[原文/DOI](https://arxiv.org/abs/1801.08757)。**关联**：连续控制的 safety layer。**论文提示**：筛选动作并非第一次提出。
- **[C03]** Recovery RL: Safe Reinforcement Learning with Learned Recovery Zones（2021，正式期刊）。[原文/DOI](https://doi.org/10.1109/LRA.2021.3070252)。**关联**：恢复策略与任务策略分离。**论文提示**：需比较干预/恢复成本。
- **[C04]** Safe Reinforcement Learning for Strategic Bidding of Virtual Power Plants in Day-Ahead Markets（2023，预印本）。[原文/DOI](https://arxiv.org/abs/2307.05812)。**关联**：含电网约束的投影安全屏障。**论文提示**：电力场景已有 safety shield。
- **[C05]** Benchmarking Safe Exploration in Deep Reinforcement Learning（2019，研究报告/预印本）。[原文/DOI](https://openai.com/index/benchmarking-safe-exploration-in-deep-reinforcement-learning/)。**关联**：Safety Gym 基准与安全 RL 指标。**论文提示**：安全约束需要独立计量。
- **[C06]** Generating Local Shields for Decentralised Partially Observable Markov Decision Processes（2026，预印本）。[原文/DOI](https://arxiv.org/abs/2604.06873)。**关联**：分布式局部 shield 和观测不全。**论文提示**：部分可观测约束已有理论参照。
- **[C07]** Control Barrier Functions: Theory and Applications（2019，正式会议）。[原文/DOI](https://arxiv.org/abs/1903.11199)。**关联**：控制障碍函数理论。**论文提示**：不要把 CBF 直接声称适用于非连续离散电网动作。
- **[C08]** Safe Reinforcement Learning via Shielding（2018，正式会议/预印本）。[原文/DOI](https://arxiv.org/abs/1708.08611)。**关联**：时序逻辑安全屏障。**论文提示**：动作前过滤已有工作。
- **[C09]** ReAct: Synergizing Reasoning and Acting in Language Models（2023，正式会议/预印本）。[原文/DOI](https://arxiv.org/abs/2210.03629)。**关联**：LLM 交替推理与工具操作。**论文提示**：Agent 调用流程基础。
- **[C10]** Toolformer: Language Models Can Teach Themselves to Use Tools（2023，正式会议/预印本）。[原文/DOI](https://arxiv.org/abs/2302.04761)。**关联**：模型工具调用范式。**论文提示**：工具调用不是电网特有创新。


## 12. 必须交给学弟的一页行动清单

1. **先复现**：Grid2Op + pandapower + IEEE14/30 的基本潮流/线路越限和一次重调度。
2. **再复现强基线**：TwinGridShield 概念上的 DC-one-step 和完整 AC-all；保持同一 action set 与求解预算。
3. **模拟最小反例**：构造一个 *DC 判断安全，而 AC 或真实参数 oracle 发现越限* 的工况（含公开 seed）。没有独立真值差异，就不要声称研究解决了模型失配。
4. **只选一条主新意**：推荐“连续动作 + 不确定集 + 受限验证调用”的组合。不能为凑字数同时做 RL、数字孪生、对抗训练、博弈和真实电网控制。
5. **获取领域协作者**：让熟悉潮流和 N-1 安全约束的人检查网络参数、额定值、限额、目标函数和约束合理性。
6. **先跑小实验再定刊**：若结果只支持计算机网关价值，选 C&EE/FGCS；若支持调度与能源效率价值，选 EPSR/SEGAN；强泛化/理论时冲 Applied Energy。

## 13. 关键风险与诚信边界

- **当前无实验结果**：本文所有算法优势、期刊路线和目标都是计划，不是既有科学结论。
- **SCIE 不是 JCR Q1 的同义词**：不能因期刊高影响因子而断言中国科学院分区或接受率。
- **不承诺几个月必录用**：公开审稿统计通常针对已录用稿件；拒稿和返修不可预测。
- **安全证明有限**：给定模型的校验成功不代表真实设备在未知扰动下必然安全；模型漂移会使保障失效。
- **仅限合法离线仿真研究**：不连接真实电网设备、SCADA/现场执行端，除非已有所有运营单位审批与隔离安全证明。

## 14. 最终立项判断

**建议指数（主观）**：研究上限 ★★★★☆；资源可行性 ★★★☆☆；电力系统知识门槛 ★★★★☆；与 2025–2026 年现有工作的撞题风险 ★★★★☆。

**我会优先支持：基于 Grid2Op/IEEE 公开基准 + 独立 AC 真值复算的有限时域安全网关，且让学弟负责 Agent/API/校验调度，让电力合作者负责 OPF、N-1 与误差模型。** 如果没有领域合作者，先做“小型电网数值安全筛选与验证预算”而不是将项目包装为真正安全可靠的智能电网调度。

---

*注：本 MD 在 2026-10-20 的公开可检索资料上制作；论文的研究边界、新颖性结论仍需要下一轮深入全文阅读与复现实验才能定稿。*
