@echo off
cd /d "%~dp0.."
py -3 scripts\start.py
if errorlevel 1 (
  echo Failed to start. See docs\DEBUG_INDEX.md
  pause
)
