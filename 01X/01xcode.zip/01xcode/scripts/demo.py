"""Run a small workflow against an already running local gateway."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python"))

from rabgate.demo import run  # noqa: E402 - local package import after path setup

if __name__ == "__main__":
    run()
