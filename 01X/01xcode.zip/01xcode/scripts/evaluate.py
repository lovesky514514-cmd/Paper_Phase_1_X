"""Launch offline pilot with default paired seeds, no Go server needed."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python"))

from rabgate.experiment import main  # noqa: E402 - local package import

if __name__ == "__main__":
    main()
