@echo off
cd /d "%~dp0.."
py -3 scripts\check.py
if errorlevel 1 (
  echo Check failed. See docs\DEBUG_INDEX.md
  pause
  exit /b 1
)
echo Check complete.
pause
