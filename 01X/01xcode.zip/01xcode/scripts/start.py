"""Build and run the loopback Go sandbox; delete its binary on exit."""
from __future__ import annotations

import os
from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    with tempfile.TemporaryDirectory(prefix="rabgate-run-") as folder:
        exe = Path(folder) / ("rabgate.exe" if os.name == "nt" else "rabgate")
        subprocess.run(["go", "build", "-o", str(exe), "./cmd/rabgate"],
                       cwd=ROOT, check=True)
        try:
            subprocess.run([str(exe)], cwd=ROOT, check=True)
        except KeyboardInterrupt:
            print("Sandbox stopped")


if __name__ == "__main__":
    main()
