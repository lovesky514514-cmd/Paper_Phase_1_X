"""Cross-platform self-check. No optional Python dependencies needed."""
from __future__ import annotations

import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]


def execute(command: list[str], env: dict | None = None) -> None:
    print("Running:", " ".join(command), flush=True)
    subprocess.run(command, cwd=ROOT, env=env, check=True, timeout=180)


def main() -> None:
    if sys.version_info < (3, 11):
        raise SystemExit("Python 3.11+ required")
    env = dict(os.environ)
    env["PYTHONPATH"] = str(ROOT / "python")
    execute(["go", "test", "./...", "-count=1"])
    execute(["go", "vet", "./..."])
    execute([sys.executable, "-m", "unittest", "discover", "-s", "tests", "-v"], env)
    execute([sys.executable, "-m", "rabgate.experiment", "--tasks", "100", "--seeds", "5"], env)
    print("PASS: Go, Python, HTTP and synthetic experiment")


if __name__ == "__main__":
    main()
