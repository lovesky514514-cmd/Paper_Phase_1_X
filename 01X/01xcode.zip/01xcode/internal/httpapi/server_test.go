package httpapi

import (
	"bytes"
	"encoding/json"
	"net/http/httptest"
	"strings"
	"testing"

	"example.org/rabgate/internal/core"
)

func TestHTTPGuardRejectsClientSuppliedFields(t *testing.T) {
	cfg := core.Config{Confidence: .99, MinSamples: 50, TaskBudget: 1, Hazards: map[string][]core.Hazard{}}
	h := (&Server{Engine: core.New(cfg)}).Handler()
	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, httptest.NewRequest("POST", "/v1/tasks", bytes.NewBufferString(`{"domain":"process","task_budget":999}`)))
	if rec.Code != 400 {
		t.Fatalf("budget injection status %d", rec.Code)
	}
	rec = httptest.NewRecorder()
	h.ServeHTTP(rec, httptest.NewRequest("POST", "/v1/tasks", bytes.NewBufferString(`{"domain":"process"}`)))
	if rec.Code != 201 {
		t.Fatal(rec.Body.String())
	}
	var result map[string]any
	if err := json.Unmarshal(rec.Body.Bytes(), &result); err != nil {
		t.Fatal(err)
	}
	id := result["task_id"].(string)
	body, _ := json.Marshal(map[string]any{"task_id": id, "request_id": "a", "expected_version": 1, "operation": "change_valve", "risk_upper": 0})
	rec = httptest.NewRecorder()
	h.ServeHTTP(rec, httptest.NewRequest("POST", "/v1/actions", bytes.NewReader(body)))
	if rec.Code != 400 {
		t.Fatalf("client-supplied risk accepted: %s", rec.Body.String())
	}
	rec = httptest.NewRecorder()
	h.ServeHTTP(rec, httptest.NewRequest("POST", "/v1/test/faults", bytes.NewBufferString(`{}`)))
	if rec.Code != 404 {
		t.Fatal("fault endpoint enabled by default")
	}
}
func TestInvalidJSONIsRejected(t *testing.T) {
	cfg := core.Config{Confidence: .99, MinSamples: 50, TaskBudget: 1}
	h := (&Server{Engine: core.New(cfg)}).Handler()
	req := httptest.NewRequest("POST", "/v1/tasks", bytes.NewBufferString(`{"domain":"workflow"}{"domain":"process"}`))
	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, req)
	if rec.Code != 400 {
		t.Fatal(rec.Body.String())
	}
	req = httptest.NewRequest("POST", "/v1/tasks", bytes.NewBufferString(`{"domain":"`+strings.Repeat("a", 9000)+`"}`))
	rec = httptest.NewRecorder()
	h.ServeHTTP(rec, req)
	if rec.Code != 413 {
		t.Fatalf("want 413 got %d", rec.Code)
	}
}
