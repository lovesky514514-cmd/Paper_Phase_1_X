// Package httpapi maps local JSON requests to trusted core actions.
package httpapi

import (
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"strings"

	"example.org/rabgate/internal/core"
)

type Server struct {
	Engine       *core.Engine
	EnableFaults bool
}

func (s *Server) Handler() http.Handler {
	m := http.NewServeMux()
	m.HandleFunc("GET /health", func(w http.ResponseWriter, r *http.Request) {
		reply(w, 200, map[string]string{"status": "ok", "mode": "synthetic-only"})
	})
	m.HandleFunc("POST /v1/tasks", s.create)
	m.HandleFunc("GET /v1/tasks/{id}", s.inspect)
	m.HandleFunc("POST /v1/actions", s.action)
	m.HandleFunc("GET /v1/audit/{id}", s.audit)
	if s.EnableFaults {
		m.HandleFunc("POST /v1/test/faults", s.inject)
	}
	return http.MaxBytesHandler(m, 8192)
}
func read(w http.ResponseWriter, r *http.Request, dest any) bool {
	defer r.Body.Close()
	dec := json.NewDecoder(r.Body)
	dec.DisallowUnknownFields()
	if err := dec.Decode(dest); err != nil {
		var tooLarge *http.MaxBytesError
		if errors.As(err, &tooLarge) {
			reply(w, 413, map[string]string{"error": "request body too large"})
			return false
		}
		reply(w, 400, map[string]string{"error": "invalid JSON: " + err.Error()})
		return false
	}
	var extra any
	if err := dec.Decode(&extra); !errors.Is(err, io.EOF) {
		reply(w, 400, map[string]string{"error": "multiple JSON values"})
		return false
	}
	return true
}
func reply(w http.ResponseWriter, status int, val any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(val)
}
func (s *Server) create(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Domain string `json:"domain"`
	}
	if !read(w, r, &req) {
		return
	}
	nonce := make([]byte, 12)
	if _, err := rand.Read(nonce); err != nil {
		reply(w, 500, map[string]string{"error": "cannot create task id"})
		return
	}
	id := hex.EncodeToString(nonce)
	snapshot, err := s.Engine.Create(id, req.Domain)
	if err != nil {
		reply(w, 400, map[string]string{"error": err.Error()})
		return
	}
	reply(w, 201, map[string]any{"task_id": id, "state": snapshot})
}
func (s *Server) action(w http.ResponseWriter, r *http.Request) {
	var a core.Action
	if !read(w, r, &a) {
		return
	}
	result, err := s.Engine.Execute(a)
	if err != nil {
		reply(w, 400, map[string]string{"error": err.Error()})
		return
	}
	reply(w, 200, result)
}
func (s *Server) inspect(w http.ResponseWriter, r *http.Request) {
	state, spent, ok := s.Engine.Inspect(r.PathValue("id"))
	if !ok {
		reply(w, 404, map[string]string{"error": "task not found"})
		return
	}
	reply(w, 200, map[string]any{"state": state, "risk_spent": spent})
}
func (s *Server) audit(w http.ResponseWriter, r *http.Request) {
	history, ok := s.Engine.Audit(r.PathValue("id"))
	if !ok {
		reply(w, 404, map[string]string{"error": "task not found"})
		return
	}
	reply(w, 200, map[string]any{"decisions": history})
}
func (s *Server) inject(w http.ResponseWriter, r *http.Request) {
	var req struct {
		TaskID string `json:"task_id"`
		Fault  string `json:"fault"`
	}
	if !read(w, r, &req) {
		return
	}
	if strings.TrimSpace(req.TaskID) == "" {
		reply(w, 400, map[string]string{"error": "missing task"})
		return
	}
	state, err := s.Engine.Inject(req.TaskID, req.Fault)
	if err != nil {
		reply(w, 400, map[string]string{"error": err.Error()})
		return
	}
	reply(w, 200, state)
}
