package core

import (
	"encoding/json"
	"math"
	"sync"
	"testing"
)

func exampleConfig() Config {
	return Config{Confidence: .99, MinSamples: 50, TaskBudget: 1.25, Hazards: map[string][]Hazard{
		"process.change_valve":  {{Event: "H_pressure", Severity: 5, Trials: 1000, Events: 5}},
		"workflow.approve_case": {{Event: "H_approve", Severity: 3, Trials: 1000, Events: 2}},
		"workflow.issue_credit": {{Event: "H_credit", Severity: 5, Trials: 1000, Events: 6}},
		"workflow.send_notice":  {{Event: "H_notice", Severity: 2, Trials: 1000, Events: 2}},
	}}
}
func act(task, id, op string, ver, value int) Action {
	return Action{TaskID: task, RequestID: id, Operation: op, ExpectedVersion: ver, Value: value}
}
func TestBudgetAndIdempotency(t *testing.T) {
	e := New(exampleConfig())
	_, _ = e.Create("p", "process")
	x, err := e.Execute(act("p", "a", "change_valve", 1, 1))
	if err != nil || x.Decision != "allow" || x.RiskSpent <= 0 {
		t.Fatalf("first action: %+v %v", x, err)
	}
	second, err := e.Execute(act("p", "a", "change_valve", 1, 1))
	if err != nil || second.Decision != "replay" || second.RiskSpent != x.RiskSpent {
		t.Fatalf("replay: %+v %v", second, err)
	}
	_, err = e.Execute(act("p", "a", "change_valve", 1, 0))
	if err == nil {
		t.Fatal("conflicting idempotency key accepted")
	}
	snap, spent, _ := e.Inspect("p")
	if snap.Pressure != 680 || spent != x.RiskSpent {
		t.Fatalf("duplicate effect: %+v", snap)
	}
}
func TestStaleAndAlarm(t *testing.T) {
	e := New(exampleConfig())
	_, _ = e.Create("p", "process")
	if got, _ := e.Execute(act("p", "stale", "change_valve", 0, 1)); got.Decision != "block" {
		t.Fatal(got)
	}
	_, _ = e.Inject("p", "high_pressure")
	if got, _ := e.Execute(act("p", "alarm", "change_valve", 2, 1)); got.Decision != "block" {
		t.Fatal(got)
	}
}
func TestUnknownRiskEscalates(t *testing.T) {
	cfg := exampleConfig()
	delete(cfg.Hazards, "workflow.issue_credit")
	e := New(cfg)
	_, _ = e.Create("w", "workflow")
	for _, a := range []Action{act("w", "r", "read_case", 1, 0), act("w", "a", "approve_case", 2, 0)} {
		if res, _ := e.Execute(a); res.Decision != "allow" {
			t.Fatal(res)
		}
	}
	if got, _ := e.Execute(act("w", "c", "issue_credit", 3, 0)); got.Decision != "escalate" {
		t.Fatal(got)
	}
}
func TestConcurrentDuplicateCredit(t *testing.T) {
	e := New(exampleConfig())
	_, _ = e.Create("w", "workflow")
	for _, a := range []Action{act("w", "r", "read_case", 1, 0), act("w", "a", "approve_case", 2, 0)} {
		_, _ = e.Execute(a)
	}
	var wg sync.WaitGroup
	results := make(chan string, 40)
	for i := 0; i < 40; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			d, _ := e.Execute(act("w", "credit", "issue_credit", 3, 0))
			results <- d.Decision
		}()
	}
	wg.Wait()
	close(results)
	allow, replay := 0, 0
	for r := range results {
		if r == "allow" {
			allow++
		}
		if r == "replay" {
			replay++
		}
	}
	s, _, _ := e.Inspect("w")
	if allow != 1 || replay != 39 || !s.Credited {
		t.Fatalf("allow=%d replay=%d state=%+v", allow, replay, s)
	}
}
func TestIndependentKeysStillCannotDuplicateCredit(t *testing.T) {
	e := New(exampleConfig())
	_, _ = e.Create("w", "workflow")
	for _, a := range []Action{act("w", "r", "read_case", 1, 0), act("w", "a", "approve_case", 2, 0), act("w", "c", "issue_credit", 3, 0)} {
		if d, _ := e.Execute(a); d.Decision != "allow" {
			t.Fatal(d)
		}
	}
	d, _ := e.Execute(act("w", "c2", "issue_credit", 4, 0))
	if d.Decision != "block" {
		t.Fatal(d)
	}
}
func TestBudgetExhaustion(t *testing.T) {
	cfg := exampleConfig()
	cfg.TaskBudget = .01
	e := New(cfg)
	_, _ = e.Create("p", "process")
	d, _ := e.Execute(act("p", "change", "change_valve", 1, 1))
	if d.Decision != "defer" || d.SuggestedAction != "hold" {
		t.Fatal(d)
	}
	if s, spent, _ := e.Inspect("p"); s.Pressure != 600 || spent != 0 {
		t.Fatal(s, spent)
	}
}
func TestUnknownAndZeroObservations(t *testing.T) {
	cfg := exampleConfig()
	cfg.Hazards["zero"] = []Hazard{{Event: "h", Severity: 1, Trials: 100, Events: 0}}
	v, ok := UpperRisk(cfg, "zero")
	if !ok || !(v > 0) {
		t.Fatal(v, ok)
	}
	cfg.Hazards["tiny"] = []Hazard{{Event: "h", Severity: 1, Trials: 10, Events: 0}}
	if _, ok := UpperRisk(cfg, "tiny"); ok {
		t.Fatal("small sample accepted")
	}
}
func TestBadConfig(t *testing.T) {
	for _, s := range []string{`{"confidence":2,"task_budget":1,"min_samples":50}`, `{"confidence":0.99,"task_budget":1,"min_samples":50,"hazards":{"x":[{"event":"x","severity":1,"trials":2,"events":3}]}}`} {
		if _, err := ParseConfig([]byte(s)); err == nil {
			t.Fatal(s)
		}
	}
	cfg := exampleConfig()
	r, _ := json.Marshal(cfg)
	if _, err := ParseConfig(r); err != nil {
		t.Fatal(err)
	}
	if v, ok := UpperRisk(cfg, "process.change_valve"); !ok || math.IsNaN(v) {
		t.Fatal(v)
	}
}
func TestTOCTOUVersionBound(t *testing.T) {
	e := New(exampleConfig())
	_, _ = e.Create("p", "process")
	first, _ := e.Execute(act("p", "r", "read_pressure", 1, 0))
	if first.Decision != "allow" {
		t.Fatal(first)
	}
	_, _ = e.Inject("p", "stale_sensor")
	d, _ := e.Execute(act("p", "a", "change_valve", 2, 1))
	if d.Decision != "block" {
		t.Fatal("stale optimistic write succeeded", d)
	}
}
func TestSafeStateInvariantSequence(t *testing.T) {
	e := New(exampleConfig())
	_, _ = e.Create("p", "process")
	for i := 0; i < 40; i++ {
		snap, _, _ := e.Inspect("p")
		op := "read_pressure"
		value := 0
		if i%2 == 1 {
			op = "change_valve"
			value = (i / 2) % 2
		}
		_, _ = e.Execute(act("p", string(rune('a'+i)), op, snap.Version, value))
		newState, spent, _ := e.Inspect("p")
		if newState.Pressure > 820 || spent > exampleConfig().TaskBudget+1e-12 {
			t.Fatal(newState, spent)
		}
	}
}
