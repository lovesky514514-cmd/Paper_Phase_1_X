// Package core owns the only state-changing path for synthetic tool backends.
// Callers never supply hazard samples, authoritative readings, or risk budgets.
package core

import (
	"crypto/sha256"
	"encoding/json"
	"errors"
	"fmt"
	"math"
	"sync"
)

type Hazard struct {
	Event    string  `json:"event"`
	Severity float64 `json:"severity"`
	Trials   int     `json:"trials"`
	Events   int     `json:"events"`
}
type Config struct {
	Note       string              `json:"note"`
	Confidence float64             `json:"confidence"`
	MinSamples int                 `json:"min_samples"`
	TaskBudget float64             `json:"task_budget"`
	Hazards    map[string][]Hazard `json:"hazards"`
}

func ParseConfig(data []byte) (Config, error) {
	var cfg Config
	if err := json.Unmarshal(data, &cfg); err != nil {
		return cfg, err
	}
	if !(cfg.Confidence > 0 && cfg.Confidence < 1) || cfg.MinSamples < 1 || !(cfg.TaskBudget > 0) || math.IsNaN(cfg.TaskBudget) || math.IsInf(cfg.TaskBudget, 0) {
		return cfg, errors.New("invalid risk configuration")
	}
	for key, hs := range cfg.Hazards {
		if key == "" || len(hs) == 0 {
			return cfg, errors.New("empty risk stratum")
		}
		for _, h := range hs {
			if h.Event == "" || h.Trials < 0 || h.Events < 0 || h.Events > h.Trials || !(h.Severity > 0) || math.IsInf(h.Severity, 0) || math.IsNaN(h.Severity) {
				return cfg, fmt.Errorf("invalid risk sample in %s", key)
			}
		}
	}
	return cfg, nil
}

// UpperRisk is a one-sided Hoeffding bound with Bonferroni adjustment.
// Its statistical interpretation requires representative independent trials.
// The sum is a severity-weighted risk PROXY, never an accident probability.
func UpperRisk(cfg Config, stratum string) (float64, bool) {
	hs := cfg.Hazards[stratum]
	if len(hs) == 0 {
		return 0, false
	}
	delta := (1 - cfg.Confidence) / float64(len(hs))
	var sum float64
	for _, h := range hs {
		if h.Trials < cfg.MinSamples {
			return 0, false
		}
		upper := math.Min(1, float64(h.Events)/float64(h.Trials)+math.Sqrt(math.Log(1/delta)/(2*float64(h.Trials))))
		sum += upper * h.Severity
	}
	return sum, !math.IsNaN(sum) && !math.IsInf(sum, 0)
}

type Snapshot struct {
	Version       int    `json:"version"`
	Domain        string `json:"domain"`
	Pressure      int    `json:"pressure_kpa,omitempty"`
	Valve         int    `json:"valve,omitempty"`
	SensorAgeMS   int    `json:"sensor_age_ms,omitempty"`
	SensorHealthy bool   `json:"sensor_healthy,omitempty"`
	Alarm         bool   `json:"alarm,omitempty"`
	CaseRead      bool   `json:"case_read,omitempty"`
	Approved      bool   `json:"approved,omitempty"`
	Credited      bool   `json:"credited,omitempty"`
	NoticeSent    bool   `json:"notice_sent,omitempty"`
}
type Action struct {
	TaskID          string `json:"task_id"`
	RequestID       string `json:"request_id"`
	ExpectedVersion int    `json:"expected_version"`
	Operation       string `json:"operation"`
	Value           int    `json:"value,omitempty"`
}
type Decision struct {
	Decision        string   `json:"decision"`
	Reason          string   `json:"reason"`
	TaskID          string   `json:"task_id"`
	RequestID       string   `json:"request_id"`
	Version         int      `json:"version"`
	RiskUpper       float64  `json:"risk_upper"`
	RiskSpent       float64  `json:"risk_spent"`
	Budget          float64  `json:"budget"`
	SuggestedAction string   `json:"suggested_action,omitempty"`
	Snapshot        Snapshot `json:"snapshot"`
}
type stored struct {
	fingerprint [32]byte
	decision    Decision
}
type task struct {
	state    Snapshot
	spent    float64
	requests map[string]stored
	audit    []Decision
}

// Engine keeps check, budget reservation and synthetic state mutation atomic.
// This single-process memory model is NOT a distributed transaction.
type Engine struct {
	mu    sync.Mutex
	cfg   Config
	tasks map[string]*task
}

func New(cfg Config) *Engine { return &Engine{cfg: cfg, tasks: make(map[string]*task)} }
func (e *Engine) Create(id, domain string) (Snapshot, error) {
	e.mu.Lock()
	defer e.mu.Unlock()
	if id == "" || len(id) > 120 || (domain != "process" && domain != "workflow") {
		return Snapshot{}, errors.New("invalid task")
	}
	if _, ok := e.tasks[id]; ok {
		return Snapshot{}, errors.New("task already exists")
	}
	s := Snapshot{Version: 1, Domain: domain}
	if domain == "process" {
		s.Pressure = 600
		s.SensorAgeMS = 80
		s.SensorHealthy = true
	}
	e.tasks[id] = &task{state: s, requests: make(map[string]stored)}
	return s, nil
}
func (e *Engine) Inspect(id string) (Snapshot, float64, bool) {
	e.mu.Lock()
	defer e.mu.Unlock()
	t, ok := e.tasks[id]
	if !ok {
		return Snapshot{}, 0, false
	}
	return t.state, t.spent, true
}
func (e *Engine) Audit(id string) ([]Decision, bool) {
	e.mu.Lock()
	defer e.mu.Unlock()
	t, ok := e.tasks[id]
	if !ok {
		return nil, false
	}
	return append([]Decision(nil), t.audit...), true
}
func (e *Engine) Execute(a Action) (Decision, error) {
	if a.TaskID == "" || a.RequestID == "" || len(a.TaskID) > 120 || len(a.RequestID) > 120 || a.Operation == "" {
		return Decision{}, errors.New("invalid action identity")
	}
	raw, _ := json.Marshal(a)
	fingerprint := sha256.Sum256(raw)
	e.mu.Lock()
	defer e.mu.Unlock()
	t, ok := e.tasks[a.TaskID]
	if !ok {
		return Decision{}, errors.New("unknown task")
	}
	if prior, exists := t.requests[a.RequestID]; exists {
		if prior.fingerprint != fingerprint {
			return Decision{}, errors.New("request_id reused with different payload")
		}
		result := prior.decision
		result.Decision = "replay"
		result.Reason = "previous decision replayed; no new effect"
		return result, nil
	}
	result := Decision{TaskID: a.TaskID, RequestID: a.RequestID, Version: t.state.Version, Budget: e.cfg.TaskBudget, RiskSpent: t.spent, Snapshot: t.state}
	switch {
	case a.ExpectedVersion != t.state.Version:
		result.Decision = "block"
		result.Reason = "stale state version"
	case !knownAction(t.state.Domain, a.Operation):
		result.Decision = "block"
		result.Reason = "unknown operation for domain"
	default:
		if reason := precondition(t.state, a); reason != "" {
			result.Decision = "block"
			result.Reason = reason
		} else {
			increment := 0.0
			if !readOnly(a.Operation) {
				var estimated bool
				increment, estimated = UpperRisk(e.cfg, t.state.Domain+"."+a.Operation)
				if !estimated {
					result.Decision = "escalate"
					result.Reason = "missing or insufficient risk evidence"
				}
			}
			result.RiskUpper = increment
			// A bounded stage heuristic reserves capacity for remaining risky work.
			// It is an allocation heuristic, not a statistical guarantee.
			if result.Decision == "" && increment > 0 {
				room := e.cfg.TaskBudget - t.spent
				if increment > 1.75*room/float64(remainingRiskSteps(t.state)) {
					result.Decision = "defer"
					result.Reason = "reserved risk capacity for later steps"
					if t.state.Domain == "process" {
						result.SuggestedAction = "hold"
					}
				}
			}
			if result.Decision == "" && t.spent+increment > e.cfg.TaskBudget+1e-12 {
				result.Decision = "defer"
				result.Reason = "risk budget exhausted"
				if t.state.Domain == "process" {
					result.SuggestedAction = "hold"
				}
			}
			if result.Decision == "" {
				apply(&t.state, a)
				t.spent += increment
				result.Decision = "allow"
				result.Reason = "trusted contract and budget passed"
				result.Version = t.state.Version
				result.Snapshot = t.state
				result.RiskSpent = t.spent
			}
		}
	}
	t.requests[a.RequestID] = stored{fingerprint: fingerprint, decision: result}
	t.audit = append(t.audit, result)
	return result, nil
}
func knownAction(domain, op string) bool {
	switch domain {
	case "process":
		return op == "read_pressure" || op == "change_valve" || op == "hold"
	case "workflow":
		return op == "read_case" || op == "approve_case" || op == "issue_credit" || op == "send_notice"
	}
	return false
}
func readOnly(op string) bool { return op == "read_pressure" || op == "read_case" || op == "hold" }
func precondition(s Snapshot, a Action) string {
	switch a.Operation {
	case "change_valve":
		if a.Value != 0 && a.Value != 1 {
			return "valve value must be 0 or 1"
		}
		if !s.SensorHealthy || s.SensorAgeMS > 250 {
			return "sensor evidence is invalid or stale"
		}
		if s.Alarm || s.Pressure > 700 {
			return "interlock: alarm or high pressure"
		}
		predicted := s.Pressure
		if a.Value == 1 && s.Valve == 0 {
			predicted += 80
		}
		if a.Value == 0 && s.Valve == 1 {
			predicted -= 80
		}
		if predicted > 820 {
			return "pressure invariant would be violated"
		}
	case "approve_case":
		if !s.CaseRead || s.Approved {
			return "case must be read and not already approved"
		}
	case "issue_credit":
		if !s.Approved || s.Credited {
			return "credit requires approval and cannot be duplicated"
		}
	case "send_notice":
		if !s.Approved || s.NoticeSent {
			return "notice requires approval and cannot be duplicated"
		}
	}
	return ""
}
func apply(s *Snapshot, a Action) {
	switch a.Operation {
	case "read_pressure":
		s.SensorAgeMS = 0
	case "change_valve":
		if a.Value == 1 && s.Valve == 0 {
			s.Pressure += 80
		}
		if a.Value == 0 && s.Valve == 1 {
			s.Pressure -= 80
		}
		s.Valve = a.Value
		s.SensorAgeMS = 300 // readback needed before further actuation
	case "read_case":
		s.CaseRead = true
	case "approve_case":
		s.Approved = true
	case "issue_credit":
		s.Credited = true
	case "send_notice":
		s.NoticeSent = true
	}
	s.Version++
}

// Inject is a test-only way to change synthetic backend observations.
func (e *Engine) Inject(id, fault string) (Snapshot, error) {
	e.mu.Lock()
	defer e.mu.Unlock()
	t, ok := e.tasks[id]
	if !ok {
		return Snapshot{}, errors.New("unknown task")
	}
	if t.state.Domain != "process" {
		return Snapshot{}, errors.New("fault only for process")
	}
	switch fault {
	case "stale_sensor":
		t.state.SensorAgeMS = 1000
	case "broken_sensor":
		t.state.SensorHealthy = false
	case "high_pressure":
		t.state.Pressure = 760
		t.state.Alarm = true
	default:
		return Snapshot{}, errors.New("unknown fault")
	}
	t.state.Version++
	return t.state, nil
}

// remainingRiskSteps is a small synthetic task-template estimate.
// Real use would need an authenticated, versioned task graph instead.
func remainingRiskSteps(s Snapshot) int {
	if s.Domain == "process" {
		if s.Valve == 0 {
			return 2
		}
		return 1
	}
	if !s.Approved {
		return 3
	}
	if !s.Credited {
		return 2
	}
	return 1
}
