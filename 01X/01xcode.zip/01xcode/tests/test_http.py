"""Integration tests against a real, temporary Go executable on loopback."""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
import json
import os
from pathlib import Path
import socket
import subprocess
import tempfile
import time
import unittest

from rabgate.client import GatewayClient

ROOT = Path(__file__).resolve().parents[1]


def free_port() -> int:
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


class HTTPTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.folder = tempfile.TemporaryDirectory(prefix="rabgate-test-")
        cls.executable = Path(cls.folder.name) / ("rabgate.exe" if os.name == "nt" else "rabgate")
        subprocess.run(["go", "build", "-o", str(cls.executable), "./cmd/rabgate"],
                       cwd=ROOT, check=True, capture_output=True, timeout=120)
        cls.port = free_port()
        cls.process = subprocess.Popen(
            [str(cls.executable), "-addr", f"127.0.0.1:{cls.port}", "-test-faults"],
            cwd=ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
        )
        cls.client = GatewayClient(f"http://127.0.0.1:{cls.port}")
        for _ in range(100):
            if cls.process.poll() is not None:
                raise RuntimeError("Go gateway quit on startup")
            try:
                if cls.client._json("GET", "/health")["status"] == "ok":
                    break
            except RuntimeError:
                time.sleep(.05)
        else:
            cls.process.terminate()
            raise RuntimeError("Go gateway did not become healthy")

    @classmethod
    def tearDownClass(cls):
        cls.process.terminate()
        try:
            cls.process.communicate(timeout=5)
        except subprocess.TimeoutExpired:
            cls.process.kill()
            cls.process.communicate(timeout=5)
        cls.folder.cleanup()

    def test_process_replay_and_readback(self):
        task, state = self.client.create("process")
        first = self.client.act(task, "a", "change_valve", state["version"], 1)
        self.assertEqual(first["decision"], "allow")
        self.assertEqual(first["snapshot"]["pressure_kpa"], 680)
        retry = self.client.act(task, "a", "change_valve", state["version"], 1)
        self.assertEqual(retry["decision"], "replay")
        self.assertEqual(self.client.inspect(task)["state"]["pressure_kpa"], 680)
        self.assertEqual(len(self.client.audit(task)["decisions"]), 1)
        stale = self.client.act(task, "b", "change_valve", state["version"], 0)
        self.assertEqual(stale["decision"], "block")

    def test_sensor_fault_denied_with_current_version(self):
        task, _ = self.client.create("process")
        fault = self.client._json("POST", "/v1/test/faults",
                                  {"task_id": task, "fault": "broken_sensor"})
        d = self.client.act(task, "attempt", "change_valve", fault["version"], 1)
        self.assertEqual(d["decision"], "block")
        self.assertEqual(self.client.inspect(task)["state"]["pressure_kpa"], 600)

    def test_concurrent_credit_does_not_duplicate(self):
        task, state = self.client.create("workflow")
        for request, operation in (("read", "read_case"), ("approve", "approve_case")):
            decision = self.client.act(task, request, operation, state["version"])
            self.assertEqual(decision["decision"], "allow")
            state = decision["snapshot"]
        with ThreadPoolExecutor(max_workers=12) as pool:
            decisions = list(pool.map(
                lambda _: self.client.act(task, "credit", "issue_credit", state["version"])["decision"],
                range(24),
            ))
        self.assertEqual(decisions.count("allow"), 1)
        self.assertEqual(decisions.count("replay"), 23)
        final_state = self.client.inspect(task)["state"]
        self.assertTrue(final_state["credited"])
        blocked = self.client.act(task, "credit-2", "issue_credit", final_state["version"])
        self.assertEqual(blocked["decision"], "block")

    def test_rejects_client_budget_override(self):
        with self.assertRaises(RuntimeError):
            self.client._json("POST", "/v1/tasks", {"domain": "process", "task_budget": 99})

    def test_unknown_action_and_bad_reuse(self):
        task, state = self.client.create("workflow")
        rejected = self.client.act(task, "x", "send_payment", state["version"])
        self.assertEqual(rejected["decision"], "block")
        with self.assertRaises(RuntimeError):
            self.client.act(task, "x", "issue_credit", state["version"])

    def test_loopback_only_client(self):
        for url in ("https://example.com", "http://127.0.0.1:123@evil.example"):
            with self.subTest(url=url), self.assertRaises(ValueError):
                GatewayClient(url)


if __name__ == "__main__":
    unittest.main()
