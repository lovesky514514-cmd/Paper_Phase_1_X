"""Small, deterministic statistical and policy boundary tests."""
import copy
import json
from pathlib import Path
import unittest

from rabgate.risk import risk_proxy
from rabgate.experiment import Candidate, evaluate, gate, run, workload

ROOT = Path(__file__).resolve().parents[1]
CONFIG = json.loads((ROOT / "contracts/risk_samples.json").read_text("utf-8"))


class RiskTest(unittest.TestCase):
    def test_zero_events_have_nonzero_upper_bound(self):
        h = [{"trials": 100, "events": 0, "severity": 5}]
        self.assertEqual(risk_proxy(h, .99, 50, upper=False), 0)
        self.assertGreater(risk_proxy(h, .99, 50), 0)

    def test_insufficient_data_is_unknown(self):
        h = [{"trials": 2, "events": 0, "severity": 1}]
        self.assertIsNone(risk_proxy(h, .99, 50))
        self.assertIsNone(risk_proxy([], .99, 50))

    def test_severity_is_part_of_risk_proxy(self):
        h = [{"trials": 1000, "events": 5, "severity": 1}]
        low = risk_proxy(h, .99, 50)
        h[0]["severity"] = 5
        self.assertAlmostEqual(risk_proxy(h, .99, 50), 5 * low)

    def test_unknown_stratum_never_passes_risky_action(self):
        candidate = Candidate(0, 2, "workflow", "issue_credit", True, "missing", True)
        allowed, _ = gate("ours_upper_dynamic", candidate, 0, CONFIG)
        self.assertFalse(allowed)

    def test_oracle_labels_are_not_policy_inputs(self):
        item = Candidate(0, 2, "workflow", "issue_credit", True,
                         "workflow.issue_credit", True)
        other = Candidate(0, 2, "workflow", "issue_credit", True,
                          "workflow.issue_credit", False)
        for policy in ("B2_fixed_rules", "B3_point_threshold", "B4_fixed_budget", "ours_upper_dynamic"):
            self.assertEqual(gate(policy, item, 0, CONFIG), gate(policy, other, 0, CONFIG))

    def test_synthetic_evaluation_is_reproducible(self):
        a = run(CONFIG, [1, 2], 25)
        b = run(CONFIG, [1, 2], 25)
        self.assertEqual(a, b)
        self.assertEqual(len(a["rows"]), 12)

    def test_ours_never_spends_over_budget(self):
        for seed in range(10):
            summary = evaluate(workload(seed, 75, .15), "ours_upper_dynamic", CONFIG)
            self.assertEqual(summary["proxy_budget_violations"], 0)

    def test_budget_denial_changes_no_state(self):
        cfg = copy.deepcopy(CONFIG)
        cfg["task_budget"] = 0.001
        item = Candidate(0, 1, "process", "change_valve", True,
                         "process.change_valve", True)
        self.assertFalse(gate("ours_upper_dynamic", item, 0, cfg)[0])

    def test_read_only_policy_has_no_dangerous_external_writes(self):
        summary = evaluate(workload(0, 50), "B1_read_only", CONFIG)
        self.assertEqual(summary["unsafe_executions"], 0)


if __name__ == "__main__":
    unittest.main()
