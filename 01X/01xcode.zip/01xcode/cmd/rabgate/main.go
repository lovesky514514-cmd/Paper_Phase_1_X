// rabgate serves a local, synthetic tool gateway for experiments only.
package main

import (
	"flag"
	"log"
	"net"
	"net/http"
	"os"
	"time"

	"example.org/rabgate/internal/core"
	"example.org/rabgate/internal/httpapi"
)

func main() {
	addr := flag.String("addr", "127.0.0.1:8938", "loopback listener")
	samples := flag.String("samples", "contracts/risk_samples.json", "server-owned demo risk samples")
	faults := flag.Bool("test-faults", false, "expose synthetic fault injection")
	flag.Parse()
	host, _, err := net.SplitHostPort(*addr)
	if err != nil || host != "127.0.0.1" {
		log.Fatal("only 127.0.0.1 is accepted")
	}
	data, err := os.ReadFile(*samples)
	if err != nil {
		log.Fatal(err)
	}
	cfg, err := core.ParseConfig(data)
	if err != nil {
		log.Fatal(err)
	}
	server := http.Server{Addr: *addr, Handler: (&httpapi.Server{Engine: core.New(cfg), EnableFaults: *faults}).Handler(), ReadHeaderTimeout: 5 * time.Second}
	log.Printf("RAB-Gate synthetic sandbox http://%s; no real tools", *addr)
	log.Fatal(server.ListenAndServe())
}
