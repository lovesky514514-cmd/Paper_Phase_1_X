# 架构与接口

`Agent / Python client → Go HTTP → Engine(锁) → 虚构过程 / 工单状态`。
`Python experiment → 独立成对合成用例 / 策略比较`（不绕到真实设备）。

核心接口：

- `POST /v1/tasks`：只接受 `{"domain":"process"}` 或 `{"domain":"workflow"}`；服务器分配随机任务 ID 和统一预算。
- `GET /v1/tasks/{id}`：当前可信状态与风险花费。
- `POST /v1/actions`：`task_id, request_id, expected_version, operation, value`；所有检查与提交一同完成。
- `GET /v1/audit/{id}`：这个进程生存期内的脱敏决策历史。
- `GET /health`：本地健康检查。
- `POST /v1/test/faults`：仅启动时显式带 `-test-faults` 才暴露；模拟传感器故障、过期、高压。

执行次序：查请求 ID → 版本与操作检查 → 人工危险合约 → 统计证据 → 预算（包含阶段保留）→ 提交真实模拟状态和花费 → 记录审计。并发请求共享 Go 锁，保证**单进程内**操作原子性。

风险算法：对 `k/n`，取 `min(1, k/n + sqrt(log(m/delta)/(2n)))`；其中 `m` 为风险事件种类数，`delta=1-confidence`。乘预设严重度后求和。采用 Hoeffding + Bonferroni，并不意味着训练集具有所需统计独立性。

部署边界：仅监听 `127.0.0.1`；无鉴权、无磁盘 WAL、无跨进程共识。审计在内存，进程退出丢失。严禁接生产后端或开放公网。
