# CODING_STANDARDS.md

**职责**：Local code quality contract。

**自检**：`go vet ./... && python scripts/check.py`。

**常见故障与修复**：Use as review checklist; trace behavior to original report and trusted Go model.

**修改后**：在解压根目录运行 `python scripts/check.py`；如涉及并发/账本，再运行 `go test -race ./...`。
不要直接修改保存的实验数字，也不要绕开安全拒绝来消除测试失败。
