# results/ood_pilot.json

**职责**：Generated shifted synthetic pilot data。

**自检**：`python scripts/evaluate.py --tasks 100 --seeds 5 --drift 0.2 --out results/ood_pilot.json`。

**常见故障与修复**：Recheck shift flag and seed count before comparing with pilot.json.

**修改后**：在解压根目录运行 `python scripts/check.py`；如涉及并发/账本，再运行 `go test -race ./...`。
不要直接修改保存的实验数字，也不要绕开安全拒绝来消除测试失败。
