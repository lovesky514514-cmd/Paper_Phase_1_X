# research/01x_original.md

**职责**：Unmodified user-provided first cross-disciplinary proposal。

**自检**：`no executable command`。

**常见故障与修复**：This is a reference: do not mistake proposal thresholds or goals for experimental results.

**修改后**：在解压根目录运行 `python scripts/check.py`；如涉及并发/账本，再运行 `go test -race ./...`。
不要直接修改保存的实验数字，也不要绕开安全拒绝来消除测试失败。
