# contracts/risk_samples.json

**职责**：Trusted synthetic counts, severity and budget。

**自检**：`go test ./... && python scripts/evaluate.py`。

**常见故障与修复**：Keep 0 <= events <= trials and confidence (0,1). Treat fictional values as research-only; do not tune solely to win.

**修改后**：在解压根目录运行 `python scripts/check.py`；如涉及并发/账本，再运行 `go test -race ./...`。
不要直接修改保存的实验数字，也不要绕开安全拒绝来消除测试失败。
