# scripts/demo.py

**职责**：Import-safe demo wrapper。

**自检**：`python scripts/demo.py`。

**常见故障与修复**：Server must be running. Change neither root discovery nor localhost-only target.

**修改后**：在解压根目录运行 `python scripts/check.py`；如涉及并发/账本，再运行 `go test -race ./...`。
不要直接修改保存的实验数字，也不要绕开安全拒绝来消除测试失败。
