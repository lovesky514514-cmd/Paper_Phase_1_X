# scripts/start_windows.bat

**职责**：Windows one-command server start。

**自检**：`scripts\start_windows.bat`。

**常见故障与修复**：Install Python and Go, check firewall/port, keep the console open.

**修改后**：在解压根目录运行 `python scripts/check.py`；如涉及并发/账本，再运行 `go test -race ./...`。
不要直接修改保存的实验数字，也不要绕开安全拒绝来消除测试失败。
