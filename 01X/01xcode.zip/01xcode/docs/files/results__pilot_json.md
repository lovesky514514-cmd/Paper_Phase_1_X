# results/pilot.json

**职责**：Generated default pilot data。

**自检**：`python scripts/evaluate.py --tasks 100 --seeds 5`。

**常见故障与修复**：Compare metadata and paired seeds; rerun after changing the policy rather than editing results.

**修改后**：在解压根目录运行 `python scripts/check.py`；如涉及并发/账本，再运行 `go test -race ./...`。
不要直接修改保存的实验数字，也不要绕开安全拒绝来消除测试失败。
