# scripts/check.py

**职责**：End-to-end self-check entry point。

**自检**：`python scripts/check.py`。

**常见故障与修复**：Check Python and Go PATH; read first failed test rather than rerunning without diagnosis.

**修改后**：在解压根目录运行 `python scripts/check.py`；如涉及并发/账本，再运行 `go test -race ./...`。
不要直接修改保存的实验数字，也不要绕开安全拒绝来消除测试失败。
