# scripts/check.sh

**职责**：Unix one-command self-check。

**自检**：`sh scripts/check.sh`。

**常见故障与修复**：Run from extracted ZIP; check python3 and go executable permissions.

**修改后**：在解压根目录运行 `python scripts/check.py`；如涉及并发/账本，再运行 `go test -race ./...`。
不要直接修改保存的实验数字，也不要绕开安全拒绝来消除测试失败。
