# scripts/start.sh

**职责**：Unix one-command server start。

**自检**：`sh scripts/start.sh`。

**常见故障与修复**：Verify Go build and port availability; Ctrl+C stops the server.

**修改后**：在解压根目录运行 `python scripts/check.py`；如涉及并发/账本，再运行 `go test -race ./...`。
不要直接修改保存的实验数字，也不要绕开安全拒绝来消除测试失败。
