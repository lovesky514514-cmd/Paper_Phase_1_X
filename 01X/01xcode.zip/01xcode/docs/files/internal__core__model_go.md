# internal/core/model.go

**职责**：State machine, hazard gate and atomic risk accounting。

**自检**：`go test ./internal/core -v`。

**常见故障与修复**：Reproduce with a core test, check version and precondition order; never remove locks or default denials.

**修改后**：在解压根目录运行 `python scripts/check.py`；如涉及并发/账本，再运行 `go test -race ./...`。
不要直接修改保存的实验数字，也不要绕开安全拒绝来消除测试失败。
