# python/rabgate/demo.py

**职责**：Process and workflow live HTTP demo。

**自检**：`python scripts/demo.py`。

**常见故障与修复**：First start python scripts/start.py in another terminal; inspect blocked reason and current version.

**修改后**：在解压根目录运行 `python scripts/check.py`；如涉及并发/账本，再运行 `go test -race ./...`。
不要直接修改保存的实验数字，也不要绕开安全拒绝来消除测试失败。
