# python/rabgate/experiment.py

**职责**：Paired synthetic workload and six approximate policies。

**自检**：`python scripts/evaluate.py --tasks 25 --seeds 2`。

**常见故障与修复**：Check seed/hidden labels and observed fields; never feed true_safe into gate().

**修改后**：在解压根目录运行 `python scripts/check.py`；如涉及并发/账本，再运行 `go test -race ./...`。
不要直接修改保存的实验数字，也不要绕开安全拒绝来消除测试失败。
