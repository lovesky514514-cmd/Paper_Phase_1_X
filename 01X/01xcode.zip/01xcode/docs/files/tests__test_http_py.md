# tests/test_http.py

**职责**：Real Go HTTP integration tests in an isolated temp directory。

**自检**：`python scripts/check.py`。

**常见故障与修复**：A compilation error points to Go; a timeout may indicate blocked port or gateway startup failure.

**修改后**：在解压根目录运行 `python scripts/check.py`；如涉及并发/账本，再运行 `go test -race ./...`。
不要直接修改保存的实验数字，也不要绕开安全拒绝来消除测试失败。
