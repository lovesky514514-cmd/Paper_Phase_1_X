# go.mod

**职责**：Go module declaration。

**自检**：`go version, go list ./...`。

**常见故障与修复**：Check Go >=1.22 and execute from the project root.

**修改后**：在解压根目录运行 `python scripts/check.py`；如涉及并发/账本，再运行 `go test -race ./...`。
不要直接修改保存的实验数字，也不要绕开安全拒绝来消除测试失败。
