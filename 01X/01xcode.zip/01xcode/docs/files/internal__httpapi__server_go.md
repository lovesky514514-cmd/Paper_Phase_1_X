# internal/httpapi/server.go

**职责**：HTTP parsing, JSON validation and local endpoints。

**自检**：`go test ./internal/httpapi -v`。

**常见故障与修复**：Check known JSON fields, 8KB body cap and HTTP statuses; do not accept client-supplied risk numbers.

**修改后**：在解压根目录运行 `python scripts/check.py`；如涉及并发/账本，再运行 `go test -race ./...`。
不要直接修改保存的实验数字，也不要绕开安全拒绝来消除测试失败。
