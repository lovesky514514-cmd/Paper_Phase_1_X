# contracts/HAZARD_CONTRACT.md

**职责**：Human review sheet for hard invariants。

**自检**：`go test ./internal/core`。

**常见故障与修复**：Compare written rules with core precondition/apply; reconcile disagreements explicitly.

**修改后**：在解压根目录运行 `python scripts/check.py`；如涉及并发/账本，再运行 `go test -race ./...`。
不要直接修改保存的实验数字，也不要绕开安全拒绝来消除测试失败。
