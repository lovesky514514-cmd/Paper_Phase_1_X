# scripts/evaluate.py

**职责**：Offline evaluation wrapper。

**自检**：`python scripts/evaluate.py`。

**常见故障与修复**：Results path must remain inside root; check CLI errors for bad task counts.

**修改后**：在解压根目录运行 `python scripts/check.py`；如涉及并发/账本，再运行 `go test -race ./...`。
不要直接修改保存的实验数字，也不要绕开安全拒绝来消除测试失败。
