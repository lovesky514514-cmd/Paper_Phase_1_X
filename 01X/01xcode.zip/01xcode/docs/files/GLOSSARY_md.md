# GLOSSARY.md

**职责**：Canonical domain terminology。

**自检**：`python scripts/check.py`。

**常见故障与修复**：Do not redefine risk proxy as accident probability; align documentation with implementation.

**修改后**：在解压根目录运行 `python scripts/check.py`；如涉及并发/账本，再运行 `go test -race ./...`。
不要直接修改保存的实验数字，也不要绕开安全拒绝来消除测试失败。
