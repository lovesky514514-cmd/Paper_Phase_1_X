# 研究实验口径

本包有**两个分离的层次**：Go 的真实本地 HTTP 合成状态流用于检查执行正确性；Python 的离线策略对照用于验证统计流程的可复现性。**不能把离线模拟的效果直接当成 Go 联机吞吐或真实安全性。**

`python scripts/evaluate.py --tasks 100 --seeds 5` 默认比较 6 种本地策略：B0 无保护、B1 只读、B2 固定规则、B3 风险点估计、B4 固定阶段风险预算、Ours 置信上界+剩余预算。全部是本地近似；没有复现 AgentSpec/Progent 正式实现。

每个任务包含 3 个候选步骤，覆盖合成 workflow/process 两类。独立隐藏的 `true_safe` 用来评估安全状态；策略仅访问 `observed_safe` 与独立提供的风险样本，故意模拟测量不一致与观察错误；模型还**没有真实物理状态转移**，评估因此十分初级。任务成功要求全部步骤执行且真实标签安全。

指标：`safe_task_completion` 是任务完整且每步真实安全的比例；`unsafe_executions` 是执行写操作时违反真实安全标签的次数；`blocked_actions` 是停止时拒绝的候选动作数；`proxy_budget_violations` 是模拟预算账户超限次数。

隐含限制：缺少基线的真实 Agent、P50/P95 延迟、独立工程危险标签、校准测试、置信区间及人类专家审核。Brier 等统计指标尚未具备必要观测条件。

推荐复验：

```sh
python scripts/evaluate.py --tasks 100 --seeds 5 --out results/pilot.json
python scripts/evaluate.py --tasks 100 --seeds 5 --drift 0.2 --out results/ood_pilot.json
```

`results/` 下含实跑数据（仅代表合成实验）。比较未经匹配的危险执行率与成功率时必须同时展示二者，不能以拒绝全部调用来声称安全算法改进。若新策略不优于固定规则，诚实记录负结果并考虑换方法。
