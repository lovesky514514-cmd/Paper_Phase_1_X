# 逐文件排错与修复索引

每一份**执行源码、测试、脚本、合约和研究输入/结果**均有一页。设计说明文档按 `docs/` 原路径直接查看；修复代码后先跑本文件测试，再跑整体自检。

- [`go.mod`](files/go_mod.md)：Go module declaration
- [`cmd/rabgate/main.go`](files/cmd__rabgate__main_go.md)：Loopback server boot and config loading
- [`internal/core/model.go`](files/internal__core__model_go.md)：State machine, hazard gate and atomic risk accounting
- [`internal/core/core_test.go`](files/internal__core__core_test_go.md)：Concurrency, version and invariants regression tests
- [`internal/httpapi/server.go`](files/internal__httpapi__server_go.md)：HTTP parsing, JSON validation and local endpoints
- [`internal/httpapi/server_test.go`](files/internal__httpapi__server_test_go.md)：Malformed JSON and guard injection tests
- [`contracts/risk_samples.json`](files/contracts__risk_samples_json.md)：Trusted synthetic counts, severity and budget
- [`contracts/HAZARD_CONTRACT.md`](files/contracts__HAZARD_CONTRACT_md.md)：Human review sheet for hard invariants
- [`python/rabgate/__init__.py`](files/python__rabgate____init___py.md)：Python package entry point
- [`python/rabgate/client.py`](files/python__rabgate__client_py.md)：Loopback-only HTTP client and errors
- [`python/rabgate/demo.py`](files/python__rabgate__demo_py.md)：Process and workflow live HTTP demo
- [`python/rabgate/experiment.py`](files/python__rabgate__experiment_py.md)：Paired synthetic workload and six approximate policies
- [`python/rabgate/risk.py`](files/python__rabgate__risk_py.md)：One-sided uncertainty calculation for offline comparisons
- [`scripts/check.py`](files/scripts__check_py.md)：End-to-end self-check entry point
- [`scripts/start.py`](files/scripts__start_py.md)：Temporary compiled gateway launcher
- [`scripts/demo.py`](files/scripts__demo_py.md)：Import-safe demo wrapper
- [`scripts/evaluate.py`](files/scripts__evaluate_py.md)：Offline evaluation wrapper
- [`scripts/check.sh`](files/scripts__check_sh.md)：Unix one-command self-check
- [`scripts/start.sh`](files/scripts__start_sh.md)：Unix one-command server start
- [`scripts/check_windows.bat`](files/scripts__check_windows_bat.md)：Windows one-command self-check
- [`scripts/start_windows.bat`](files/scripts__start_windows_bat.md)：Windows one-command server start
- [`tests/test_http.py`](files/tests__test_http_py.md)：Real Go HTTP integration tests in an isolated temp directory
- [`tests/test_risk.py`](files/tests__test_risk_py.md)：Offline statistical and policy behavior tests
- [`README.md`](files/README_md.md)：Entry point and required installations
- [`GLOSSARY.md`](files/GLOSSARY_md.md)：Canonical domain terminology
- [`CODING_STANDARDS.md`](files/CODING_STANDARDS_md.md)：Local code quality contract
- [`research/01x_original.md`](files/research__01x_original_md.md)：Unmodified user-provided first cross-disciplinary proposal
- [`results/pilot.json`](files/results__pilot_json.md)：Generated default pilot data
- [`results/ood_pilot.json`](files/results__ood_pilot_json.md)：Generated shifted synthetic pilot data
