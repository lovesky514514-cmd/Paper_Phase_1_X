"""Demonstrate Go HTTP writes, idempotent replay and a hard interlock."""
from __future__ import annotations

from .client import GatewayClient


def run() -> None:
    client = GatewayClient()
    process_id, state = client.create("process")
    opened = client.act(process_id, "open-1", "change_valve", state["version"], value=1)
    replay = client.act(process_id, "open-1", "change_valve", state["version"], value=1)
    rejected = client.act(process_id, "open-again", "change_valve", opened["version"], value=1)
    assert opened["decision"] == "allow"
    assert replay["decision"] == "replay"
    assert rejected["decision"] == "block"  # sensor is now stale
    print("Process sandbox:", opened["decision"], replay["decision"], rejected["decision"])

    workflow_id, state = client.create("workflow")
    for request, operation in (("read", "read_case"), ("approve", "approve_case"), ("credit", "issue_credit")):
        decision = client.act(workflow_id, request, operation, state["version"])
        print("Workflow sandbox:", operation, decision["decision"])
        if decision["decision"] != "allow":
            raise AssertionError(f"demo workflow unexpectedly refused: {decision}")
        state = decision["snapshot"]
    duplicate = client.act(workflow_id, "second-credit", "issue_credit", state["version"])
    assert duplicate["decision"] == "block"
    print("Second credit denied; audit entries:", len(client.audit(workflow_id)["decisions"]))


if __name__ == "__main__":
    run()
