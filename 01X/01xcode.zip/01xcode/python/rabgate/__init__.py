"""RAB-Gate research helpers. No live device or external tool access."""
