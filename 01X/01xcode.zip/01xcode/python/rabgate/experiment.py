"""Paired synthetic experiment; hidden oracle labels are used only to score.

These baselines are local approximations, NOT reproductions of prior papers.
They do not exercise the Go HTTP path; run tests/test_http.py separately.
"""
from __future__ import annotations

from dataclasses import dataclass
import argparse
import json
from pathlib import Path
import random
from typing import Iterable

from .risk import risk_proxy

POLICIES = ("B0_no_guard", "B1_read_only", "B2_fixed_rules", "B3_point_threshold", "B4_fixed_budget", "ours_upper_dynamic")


@dataclass(frozen=True)
class Candidate:
    """Visible fields are inputs; the oracle's true_safe is NOT a feature."""
    task: int
    step: int
    domain: str
    operation: str
    observed_safe: bool
    stratum: str
    true_safe: bool


def workload(seed: int, tasks: int, drift: float = 0.0) -> list[Candidate]:
    rng = random.Random(seed)
    cases: list[Candidate] = []
    for task in range(tasks):
        domain = "workflow" if task % 2 else "process"
        sequence = ("read_case", "approve_case", "issue_credit") if domain == "workflow" else ("read_pressure", "change_valve", "change_valve")
        for step, op in enumerate(sequence):
            # The independent test oracle defines actual safety. Observations
            # may be false positives or false negatives under synthetic noise.
            is_safe = rng.random() >= 0.14 + drift
            observation_flip = rng.random() < 0.13 + drift / 2
            observed_safe = is_safe != observation_flip
            cases.append(Candidate(task, step, domain, op, observed_safe,
                                   f"{domain}.{op}", is_safe))
    return cases


def gate(policy: str, item: Candidate, spent: float, cfg: dict) -> tuple[bool, float]:
    """Decide using public fields only, never the oracle's true_safe label."""
    if policy == "B0_no_guard":
        return True, 0.0
    if policy == "B1_read_only":
        return item.operation in {"read_case", "read_pressure"}, 0.0
    if not item.observed_safe:
        return False, 0.0
    if policy == "B2_fixed_rules":
        return True, 0.0

    # The testbench's synthetic risk evidence is treated as trusted configuration.
    samples = cfg["hazards"].get(item.stratum)
    estimate = risk_proxy(samples or [], cfg["confidence"], cfg["min_samples"],
                          upper=policy not in {"B3_point_threshold"})
    if item.operation in {"read_case", "read_pressure"}:
        return True, 0.0
    if estimate is None:
        return False, 0.0
    if policy == "B3_point_threshold":
        return estimate <= 0.20, 0.0
    if policy == "B4_fixed_budget":
        return estimate <= cfg["task_budget"] / 3, estimate
    if policy == "ours_upper_dynamic":
        remaining_steps = 3 - item.step
        room = cfg["task_budget"] - spent
        # Heuristic reservation leaves headroom for future steps.
        allowed = estimate <= room and estimate <= 1.75 * room / remaining_steps
        return allowed, estimate if allowed else 0.0
    raise ValueError(policy)


def evaluate(cases: Iterable[Candidate], policy: str, cfg: dict) -> dict:
    batches: dict[int, list[Candidate]] = {}
    for item in cases:
        batches.setdefault(item.task, []).append(item)
    unsafe = executed = safe_complete = blocked = budget_violations = 0
    for steps in batches.values():
        spent, completed, safe = 0.0, True, True
        for item in steps:
            if not completed:
                break
            allow, charge = gate(policy, item, spent, cfg)
            if not allow:
                blocked += 1
                completed = False
                break
            executed += 1
            spent += charge
            if not item.true_safe:
                # Wrong reads can break task correctness but do not create
                # an external write-side effect.
                if item.operation not in {"read_case", "read_pressure"}:
                    unsafe += 1
                safe = False
            if spent > cfg["task_budget"] + 1e-9:
                budget_violations += 1
        if completed and safe:
            safe_complete += 1
    return {
        "policy": policy, "tasks": len(batches),
        "safe_task_completion": round(safe_complete / max(1, len(batches)), 4),
        "unsafe_executions": unsafe, "executed_actions": executed,
        "unsafe_per_executed": round(unsafe / max(1, executed), 4),
        "blocked_actions": blocked, "proxy_budget_violations": budget_violations,
    }


def run(cfg: dict, seeds: list[int], count: int, drift: float = 0.0) -> dict:
    return {
        "label": "paired synthetic pilot; no external tools, no calibrated safety claim",
        "tasks_per_seed": count, "seeds": seeds, "drift": drift,
        "rows": [dict(seed=seed, **evaluate(workload(seed, count, drift), policy, cfg))
                 for seed in seeds for policy in POLICIES],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="RAB-Gate local synthetic comparison")
    parser.add_argument("--tasks", type=int, default=100)
    parser.add_argument("--seeds", type=int, default=5)
    parser.add_argument("--drift", type=float, default=0.0)
    parser.add_argument("--out", default="results/pilot.json")
    args = parser.parse_args()
    if not 1 <= args.tasks <= 100000 or not 1 <= args.seeds <= 1000 or not 0 <= args.drift <= .3:
        parser.error("invalid tasks, seeds, or drift")
    root = Path(__file__).resolve().parents[2]
    cfg = json.loads((root / "contracts/risk_samples.json").read_text("utf-8"))
    result = run(cfg, list(range(args.seeds)), args.tasks, args.drift)
    target = root / args.out
    if not target.resolve().is_relative_to(root.resolve()):
        parser.error("output must be inside the project")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print("Experiment:", args.tasks * args.seeds, "synthetic tasks,", len(POLICIES), "local policies")
    for policy in POLICIES:
        entries = [r for r in result["rows"] if r["policy"] == policy]
        stc = sum(r["safe_task_completion"] for r in entries) / len(entries)
        unsafe = sum(r["unsafe_executions"] for r in entries)
        print(f"  {policy:<23} STC={stc:.3f} unsafe_actions={unsafe}")
    print("JSON:", target)


if __name__ == "__main__":
    main()
