"""Pure risk calculations for OFFLINE comparisons; Go remains the live gate."""
from __future__ import annotations

from math import log, sqrt


def risk_proxy(hazards: list[dict], confidence: float, min_samples: int,
               upper: bool = True) -> float | None:
    """Return severity-weighted empirical risk or simultaneous upper bound.

    Under-sampled strata return None, never zero. The upper bound relies on
    independent representative trials, which these synthetic samples do not
    establish for real physical processes.
    """
    if not hazards or not 0 < confidence < 1:
        return None
    adjustment = (1 - confidence) / len(hazards)
    score = 0.0
    for h in hazards:
        n, k = h["trials"], h["events"]
        if n < min_samples or not 0 <= k <= n or h["severity"] <= 0:
            return None
        p = k / n
        if upper:
            p = min(1.0, p + sqrt(log(1 / adjustment) / (2 * n)))
        score += p * h["severity"]
    return score
