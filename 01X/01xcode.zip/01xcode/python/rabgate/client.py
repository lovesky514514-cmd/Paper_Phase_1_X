"""Small HTTP client. It never retries a write with a new request ID."""
from __future__ import annotations

import json
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import Request, urlopen


class GatewayClient:
    def __init__(self, base_url: str = "http://127.0.0.1:8938") -> None:
        # This library intentionally refuses off-machine targets.
        parsed = urlsplit(base_url)
        if (parsed.scheme != "http" or parsed.hostname != "127.0.0.1"
                or parsed.username is not None or parsed.password is not None
                or parsed.path or parsed.query or parsed.fragment or parsed.port is None):
            raise ValueError("only the loopback synthetic sandbox is supported")
        self.base_url = base_url.rstrip("/")

    def _json(self, method: str, path: str, payload: dict | None = None) -> dict:
        data = json.dumps(payload).encode("utf-8") if payload is not None else None
        request = Request(
            self.base_url + path,
            data=data,
            headers={"Content-Type": "application/json"} if data is not None else {},
            method=method,
        )
        try:
            with urlopen(request, timeout=5) as response:
                return json.load(response)
        except HTTPError as exc:
            message = exc.read(2048).decode("utf-8", errors="replace")
            raise RuntimeError(f"gateway returned {exc.code}: {message}") from exc
        except URLError as exc:
            # Ambiguous transport failures must not trigger a new write identity.
            raise RuntimeError(f"gateway unavailable; inspect state before retry: {exc}") from exc

    def create(self, domain: str) -> tuple[str, dict]:
        data = self._json("POST", "/v1/tasks", {"domain": domain})
        return data["task_id"], data["state"]

    def act(self, task_id: str, request_id: str, operation: str,
            expected_version: int, value: int = 0) -> dict:
        return self._json("POST", "/v1/actions", {
            "task_id": task_id, "request_id": request_id,
            "expected_version": expected_version, "operation": operation,
            "value": value,
        })

    def inspect(self, task_id: str) -> dict:
        return self._json("GET", "/v1/tasks/" + task_id)

    def audit(self, task_id: str) -> dict:
        return self._json("GET", "/v1/audit/" + task_id)
