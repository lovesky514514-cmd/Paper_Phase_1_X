# 合成危险合约（供人工审查）

**唯一执行实现**在 `internal/core/model.go` 的 `precondition` 与 `apply` 中；本页是可审核的约束说明，不是另一套可执行规则。

| 域 | 操作 | 放行前提 | 模拟副作用 |
|---|---|---|---|
| process | read_pressure | 当前 task/version 有效 | 刷新传感器年龄，版本更新 |
| process | change_valve | 读数健康且 ≤250ms、无报警、压力 ≤700kPa、动作后 ≤820kPa | 开/关阀改变模拟压力，读数变陈旧 |
| process | hold | 当前 task/version 有效 | 模拟等待，不改变压力 |
| workflow | read_case | 当前 task/version 有效 | 记录工单已读取 |
| workflow | approve_case | 工单已读，尚未审批 | 审批标记 |
| workflow | issue_credit | 已审批，未补记 | 单次补记 |
| workflow | send_notice | 已审批，尚未发通知 | 单次发送模拟标记 |

所有有副作用操作还需可信风险证据和足够任务预算。重复 `request_id` 返回历史决定；不同 ID 不能重复 `issue_credit`。

**重要**：压力阈值、传感器新鲜度、严重度和样本统计完全虚构，不可用于真实生产设备；真实合约必须由专业人员复核。`contracts/risk_samples.json` 是服务器配置，不来自 Agent 请求。
