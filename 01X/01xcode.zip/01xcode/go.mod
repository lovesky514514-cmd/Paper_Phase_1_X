module example.org/rabgate

go 1.22
