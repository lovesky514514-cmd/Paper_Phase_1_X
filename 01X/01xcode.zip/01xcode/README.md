# 01xcode · RAB-Gate

**风险预算 + 硬安全约束的 Agent 工具网关研究原型**。仅能操作本地合成任务，不接工业设备、真实业务账户或公网工具。

**需要安装：Python 3.11+、Go 1.22+。** 不需要 pip 包、GPU、数据库或 API Key。

| 要做什么 | Windows | Linux / macOS |
|---|---|---|
| 一键自检 | 双击 `scripts\check_windows.bat` | `sh scripts/check.sh` |
| 启动本地模拟网关 | 双击 `scripts\start_windows.bat` | `sh scripts/start.sh` |
| 运行本地交互演示 | 另开终端 `py -3 scripts\demo.py` | 另开终端 `python3 scripts/demo.py` |
| 离线六策略对照 | `py -3 scripts\evaluate.py` | `python3 scripts/evaluate.py` |

所有命令在**解压后的项目根目录**运行。自检覆盖 Go、Python 和真实 HTTP；离线结果写入 `results/pilot.json`。

- **Go**：可信状态、版本检查、危险互锁、风险账本、幂等重放、合成执行。
- **Python**：客户端、置信风险上界、成对模拟场景、策略对照、实验报告。
- **说明**：`docs/ARCHITECTURE.md`；研究限制：`docs/EXPERIMENTS.md`；出错：`docs/DEBUG_INDEX.md`。

**科研状态**：可运行的 v0 原型，不是已校准的可靠性控制算法或 SCI 实证。工业阈值仅为示例。Windows 脚本已提供，未在 Windows 真机测试。
