# 交叉学科 SCI 研究报告（一）

# RAB-Gate：面向工具调用智能体的风险预算驱动可靠性保障与可验证安全控制网关

> **研究定位**：Agent × 可靠性工程（Reliability Engineering）× 系统安全（System Safety）× 运行时控制（Runtime Assurance）  
> **备选英文题目**：*RAB-Gate: Risk-Budgeted Runtime Assurance for Tool-Using Agents with Reliability-Aware Safety Contracts*  
> **版本**：研究规划稿，2026-10-20；**非已完成实验、非创新性已证明、非投稿录用承诺**。  
> **适用对象**：以 Agent、后端网关为主的本科生／研究团队；首选软件仿真，后续需可靠性工程领域专家参与验证。  
> **边界**：该方案仅在“受网关完整中介且工具执行语义、状态可观测及风险上界假设成立”的限定范围内讨论形式化保障；不宣称开放世界 Agent 无条件安全。

---

## 0. 一页结论

- **唯一主观点**：工具调用的“单次允许/拒绝”不足以控制复杂 Agent 任务的累积风险；网关应以工程系统的**危险事件、后果严重性、剩余风险预算和真实系统状态**为决策单位，在有限风险预算内最大化可安全完成的任务。
- **拟研究的主创新**：将由 STPA/故障树提取的危险约束、带统计置信度的危险概率上界、任务级风险预算分配，以及具有原子授权语义的运行时执行控制组合为一个**可被反证、可度量开销的风险约束方法**。其中各组件并非首次出现，**联合方案能否成立为新创新依赖严格对照实验**。
- **重点避免撞题**：已有 *Towards Verifiably Safe Tool Use for LLM Agents*（2026）把 STPA、MCP、信息流及工具序列验证结合；*AgentSpec*、*Progent*、*ShieldAgent*、*MiniScope*、*AgentGuard* 已分别研究运行时规则、权限和保护。**“STPA+网关+一个规则引擎”不构成足够创新**。
- **最可行的第一阶段**：不训练模型、不接实体设备；使用零副作用的仿真后端与标准化工具调用，研究**固定安全规则 vs. 风险预算自适应干预**对任务成功、危险执行、超时、延迟与错误拦截的影响。
- **SCI 投稿主路径**：高要求版优先 *Reliability Engineering & System Safety*（RESS）；应用充分可选 *Safety Science*；控制理论实质强可考虑 *ISA Transactions*；工程可靠性案例扎实可考虑 *Quality and Reliability Engineering International*（QREI）。优先选择**订阅发表模式**免 APC，并逐刊确认是否存在额外投稿/图版费用。
- **当前状态**：只有经过检索的研究设想，没有运行结果；文中的指标目标均为**拟定的立项门槛**，不是已实现性能。

## 1. 研究问题与论文主张

### 1.1 直观例子

一个 Agent 对工业工艺的仿真控制后端执行操作：读取压力、改变阀门开度、确认报警、发出复位命令。一个“改变阀门开度”的工具调用可能合法，却在压力过高、传感器故障、前序报警尚未处理等特定状态下变成危险行为。普通 API 网关通常处理身份、速率与格式；文本式 Agent 守卫经常看单次操作是否合法，但单步合法不推出轨迹安全。

形式化后，令任务轨迹为 `τ=(s0,a0,s1,a1,...,sT)`。这里 `a` 是实际工具执行动作，`s` 是可靠性状态（安全约束、危险前驱、权限、剩余预算、设备状态与证据完备度）。研究问题不再是“识别危险文本”，而是：

> 在工具行为可形式化、状态存在观测误差、风险后果不相同的条件下，能否构造一个外置网关，使其在给定错误风险/安全预算内尽量维持任务完成，并明确什么时候必须拒绝、降级或人工升级？

### 1.2 可验证研究假设

- **H1（风险权衡）**：在相近安全事件率下，相比静态规则/全拒绝/一律人工确认，自适应风险预算能够改善安全任务完成率或减少额外延迟。若不能则主创新不成立。
- **H2（分布外鲁棒性）**：在工具故障率、危险状态分布、传感器缺失和恶意工具结果发生变化时，置信上界+保守退化策略比点估计策略产生更少的危险放行。
- **H3（系统保障）**：在*预设可观测状态、经验证的状态机及完整中介*下，无法绕过的确定性不变量约束能在模型检查/穷举状态空间中保持零违规；风险阈值本身只提供**有条件的概率式保证**。
- **H4（真实工程相关性）**：在第二个独立场景复现改进，且不由错误拒绝全部任务实现“安全”。

### 1.3 不宜宣称的伪创新

1. “首次采用 STPA 分析 Agent 风险”（已被 2026 年工作触及）。
2. “首次提出模型外安全屏障/运行时监控”（既有 Shield Synthesis、ShieldAgent、AgentSpec）。
3. “只要被网关拦截，就可证明现实物理系统安全”（外部旁路、状态时延、模型失配未处理）。
4. “危险识别率高就是可靠性高”（遗漏可用性、误拒绝和后果严重性）。
5. “第一次在某专业使用 LLM+网关”（单纯领域拼接通常不足以支持高水平论文）。

---

## 2. 与直接竞争研究的差异：必须写进 Related Work

| 最相关工作 | 已解决的问题 | 我们不能重复什么 | 需要用实验检验的可能差异 |
|---|---|---|---|
| Doshi 等，*Towards Verifiably Safe Tool Use for LLM Agents*（ICSE-NIER 2026） | STPA 分析、MCP 扩展、信息流/工具序列约束 | STPA+MCP 安全形式化本身 | 按危险后果分层的**概率预算**与任务完成率—风险 Pareto 曲线 |
| *AgentSpec*（2025） | DSL 约束与运行时执行 | 策略 DSL/阻断危险动作 | 在输入风险不确定时的**预算分配及校准** |
| *Progent*（2025） | 细粒度工具权限控制、可自动生成策略 | 网关拦截和最小权限 | 权限合法≠物理安全，增加**后果/状态条件** |
| *ShieldAgent*（ICML 2025） | 显式安全策略的可验证推理与保护 | “额外加一个 guard agent” | 网关可靠性统计与安全阈值的**可审计上界** |
| *GuardAgent*（ICML 2025） | 安全请求生成可执行检查 | 自动生成守护代码 | 专业工程危险模型与任务级风险预算 |
| *MiniScope*（2025 预印本） | 最小权限与工具授权 | 限权本身 | 动态危险前驱状态、不确定性与保护成本 |
| *AgentGuard*（2026 预印本） | ABAC、跨工具保护与审计 | ABAC 与跨工具拦截 | 高危工程任务的**风险聚合/证据有效性** |
| *AgentTrust*（2026 预印本） | 执行前工具调用风险拦截 | allow/warn/block/review 四态 | 基于工程事故模型的可量化剩余风险约束 |
| *Safe Reinforcement Learning via Shielding*（AAAI 2018） | 自动合成安全屏障 | “屏障拦截危险动作” | 非 Markov 工具轨迹与外部可靠性证据的桥接 |
| *Adaptive Shielding via Parametric Safety Proofs*（OOPSLA 2025） | 适应环境的参数化安全证明 | 参数化屏障概念 | 不可逆 API、副作用、分布外校准与网关实装 |

**核心对照原则**：不要比“没有任何防护的 Agent”强就声称有新贡献；至少比**最强的固定屏障、运行时规则、权限控制、动态风险策略**强，且公布等任务、等模型、等成本设置。

---

## 3. 可靠性工程的真正切入点

### 3.1 STPA + FTA 的职责不同

- **STPA（System-Theoretic Process Analysis）**用来识别“不恰当控制动作”、控制回路中的危险组合与安全约束。例如“压力传感器失效时仍增加流入量”。
- **FTA（Fault Tree Analysis）**用来组织顶事件及其前驱依赖，如“超压事故 = 进料持续增加 AND 安全泄压未生效”；可辅助风险结构可视化与故障注入设计。
- **风险模型**用观测数据估计危险事件与条件之间的概率关系，并对置信度不足的地方形成上界。
- **运行时屏障**只有在执行层掌握完备约束、执行前状态和工具操作执行权时，才能实现确定性阻止。

**不能把 FTA 静态逻辑的与/或门概率简单相乘当成真实工程风险**：共享原因、状态相关性和故障时序可能使独立性假设失效，应该至少引入依赖项检查、贝叶斯模型或保守上界。

### 3.2 危险语义合约（Hazard Contract）

每类实际执行工具记录：

```yaml
hazard_contract:
  operation: change_valve
  resource_scope: simulator/line_A
  irreversible: false
  preconditions:
    - sensor_freshness_ms <= 250
    - pressure_kpa <= 700
  invariant:
    - pressure_kpa <= 820
  hazard_event: H_overpressure
  severity: 5
  fallback: hold_or_shutdown_simulator
  evidence_required:
    - readback_pressure
    - active_interlock_state
  estimation:
    model_version: risk-v1
    upper_confidence: 0.99
```

数值仅用于**演示接口**，不是任何真实设备允许的压力或工程标准。

需要明确：人工编写/审定的危险合约 ≠ LLM 生成结果自动正确；语义映射错误是最严重风险之一。

### 3.3 观测证据与状态一致性

- 工具执行前读取真实后端状态；拒绝仅凭 Agent 的自然语言声明“已关闭警报”。
- 读回状态附时间戳、资源版本和证据来源。
- 对检查与执行之间的竞态（TOCTOU），必须用后端**条件写入、版本号 compare-and-swap、原子策略执行**或者同一可信事务边界处理。若工具端不支持，就降级标注“无法强保障”。
- 对不可逆动作（转账、发送危险指令、删除关键记录）使用额外确认和幂等键；幂等只解决一类重复执行问题，不可取代状态安全验证。

---

## 4. 方法：RAB-Gate（拟定，并非已证实创新）

### 4.1 六层系统结构

```text
用户任务 / 多 Agent 规划器
          |
          v
[1 工具拦截] 统一 Tool/API/MCP 入口、身份与任务标识
          |
          v
[2 证据读回] 后端真实状态、版本、传感器新鲜度、工具结果
          |
          v
[3 危险映射] STPA/FTA => 危险类型、严重性、约束、故障场景
          |
          v
[4 风险上界] 事故前驱检测 / 概率区间 / 未知状态识别
          |
          v
[5 预算策略] allow / alternative / delay / confirm / block
          |
          v
[6 原子执行] 条件提交、回读、审计、更新剩余风险预算
          |
          v
仿真后端/可中介的实际工具（首期只在沙箱里）
```

实现建议：FastAPI（Agent 侧路由接口）+ Rust/Go（可选安全执行代理）+ PostgreSQL 或 SQLite（版本化审计，原型即可）+ Python（离线实验）。安全策略执行层尽量保持纯确定性；**不要用 LLM 自行批准它自己的高风险动作**。

### 4.2 数学问题（可投稿版的起点）

定义危险类型 `h=1...H`，严重性损失 `L_h>0`，历史证据 `D_t`，提议操作 `a_t` 和观测状态 `s_t`。

- 状态条件危险概率上界：`U_h(a_t,s_t,D_t)`；
- 当前动作保守风险增量：`r_t(a_t) = sum_h L_h * U_h(a_t,s_t,D_t)`；
- 任务风险预算 `B>0`，累计已分配预算 `C_t`；
- 可操作动作集合 `A_safe(s_t)` 满足确定性硬约束。

提出的简化决策：

```text
max_{a in A_safe(s_t) union {defer,block,confirm}}
      E[task_progress(a)] - λ latency(a) - μ compute_cost(a)
subject to:
      C_t + r_t(a) <= B
      hard_invariants(s_t,a) == TRUE
      evidence_is_fresh(s_t,a) == TRUE
```

**解释与边界**：

1. `sum_h L_h U_h` 是保守**代价代理量**，不等于系统事故发生概率；不同危险的损失与相关性需要审慎建模。对于“整段轨迹出现至少一次事故的概率上界”，应改用满足条件的联合界/状态模型，不能把期望损失直接当成事故概率。
2. 危险概率 `U_h` 必须说明其构造办法（如二项置信区间、分布鲁棒区间），以及独立性、状态覆盖、校准、漂移条件。样本太少时上界可能非常保守；此时系统要允许**弃权与人工介入**。
3. 动作预算累加虽可在风险成本模型中实现**规划约束**，但没有证明实际数据生成过程满足模型前，不能称为“端到端概率严格保证”。
4. 对必须“绝对禁止”的动作，先用**确定性不变量**；不能因为风险预算宽松而放行。
5. 未来可研究预算再分配（按危险严重度、后续步骤关键路径或剩余任务价值），必须与固定分配和风险阈值对照，证明这不是启发式调参。

### 4.3 风险上界的第一版可操作方案

- 每个有足够样本的受控状态桶统计危险事件 `k/n`，给出 **Clopper–Pearson** 或其他适合的上置信界；对多危险类型/多比较同时成立需调整置信预算。
- 样本稀缺及分布外：风险视为**不可判定**，进入只读/拒绝/人工升级，不填“0 风险”。
- 第二版引入可解释单调风险模型或分层贝叶斯模型；**模型复杂化只有在实际改善校准时才保留**。
- 不推荐起步就将 LLM 估计危险概率作为唯一输入。

### 4.4 最小可证安全命题

限定：(i) 所有动作受中介；(ii) 可信后端提供原子检查与提交；(iii) 状态映射正确；(iv) 硬约束不变量在模型状态空间内完备；(v) 初态安全。若屏障只允许满足安全转移关系的动作，则**对模型可覆盖状态**的有限执行轨迹，可通过归纳证明硬不变量始终成立。

**需要反证测试**：旁路调用、延迟状态、工具返回伪造、跨租户重放、崩溃恢复、未建模设备模式、权限过期；其中若假设破坏，结论不得外推到现实。

---

## 5. 交叉学科具体可做的 8 个小课题

| 子课题 | 交叉方法 | 可复现实验 | 研究价值判断 |
|---|---|---|---|
| A. STPA × MCP 工具链 | 危险控制动作 → 验证合约 | 人工构建 50–100 个危险序列，比较自动生成合约的一致性 | 可做，但已有直接先例；不宜单独作为主创新 |
| B. FTA × 动态工具调用 | 时序故障树、共因故障 | 故障前驱变化与事件注入，测漏判 | 有价值；强调动态依赖 |
| **C. 可靠性统计 × 风险预算** | 上置信界、机会约束、预算分配 | 同等风险下完成率—延迟—成本 Pareto | **本报告首选主线** |
| D. 控制屏障 × 工业仿真 | 离散状态约束、执行前互锁 | 温度/压力/阀门的简化物理仿真 | 适合更高要求工程期刊 |
| E. 安全论证 × 证据图 | Assurance case / 证据溯源 | 检查每个放行动作依据是否完整且未过期 | 可增强可信度与可审计性 |
| F. 人因工程 × 人工升级 | 误报负担、可理解风险说明 | 操作员对比实验或离线代理指标 | 需要额外伦理及被试设计 |
| G. 因果风险 × 故障注入 | 干预实验与关键前驱变量 | 控制变量下对风险上界与根因判定做消融 | 方法潜力大；注意因果识别前提 |
| H. 鲁棒控制 × 部分可观测 | 不确定性集合、失效安全退化 | 传感器丢包、错误读数、状态版本竞争 | 实用性强，实施难度中高 |

**本科生切实可做的组合**：先 C+B+少量 D；若已有可靠的专业仿真伙伴，再扩成 C+D+H；无需一次塞进全部 8 项。

---

## 6. 公开数据、模拟场景与实际研究工作

### 6.1 两阶段评测建议

**阶段 I（软件域）**：使用独立的 mock REST/MCP 后端模拟订单、审批、数据库维护与消息发送。要求每个操作都对应机器可判定的危险谓词（例如未审批退款、重复执行、越权状态变更）。若使用 τ²-bench、AgentDojo 或 ToolEmu，只选适合的公开任务并**另外定义可执行危险谓词**，不能把已有的任务奖励直接当成工程可靠性指标。

**阶段 II（工程域）**：构建**仅仿真运行**的压力—阀门—报警状态机（或某开源工业数字孪生），模拟设备老化、传感器偏差、通信失连、报警冻结、共因故障等。必须与简单/真实物理机制相符，由领域专家评审危险阈值的合法性。不得将示范阈值应用于实际设备。

### 6.2 建议最小实验矩阵

- 任务数：先 100 个核心任务 × 5 随机种子作为可行性测试；投稿版努力扩至**至少数千条执行轨迹**并报告置信区间。样本规模不是录用保证，应做先导实验估算功效。
- 危险类型：权限越界、复合工具危险、重复提交、状态过期、操作顺序颠倒、条件竞争、传感器异常、共因故障。
- 故障强度：0%、1%、5%、10%、20% 注入概率仅作实验网格；危险行为实际出现率需独立报告。
- 风险偏好：预算 `B` 取多点构成 Pareto 曲线，固定同一组模型与实际工具可用性。
- 漂移：训练/调参环境与测试环境的故障相关性、延迟、提示方式/Agent 模型至少改变一项。
- 重复：固定基准配置、多种随机种子、统计区间和显著性/效应量，不只展示单次最优。

### 6.3 核心对照方法

B0 无屏障，B1 静态 allowlist，B2 固定危险规则，B3 风险点估计+固定阈值，B4 按危险严重度的固定预算，B5 AgentSpec/Progent 类同层实现（可复现则采用原实现，否则明确标注近似基线），B6 全人工确认/全拒绝安全下界，Ours 动态预算+保守上界+读回；可选 B7 传统屏障合成机制。

**必须公平**：相同 Agent 输入和模型，统一工具协议，计入额外读回/LLM调用/人工确认成本；对开源基线限制适配范围，不可暗中删减其关键能力。

### 6.4 核心指标（论文图表至少 8 张）

1. **Unsafe Execution Rate (UER)**：实际危险动作被后端执行比例（按严重度分层，不是只计算被模型识别的危险）。
2. **Safe Task Completion (STC)**：任务目标完成且全程未违反真实环境危险谓词的比例。
3. **False Block Rate (FBR)**：本可安全执行却被阻断的比例。
4. **Risk Calibration**：预测概率与实际危险率的可靠性图、Brier score；报告置信区间覆盖率。
5. **Budget Violation Rate**：保守风险预算是否在离线评估中被违反，与实际事故率分开。
6. **P50/P95/P99 overhead**：网关附加延迟和总任务端到端时延。
7. **Cost**：调用次数、额外读回次数、Token、CPU、人工升级量。
8. **Abstention & Recovery**：拒绝/人工升级比例、恢复后成功率。
9. **Robustness**：分布漂移与少样本情形的失效曲线。
10. **Evidence Coverage**：高危动作中证据完整/过期/缺失的比例及安全相关性。

### 6.5 消融实验

- 移除 STPA 约束映射；移除 FTA 依赖；移除后端 readback；移除风险置信上界；改为均匀预算；不按严重性加权；移除任务阶段动态分配；移除状态版本原子提交；仅用 LLM judge；不允许人工升级。
- **必须分析安全改善是不是由过度拒绝造成**：如果 UER 下降、STC 也趋近 0，研究失败。

### 6.6 反直觉边界实验

- 所有工具单独合法，但“读机密→公共发布”复合轨迹危险；
- 工具响应与实际状态不一致；
- 先检查后执行期间资源版本改变；
- 预算临界时剩下一个不可逆高价值任务；
- 实测危险率 0/100，但统计置信上界仍不为 0；
- 多个危险有共同前因，朴素独立概率低估风险。

---

## 7. 创新性与理论贡献的最低要求

### 7.1 投稿若要写“理论保证”，需要满足

- 写清危险集合、安全规范、网关完整中介和状态观测假设；
- 对有限状态子系统给出定理+归纳证明或模型检查；
- 对概率风险只在统计假设成立时给出置信保证，不混用“经验无事故”和“数学可证明”；
- 给出策略计算复杂度或稳定可扩展性说明；
- 对合约生成的人工作业量和质量报告实际数据。

### 7.2 区别应用论文与方法论文

- **方法论文**：动态预算策略有严格定义，风险不确定性建模有优于现有方法的证据，兼顾任务效用，至少两个不同任务域。
- **工程应用论文**：即便优化算法简单，也要有真实、非琐碎的可靠性问题、物理/工程约束、定量事故/风险指标、工程人员校验。
- **暂时不宜投 SCI 的状态**：只有网页平台、规则引擎、若干 demo 截图、用模型自评“准确率 98%”，没有危险事件真实标注和强基线。

---

## 8. 学弟与合作者的分工

| 负责人 | 具体任务 | 可验收交付 |
|---|---|---|
| Agent/后端网关方向 | 工具拦截、版本控制、执行与日志、压测 | 可复现的核心网关和自动化集成测试 |
| 可靠性/系统安全方向合作人 | STPA 危险清单、FTA、严重性等级 | 审校过的危险规格及案例映射 |
| 算法方向 | 置信上界、预算更新、消融 | 数学定义、代码、标定曲线、失效分析 |
| 实验负责人 | 故障注入、基线复现、随机种子、统计 | 数据字典、统一实验脚本和原始结果 |
| 论文负责人 | 撞题对照、局限、SCI 格式 | 可追溯的英文稿和补充材料 |

如果目前只有学弟一人，不建议承诺一次完成全部：先做**最小沙箱 + 3 个基线 + 50–100 个真实标注的危险用例**；有明确正结果之后再引入可靠性工程专家。

---

## 9. 八至十二周研究进度（计划，不是已完成）

| 周期 | 工作 | Go/No-Go 验收 |
|---|---|---|
| 第 1 周 | 阅读 10 篇核心论文；锁定两类场景和危险定义 | 不能明确区别 ICSE 2026 工作即暂缓 |
| 第 2 周 | 定义危险事件、严重性与安全不变量 | 至少 30 个由人独立复核的案例 |
| 第 3–4 周 | 网关拦截/状态读回/原子提交原型 | 通过并发、重放、失败注入测试 |
| 第 5 周 | 静态屏障、阈值风险和安全拒绝基线 | 可一致复现实验结果 |
| 第 6–7 周 | 风险上界+预算分配与校准 | 风险估计不会把未知直接标为安全 |
| 第 8 周 | 消融、OOD、严重事故案例 | STC 与安全折中非劣于强基线 |
| 第 9–10 周 | 工程仿真域 + 可靠性专家评审 | 至少一个有意义的领域外测试 |
| 第 11–12 周 | 统计、图表、英文稿、补充材料 | 决定投稿/缩题/停止，不强行包装 |

**停止条件**：若核心创新仅等于 STPA+AgentSpec、实验改进来自拒绝全部危险任务、概率界无法校准、实际系统状态无法可信读回，则不应声称研究成功。

---

## 10. SCI 选刊：免费发表、周期快、匹配优先（截至 2026-10-20 检索）

### 10.1 重要口径

- **免 APC ≠ 开放获取 OA 免费**：下列期刊若存在订阅发表路线，原则上选择 subscription/non-OA 才不支付 OA APC。其他投稿/彩图/超页费用仍须查看最终投稿系统。
- **初筛周期 ≠ 外审首轮 ≠ 投稿到录用**；首轮很短常包含迅速拒稿，不代表会被快速录用。
- 期刊指标可随日期变化。以下周期来源分级为：A=出版商原始页面/政策；B=明确转述出版商统计的第三方页面；C=抽样文章回溯统计。**B/C 仅作初选参考，最终必须用期刊实时 Journal Insights 复核**。
- 不在文件中硬报不经当期核实的“中科院一区/二区”；JCR/中科院分区和 **SCIE** 状态不是一回事，务必到 [Clarivate MJL](https://mjl.clarivate.com/) 检查 ISSN 与目标投稿年份。

### 10.2 期刊对比

| 期刊 | 方向吻合 | 可免 OA APC 路线 | 编辑初筛/外审首轮 | 投稿到录用 | 来源与关键提醒 | 建议 |
|---|---|---|---|---|---|---|
| **Reliability Engineering & System Safety (RESS)** | ★★★★★ | 混合期刊订阅发表（核实附加费） | 约 7 天 / 82 天 | **约 201 天** | B：第三方汇总 2026-10-01 版出版商数据；侧重真正工程可靠性 | **有风险模型+工程案例时首选** |
| **Safety Science** | ★★★★☆ | 混合期刊订阅发表（核实） | 约 6 天 / 161 天 | **约 202 天** | B：第三方复刻期刊数据；人因/组织安全与工程危险分析更适配 | 有广泛安全科学意义时考虑 |
| **ISA Transactions** | ★★★★☆（控制强化版） | 订阅发表（核实） | 约 1 天 / 56 天 | **约 214 天** | B；另一种发表文章抽样统计中位数可不同；重控制与自动化 | 仅当有控制方法和稳定性分析 |
| **Quality and Reliability Engineering International (QREI)** | ★★★★☆ | 非 OA 传统发表；额外费用需投稿前核实 | **13 天**（官方首决中位数，A） | **未找到可信最新官方统计** | A：Wiley 官网页面明确免投稿费，不能将首决视为录用 | 更偏数学统计+可靠性案例的务实备选 |
| **Computers & Security** | ★★★☆☆ | 订阅发表免 APC | 约 2 天 / 56 天 | **约 162 天** | B：期刊信息页；若安全授权/攻击防御是主贡献才匹配 | 更偏工具安全、不适合纯事故模型 |
| **Journal of Information Security and Applications (JISA)** | ★★★☆☆ | 混合订阅发表（核实） | 约 3 天 / 64 天 | **约 162 天** | B：第三方统计转述；需要实质安全防护贡献 | 偏网络/应用安全的降维选择 |

**选刊优先级不是按周期直接排序**：RESS（真正可靠性方法）→ Safety Science（系统安全应用）→ QREI（统计+应用）→ ISA Transactions（控制加强）→ Computers & Security / JISA（若最终重心变成安全网关）。

**来源核查入口**：

- RESS [期刊范围/订阅说明](https://shop.elsevier.com/journals/reliability-engineering-and-system-safety/0951-8320)；[2026 周期二级转录](https://journalcompass.com/journals/reliability-engineering-system-safety-09518320.html)。
- Safety Science [公开指标二级页面](https://www.sciencedirectelsevier.com/journal/Safety-Science)（该站**不是 Elsevier 官方域名**，只做检索参考）。
- ISA Transactions [学会范围与稿件类型](https://www.isa.org/standards-and-publications/isa-publications/isa-transactions)；[周期转录](https://journalcompass.com/journals/isa-transactions-00190578.html)。
- QREI [Wiley 官方主页含 13 天首决](https://onlinelibrary.wiley.com/journal/10991638)、[官方作者指南：无 submission fees](https://onlinelibrary.wiley.com/page/journal/10991638/homepage/forauthors.html)。
- Computers & Security [期刊数据及订阅路线](https://computersandsecurity.org/journal-insights/)（独立站显示数据，须用 Elsevier 官方复核）。
- JISA [周期二级转录](https://journalcompass.com/journals/journal-of-information-security-and-applications-22142126.html)。
- Elsevier 官方 [订阅发表免 APC 政策](https://www.elsevier.com/about/policies-and-standards/pricing) 与 [关于初审/审稿指标口径的说明](https://www.elsevier.support/publishing/answer/when-can-i-expect-a-decision-from-the-editor)。

**实际投稿决策**：若“至少真实工程仿真 + 风险上界校准 + 强屏障基线 + 定理边界”不齐全，别因为 RESS 影响力高就盲投；选择匹配期刊更能缩短失败迭代周期。

---

## 11. 至少 30 篇关联研究：40+ 条带可追踪链接的阅读清单

**文献统计说明**：以下为 **42 条不重复研究论文/综述**，另有一本 STPA 重要专著列在“额外基础资料”；“预印本”不代表已在 SCI 期刊发表；会议论文不能当作 SCI 论文。链接优先出版社、会议论文页和 arXiv 论文页。每条都说明与本研究的关系，若是间接基础则明确标注。排序不等于正式文献引用顺序。最近发表信息与最后版次在写稿前仍需确认。

### A. 直接竞争：Agent 运行时安全/工具控制（1–13）

1. **Doshi et al. (2026)**, *Towards Verifiably Safe Tool Use for LLM Agents*. **ICSE-NIER 2026**, DOI: [10.1145/3786582.3786839](https://doi.org/10.1145/3786582.3786839)。**最重要竞争研究**：STPA 与 MCP 安全形式化；切不可声称这些是全新组合。
2. **Chen et al. (2025)**, *ShieldAgent: Shielding Agents via Verifiable Safety Policy Reasoning*. **ICML 2025**，[PMLR](https://proceedings.mlr.press/v267/chen25ae.html)。显示安全策略可验证、策略检索与保护的强基线。
3. **Xiang et al. (2025)**, *GuardAgent: Safeguard LLM Agents via Knowledge-Enabled Reasoning*. **ICML 2025**，[PMLR](https://proceedings.mlr.press/v267/xiang25a.html)。安全需求生成检查代码，适合作为策略生成层对照。
4. **Wang et al. (2025)**, *AgentSpec: Customizable Runtime Enforcement for Safe and Reliable LLM Agents*. **预印本**，[arXiv:2503.18666](https://arxiv.org/abs/2503.18666)。已做 DSL 与执行期策略检查。
5. **Shi et al. (2025)**, *Progent: Programmable Privilege Control for LLM Agents*. **预印本/另查最终发表**，[arXiv:2504.11703](https://arxiv.org/abs/2504.11703)。细粒度工具级权限策略。
6. **Zhu et al. (2025)**, *MiniScope: A Least Privilege Framework for Authorizing Tool Calling Agents*. **预印本**，[arXiv:2512.11147](https://arxiv.org/abs/2512.11147)。最小权限+低开销授权。
7. **Luo et al. (2026)**, *AgentGuard: An Attribute-Based Access Control Framework for Tool-Use LLM-Based Agent*. **预印本**，[arXiv:2605.28071](https://arxiv.org/abs/2605.28071)。ABAC 与跨工具保护。
8. **Yang (2026)**, *AgentTrust: Runtime Safety Evaluation and Interception for AI Agent Tool Use*. **预印本**，[arXiv:2605.04785](https://arxiv.org/abs/2605.04785)。规则、链式危险识别与拦截。
9. **Hua et al. (2024)**, *TrustAgent: Towards Safe and Trustworthy LLM-based Agents*. **Findings of EMNLP 2024**，[ACL Anthology](https://aclanthology.org/2024.findings-emnlp.585/)。代理宪法与规划前/中/后检查。
10. **Montanari et al. (2025)**, *VeriGuard: Enhancing LLM Agent Safety via Verified Code Generation*. **Google Research 研究论文**，[研究页](https://research.google/pubs/veriguard-enhancing-llm-agent-safety-via-verified-code-generation/)。代码验证思想，可参考软件保障路径。
11. **Feng et al. (2026)**, *Safety Testing LLM Agents at Scale: From Risk Discovery to Evidence-Grounded Verification*（Vera）. **预印本**，[arXiv:2607.01793](https://arxiv.org/abs/2607.01793)。可执行安全案例、结果证据检验。
12. **Dantas et al. (2026)**, *Toward Safe LLM Agents: A Survey of Specification, Verification, and Enforcement*. **综述预印本**，[arXiv:2608.14590](https://arxiv.org/abs/2608.14590)。系统区分规范—验证—执行，重点研读盲区。
13. **Ferrando & Cardoso (2025/2026 上线)**, *Reliable Intention Selection in BDI Agents with Recovery Shields*. **ECAI 2025 会议论文**，[DOI:10.3233/FAIA251228](https://doi.org/10.3233/FAIA251228)。安全屏障可以暂停/恢复意图。

### B. 安全评测与工具环境（14–21）

14. **Ruan et al. (2023/ICLR 2024)**, *Identifying the Risks of LM Agents with an LM-Emulated Sandbox*（ToolEmu）. [arXiv:2309.15817](https://arxiv.org/abs/2309.15817)。在沙箱中评估工具风险，评估思路参考。
15. **Debenedetti et al. (2024)**, *AgentDojo: A Dynamic Environment to Evaluate Prompt Injection Attacks and Defenses for LLM Agents*. **NeurIPS 2024**，[论文 PDF](https://proceedings.neurips.cc/paper_files/paper/2024/file/97091a5177d8dc64b1da8bf3e1f6fb54-Paper-Datasets_and_Benchmarks_Track.pdf)。工具结果对抗与任务效用。
16. **Zhang et al. (2024)**, *Agent-SafetyBench: Evaluating the Safety of LLM Agents*. **预印本**，[arXiv:2412.14470](https://arxiv.org/abs/2412.14470)。多危险类别与安全场景。
17. **Andriushchenko et al. (2024)**, *AgentHarm: A Benchmark for Measuring Harmfulness of LLM Agents*. **预印本/另查会议发表版**，[arXiv:2410.09024](https://arxiv.org/abs/2410.09024)。用于压力测试，但不应替代工业风险真实标签。
18. **Qin et al. (2024)**, *ToolLLM: Facilitating Large Language Models to Master 16000+ Real-world APIs*. **ICLR 2024**，[会议页面](https://proceedings.iclr.cc/paper_files/paper/2024/hash/28e50ee5b72e90b50e7196fde8ea260e-Abstract-Conference.html)。工具调用数据与多步骤路径。
19. **Liu et al. (2024)**, *AgentBench: Evaluating LLMs as Agents*. **ICLR 2024**，[会议页面](https://proceedings.iclr.cc/paper_files/paper/2024/hash/e9df36b21ff4ee211a8b71ee8b7e9f57-Abstract-Conference.html)。任务完成率与 Agent 场景。
20. **Yu et al. (2025)**, *A Survey on Trustworthy LLM Agents: Threats and Countermeasures*. **综述预印本**，[arXiv:2503.09648](https://arxiv.org/abs/2503.09648)。Agent 内外信任威胁分类。
21. **Tian et al. (2025)**, *Measuring Harmfulness of Computer-Using Agents*（CUAHarm）. **预印本**，[arXiv:2508.00935](https://arxiv.org/abs/2508.00935)。可验证的计算机操作副作用与误用风险。

### C. 安全屏障、形式化方法与控制理论（22–29）

22. **Alshiekh et al. (2018)**, *Safe Reinforcement Learning via Shielding*. **AAAI 2018**，[出版社页面](https://ojs.aaai.org/index.php/AAAI/article/view/11797)。经典的“在策略外限制动作”思想。
23. **Könighofer et al. (2017)**, *Shield Synthesis*. **Formal Methods in System Design**，[DOI:10.1007/s10703-017-0276-9](https://doi.org/10.1007/s10703-017-0276-9)。可证明的屏障合成与最小干预。
24. **Jansen et al. (2018)**, *Safe Reinforcement Learning via Probabilistic Shields*. **研究预印本**，[arXiv:1807.06096](https://arxiv.org/abs/1807.06096)。概率式安全边界的重要先例。
25. **Feng et al. (2025)**, *Adaptive Shielding via Parametric Safety Proofs*. **PACMPL/OOPSLA 2025**，[DOI:10.1145/3720450](https://doi.org/10.1145/3720450)。参数化保证，直接限制“动态屏障”新颖性主张。
26. **Phan et al. (2020)**, *Neural Simplex Architecture*. **会议论文**，[机构条目](https://researchconnect.stonybrook.edu/en/publications/neural-simplex-architecture/)。可信备用控制器与在线保障。
27. **Ames et al. (2019)**, *Control Barrier Functions: Theory and Applications*. **European Control Conference**，[DOI:10.23919/ECC.2019.8796030](https://doi.org/10.23919/ECC.2019.8796030)。连续动力学下的控制约束，仅在确实有连续控制模型时适用。
28. **Batole et al. (2026)**, *RefineAct: Automatic Runtime Verification of LLM Agent Actions*. **ASE 2026 论文 PDF**，[项目论文](https://lab-design.github.io/papers/ASE-26/ase26.pdf)。运行时验证的近年竞争工作。
29. **论文题目** *Formal Runtime Verification for Tool-Using LLM Agents*. **ACM 会议/论文索引；书目细节投稿前复核**，[DOI:10.1145/3847353.3847499](https://doi.org/10.1145/3847353.3847499)。多步骤与数据依赖策略，需查全文后再决定基线。

### D. 可靠性工程、风险/因果建模（30–42）

30. **Leveson (2004)**, *A New Accident Model for Engineering Safer Systems*. **Safety Science**，[DOI:10.1016/S0925-7535(03)00047-X](https://doi.org/10.1016/S0925-7535(03)00047-X)。STAMP 思想来源。
31. **Ruijters & Stoelinga (2015)**, *Fault Tree Analysis: A Survey of the State-of-the-Art in Modeling, Analysis and Tools*. **Computer Science Review**，[DOI:10.1016/j.cosrev.2015.03.001](https://doi.org/10.1016/j.cosrev.2015.03.001)。FTA 动态与依赖建模。
32. **Yazdi et al. (2023)**, *Fault Tree Analysis Improvements: A Bibliometric Analysis and Literature Review*. **QREI**，[DOI:10.1002/qre.3271](https://doi.org/10.1002/qre.3271)。理解传统 FTA 的边界与改进。
33. **论文题目** *Bayesian Network Based Dynamic Operational Risk Assessment* (2016). **Journal of Loss Prevention in the Process Industries**，[DOI:10.1016/j.jlp.2015.11.024](https://doi.org/10.1016/j.jlp.2015.11.024)。故障树到 BN/DBN 的动态风险表达。
34. **Hund & Schroeder (2020)**, *A Causal Perspective on Reliability Assessment*. **RESS**，[DOI:10.1016/j.ress.2019.106678](https://doi.org/10.1016/j.ress.2019.106678)。可靠性推理中的因果与干预。
35. **Xu & Saleh (2021)**, *Machine Learning for Reliability Engineering and Safety Applications: Review of Current Status and Future Opportunities*. **RESS**，[DOI:10.1016/j.ress.2021.107530](https://doi.org/10.1016/j.ress.2021.107530)。机器学习与可靠性工程的交叉基准。
36. **Zio (2009)**, *Reliability Engineering: Old Problems and New Challenges*. **RESS**，[DOI:10.1016/j.ress.2008.06.002](https://doi.org/10.1016/j.ress.2008.06.002)。工程可靠性研究背景。
37. **Zheng et al. (2026)**, *Causality-Enhanced System Reliability and Safety Analysis: An Overview*. **RESS**，[DOI:10.1016/j.ress.2025.112109](https://doi.org/10.1016/j.ress.2025.112109)。当代可靠性+因果问题。
38. **Wang et al. (2026)**, *Fusion of Equipment Reliability Data through Knowledge Graphs*. **RESS**，[DOI:10.1016/j.ress.2025.111785](https://doi.org/10.1016/j.ress.2025.111785)。多源工程证据与设备状态。
39. **Jung et al. (2026)**, *An Integrated Framework for Reliability Analysis and Design Optimization Using Input, Simulation, and Experimental Data: Confidence-Based Design Optimization under Aleatory and Epistemic Uncertainty*. **RESS**，[DOI:10.1016/j.ress.2025.111895](https://doi.org/10.1016/j.ress.2025.111895)。不确定性与置信度设计。
40. **Fang et al. (2026 在线)**, *Toward Intelligent Safety Science: A Paradigm-Oriented Framework for AI-Enabled Reconstruction of Safety Theories and Models*. **RESS**，[DOI:10.1016/j.ress.2026.113546](https://doi.org/10.1016/j.ress.2026.113546)。AI+可靠性理论的期刊范围参考。
41. **Zaitseva & Levashenko (2026)**, *Reliability Engineering in Healthcare: Opportunities and Challenges*. **RESS**，[DOI:10.1016/j.ress.2025.111933](https://doi.org/10.1016/j.ress.2025.111933)。交叉学科案例，非 Agent 直接竞品。
42. **O'Connor (1998)**, *Standards in Reliability and Safety Engineering*. **RESS**，[DOI:10.1016/S0951-8320(98)83010-X](https://doi.org/10.1016/S0951-8320(98)83010-X)。标准化与工程现实的差异。

**额外必读专著（不计入论文 42 条）**：Nancy G. Leveson, *Engineering a Safer World: Systems Thinking Applied to Safety*, MIT Press, [出版社页面](https://mitpress.mit.edu/9780262016629/engineering-a-safer-world/) / [开放获取版本](https://direct.mit.edu/books/oa-monograph/2908/Engineering-a-Safer-WorldSystems-Thinking-Applied)；STPA 需要阅读原始思想，不应仅凭二手摘要设计安全模型。

### 11.1 优先阅读顺序：真正起步先读 12 篇

建议先读 **1 → 4 → 5 → 2 → 23 → 22 → 30 → 31 → 33 → 34 → 15 → 37**。读完必须输出“已有贡献/方法弱点/我们能否做出可测差异/复现难度”四列表，而不是只做论文摘要。

### 11.2 文献核查声明

本文检索对象截至 2026-10-20。arXiv 题录随版本更新，文献 29 的年份及作者等完整题录尚未二次核查，因此**正式参考文献前必须核实**；所有 42 项都有可访问的论文索引/研究页面，不把未验证的预印本强行称作 SCI 期刊论文。

---

## 12. 可以写进英文论文的贡献表述（仅供实验成功后使用）

> We study tool-using agents from the perspective of engineering system reliability, where the safety of an action depends on dynamic system state, hazardous-event severity, and accumulated execution risk. We propose a gateway-mediated framework that integrates domain hazard contracts with conservative risk estimates and a task-level intervention budget. Under explicit assumptions of complete mediation and atomic enforcement, hard safety invariants are maintained by a deterministic shield. We evaluate the effectiveness and limitations of risk-budgeted interventions using fault-injected workflows and an independently specified engineering simulator, reporting safe task completion, hazardous action execution, calibration, and end-to-end overhead.

以上是**目标论文结构性摘要**，没有结果时不要添加“优于 SOTA xx%”。

---

## 13. 建议英文稿结构

1. Introduction（危险不是单次调用而是风险随任务演化）
2. Reliability and System-Safety Background（STAMP/STPA、FTA、运行时保障）
3. Threat & System Model（可信计算边界、风险与失败前提）
4. Hazard Contracts and Evidence Semantics（如何从工程约束得到策略）
5. Risk Budgeting Algorithm（目标、更新、可行域）
6. Conditional Safety Analysis（定理与限制）
7. Implementation（可中介网关、原子条件提交）
8. Experimental Settings（任务、场景、标注、统计与基线）
9. Results（风险-效用曲线与过载/OOD）
10. Ablation and Failure Cases（实证反例也呈现）
11. Related Work（直接竞争为重点）
12. Threats to Validity and Discussion（开放世界不保证安全）
13. Conclusion

---

## 14. 项目目录骨架（只作为设计，不表示已有代码）

```text
rab-gate/
  README.md
  docs/
    proposal_CN.md
    novelty_matrix.md
    assumptions_and_limits.md
    journal_checklist.md
  contracts/
    hazard_schema.yaml
    engineering_sim.yaml
    software_workflow.yaml
  gateway/
    intercept.py
    evidence.py
    policy.py
    executor.py
    audit.py
  risk/
    confidence_bounds.py
    budget_allocator.py
    calibration.py
  simulator/
    process_model.py
    fault_injector.py
    workflow_mock.py
  experiments/
    baselines/
    scenarios/
    run.py
    analyze.py
  tests/
    test_bypass.py
    test_toctou.py
    test_safe_invariant.py
  results/  # 真实实验产出；当前没有
```

**实际数据/代码状态**：本文仅交付研究规划 MD，没有虚构基准数值，也没有声称运行任何训练、仿真或模型检查。

---

## 15. 最终立项判断与选刊路线

### 15.1 当前推荐

- **主创新**：风险预算约束下的可用性—安全性自适应保障，而不是泛化的“安全 Agent 网关”。
- **最适合一开始做的任务**：只读/可逆/不可逆三类工具并存的模拟流程；先用高质量人工危险标签测量指标，后接简化工业设备仿真。
- **先导是否值得继续**：相比 B2/B3/B4，在不牺牲同等危险执行率（或在匹配的危险率下）的条件下，**安全完成率或代价有实质优势**；若没有，则方向转为可靠性评测/风险模型论文，不硬凑“新的网关算法”。
- **冲高路径**：工程危险模型真实、具有统计校准、状态一致性强、实证非平凡、复现充足 → 尝试 RESS。
- **务实路径**：应用/统计与场景扎实但理论不强 → 先看 QREI 和与内容匹配的安全工程期刊。
- **快速投稿不等于快速发表**：至少要为一轮以上大修和可能拒稿预留时间；这份计划不承诺录用概率和固定日数。

### 15.2 下一步只需要三件事

1. 学弟决定首个环境：**软件工作流**或**纯工业仿真**；建议前者先建立可复现方法，后者提供专业交叉证明。
2. 一位可靠性工程/安全控制方向合作者审查至少一版危险定义及标签，防止“程序自己给自己打安全分”。
3. 按文献 1、4、5、23 的方法写出**差异化和最小可反驳实验**，验证是否存在可发表的新东西，再决定投入。

> **交付备注**：此文档是科研立项与选刊研究资料，不是“承诺能发表 SCI”、不代表可以用仿真脚本直接操作真实高危设备。安全约束和统计风险指标的含义必须在真实研究中严格定义并逐项验证。
