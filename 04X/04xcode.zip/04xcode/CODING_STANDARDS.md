# 代码约定

参考随研究提供的 Skill（codebase-design、domain-modeling、tdd、code-review）。

- **薄接口、深实现**：`diagnose(trace, replay_port, budget)` 是唯一研究决策入口；Go 只采集，不偷偷调用工具。
- **名词统一**：anomaly=异常，failure=任务失败，repair target=沙箱干预支持的修复位置；绝不把三者叫成同一“根因”。
- **局部性**：预算只在 `budget.py` 扣减，模拟真值仅由 `SimSandbox` 持有，真实 Span 不含 label。
- **测试行为**：Python unittest 断言可观测结果与拒绝规则；Go 竞态检测确认并发日志不互相覆盖。
- **维护**：使用明确的变量名、短函数和必要的因果/安全边界注释；不使用巨幅分隔行或空洞注释。
- **安全**：真实支付、邮件、删除、现场控制不允许回放；生产系统只读诊断。
