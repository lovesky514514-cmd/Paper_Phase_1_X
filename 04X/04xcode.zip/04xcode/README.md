# 04x · CausalGuard-RCA

Agent × 因果推断 × 故障诊断：**安全回放 + 预算约束 + 多修复集合 + 弃权**的可运行科研原型。

## 安装

- Python **3.11+**，Go **1.22+**（演示 HTTP 采集端必需）
- 无 pip 依赖、无 GPU、无 API Key、无需联网

## 运行

Windows：双击 `scripts\check_windows.bat`（自检），或 `scripts\run_windows.bat`（演示）。

Linux/macOS：`sh scripts/check.sh` 或 `sh scripts/run.sh`。

单独进行合成对照：

```bash
python -m causalguard.study --count 120 --seed 19 --out results/pilot.json
```

## 看哪里

- `causalguard/`：可观测轨迹、依赖图、预算、干预与诊断
- `collector/`：Go 的只读元数据采集（只监听本机，不执行工具调用）
- `tests/`：行为测试；`results/pilot.json`：合成对照原始记录
- `docs/DEBUG_INDEX.md`：逐文件查错修错入口；`docs/EXPERIMENT.md`：实验口径和局限

**研究边界：** `intervention_supported_in_synthetic_sandbox` 不等于生产因果证明。只有合成 SCM 有干预真值；未复现官方 AgentRx/DoVer/REFLECT，也没有真实多服务性能结论。
