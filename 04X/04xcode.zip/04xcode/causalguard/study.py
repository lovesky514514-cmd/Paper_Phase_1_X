"""Paired, seed-fixed synthetic comparison. Truth stays in the evaluator."""
from __future__ import annotations

import argparse
import json
import statistics
from pathlib import Path

from .budget import Budget
from .diagnose import diagnose
from .generate import make_case

POLICIES = ("value", "random", "anomaly", "uncertainty", "cost_only")


def study(*, count: int = 120, seed: int = 19, missing: float = 0.15,
          max_replays: int = 48) -> dict:
    if count <= 0 or max_replays < 0:
        raise ValueError("invalid study size/budget")
    cases = [make_case(seed + i, missing=missing) for i in range(count)]
    summary = {}
    for policy in POLICIES:
        rows = []
        for case in cases:
            result = diagnose(case.trace, case.sandbox, strategy=policy,
                              budget=Budget(max_replays=max_replays), seed=seed)
            predicted = set(map(frozenset, result.candidate_sets))
            actual = set(case.ground_repair_sets)
            rows.append({
                "case": case.trace.trace_id, "mode": case.fault_mode,
                "topology": case.topology,
                "repair_verified": int(bool(predicted)),
                "exact_minimal_set": int(bool(predicted & actual)),
                "answered": int(bool(predicted)),
                "spent_replays": result.budget_used["replays"],
                "unsafe_replays": result.unsafe_replays,
                "reason": result.reason,
            })
        summary[policy] = {
            "verified_repair_rate": round(statistics.mean(r["repair_verified"] for r in rows), 4),
            "exact_repair_set_hit_rate": round(statistics.mean(r["exact_minimal_set"] for r in rows), 4),
            "mean_replays": round(statistics.mean(r["spent_replays"] for r in rows), 2),
            "coverage": round(statistics.mean(r["answered"] for r in rows), 4),
            "unsafe_replays": sum(r["unsafe_replays"] for r in rows),
            "by_mode": {mode: {
                "verified": round(statistics.mean(r["repair_verified"] for r in rows if r["mode"] == mode), 4),
                "exact": round(statistics.mean(r["exact_minimal_set"] for r in rows if r["mode"] == mode), 4),
            } for mode in ("single", "or", "and") if any(r["mode"] == mode for r in rows)},
            "rows": rows,
        }
    return {"study_type": "synthetic_paired_sandbox_only", "seed": seed, "cases": count,
            "missing_fraction": missing, "max_replays": max_replays,
            "caveat": "Heuristic policies, not official AgentRx/DoVer/REFLECT replications.",
            "strategies": summary}


def main() -> None:
    parser = argparse.ArgumentParser(description="CausalGuard synthetic benchmark")
    parser.add_argument("--count", type=int, default=120)
    parser.add_argument("--seed", type=int, default=19)
    parser.add_argument("--missing", type=float, default=0.15)
    parser.add_argument("--replays", type=int, default=48)
    parser.add_argument("--out", type=Path, default=Path("results/pilot.json"))
    args = parser.parse_args()
    result = study(count=args.count, seed=args.seed,
                   missing=args.missing, max_replays=args.replays)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    for name, stats in result["strategies"].items():
        print(f"{name:12} verified={stats['verified_repair_rate']:.2%} "
              f"exact={stats['exact_repair_set_hit_rate']:.2%} "
              f"replays={stats['mean_replays']:.1f}")
    print(f"Saved to {args.out}")


if __name__ == "__main__":
    main()
