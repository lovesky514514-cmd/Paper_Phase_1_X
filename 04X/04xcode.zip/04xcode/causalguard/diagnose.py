"""Budgeted intervention selection, effect evidence and honest abstention.

A positive sandbox repair effect supports a *repair target*, not unique
structural causality or a production-world causal identification claim.
"""
from __future__ import annotations

import math
import random
import time
from dataclasses import asdict, dataclass
from itertools import combinations
from typing import Protocol

from .budget import Budget
from .graph import visible_ancestors
from .model import Trace
from .sandbox import ReplayDenied, ReplayPermit


class ReplayPort(Protocol):
    permit: ReplayPermit

    def paired_replay(self, repaired: frozenset[str], trials: int) -> tuple[tuple[int, int], ...]: ...


@dataclass(frozen=True, slots=True)
class Evidence:
    targets: tuple[str, ...]
    runs: int
    improvement: float
    lower_bound: float
    baseline_fail_rate: float
    intervention_fail_rate: float
    grade: str = "sandbox_paired_trial"


@dataclass(frozen=True, slots=True)
class Diagnosis:
    trace_id: str
    strategy: str
    candidate_sets: tuple[tuple[str, ...], ...]
    tested: tuple[Evidence, ...]
    abstained_unique: bool
    reason: str
    coverage: float
    budget_used: dict
    unsafe_replays: int
    wall_ms: float
    evidence_level: str

    def to_dict(self) -> dict:
        return asdict(self)


def _wilson_lower(successes: int, count: int, z: float = 1.96) -> float:
    if count == 0:
        return 0.0
    p = successes / count
    denom = 1 + z * z / count
    return max(0.0, (p + z * z / (2 * count) - z * math.sqrt(
        (p * (1 - p) + z * z / (4 * count)) / count)) / denom)


def _proposals(trace: Trace, strategy: str, seed: int) -> list[tuple[str, ...]]:
    eligible = [s for s in visible_ancestors(trace)
                if s.operation in {"read", "mock_write"}]
    candidates = [((s.span_id,), s.anomaly) for s in eligible]
    candidates += [((a.span_id, b.span_id), (a.anomaly + b.anomaly) / 2)
                   for a, b in combinations(eligible, 2)]
    if strategy == "random":
        rng = random.Random(seed)
        rng.shuffle(candidates)
    elif strategy == "cost_only":
        candidates.sort(key=lambda c: (len(c[0]), c[0]))
    elif strategy == "anomaly":
        candidates.sort(key=lambda c: (-c[1], c[0]))
    elif strategy == "uncertainty":
        candidates.sort(key=lambda c: (abs(c[1] - 0.5), c[0]))
    elif strategy == "value":
        # The pair bonus prioritizes interacting causes when both carry evidence.
        candidates.sort(key=lambda c: (-(c[1] * (1.25 if len(c[0]) == 2 else 1.0)
                                          - 0.08 * (len(c[0]) - 1)), c[0]))
    else:
        raise ValueError(f"unknown strategy: {strategy}")
    return [c for c, _ in candidates]


def diagnose(trace: Trace, sandbox: ReplayPort, *, strategy: str = "value",
             budget: Budget | None = None, seed: int = 0, trials: int = 4,
             min_lower_bound: float = 0.45) -> Diagnosis:
    """Diagnose only from public trace and sandbox replay receipts.

    Assumes a reproducible initial state, properly isolated execution and
    comparable paired trials. Other real-world assumptions are not verified.
    """
    started = time.perf_counter()
    budget = budget or Budget()
    if trials < 2 or trials > 64:
        raise ValueError("trials must be between 2 and 64")
    if not 0 <= min_lower_bound <= 1:
        raise ValueError("invalid evidence threshold")
    proposals = _proposals(trace, strategy, seed)
    evidence: list[Evidence] = []
    supported: list[tuple[str, ...]] = []
    reason = "no_supported_repair"

    if not trace.failed:
        reason = "task_did_not_fail"
    elif not sandbox.permit.allowed:
        reason = "replay_contract_not_satisfied"
    elif any(s.operation == "external_write" for s in trace.spans):
        reason = "external_effect_not_replayable"
    elif not proposals:
        reason = "no_safe_observed_candidates"
    else:
        for targets in proposals:
            if not budget.allows(trials):
                reason = "budget_exhausted"
                break
            # Candidate list already restricts external_write; check once more
            # so a future selector cannot bypass the safety boundary.
            span_ops = {span.span_id: span.operation for span in trace.spans}
            if any(span_ops[t] == "external_write" for t in targets):
                continue
            try:
                paired = sandbox.paired_replay(frozenset(targets), trials)
            except ReplayDenied:
                reason = "replay_denied_by_sandbox"
                break
            budget.charge(trials)
            improvements = sum(1 for before, after in paired if before == 1 and after == 0)
            harms = sum(1 for before, after in paired if before == 0 and after == 1)
            effect = sum(before - after for before, after in paired) / trials
            lower = _wilson_lower(improvements, trials) if harms == 0 else 0.0
            evidence.append(Evidence(targets, trials, effect, round(lower, 4),
                                     sum(x for x, _ in paired) / trials,
                                     sum(y for _, y in paired) / trials))
            if effect > 0 and lower >= min_lower_bound:
                supported.append(targets)
        else:
            if supported:
                reason = "supported_repair_sets_found"

    # Do not report redundant supersets as minimal verified repairs.
    minimal = sorted((s for s in supported if not any(set(t) < set(s) for t in supported)),
                     key=lambda s: (len(s), s))
    coverage = len(trace.spans) / (len(trace.spans) + trace.missing_count)
    if coverage < 1 and minimal:
        reason = "partial_observability_limits_causal_identification"
    if len(minimal) > 1:
        reason = "multiple_repair_sets_not_unique_cause"
    if minimal and reason == "budget_exhausted":
        reason = "partial_support_budget_exhausted"
    return Diagnosis(trace.trace_id, strategy, tuple(minimal), tuple(evidence), True,
                     reason, round(coverage, 4),
                     {"replays": budget.used_replays, "tokens": budget.used_tokens,
                      "time_units": budget.used_time_units, "risk_units": budget.used_risk_units},
                     0, round((time.perf_counter() - started) * 1000, 3),
                     "intervention_supported_in_synthetic_sandbox" if minimal else "observational_only")
