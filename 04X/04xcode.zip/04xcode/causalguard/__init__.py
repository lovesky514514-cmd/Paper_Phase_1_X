"""Budgeted, sandbox-only intervention diagnosis for tool-using agents."""
