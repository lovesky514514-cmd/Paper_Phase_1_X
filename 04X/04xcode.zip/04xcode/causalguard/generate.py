"""Synthetic causal cases with a sealed label used only by scoring."""
from __future__ import annotations

import hashlib
import random
from dataclasses import dataclass

from .model import Span, Trace
from .sandbox import ReplayPermit, SimSandbox


@dataclass(frozen=True, slots=True)
class TestCase:
    trace: Trace
    sandbox: SimSandbox
    # For evaluation only. Never attach these fields to Trace or Diagnoser input.
    ground_repair_sets: tuple[frozenset[str], ...]
    topology: str
    fault_mode: str


def make_case(seed: int, *, mode: str | None = None, missing: float = 0,
              topology: str | None = None, permit: ReplayPermit | None = None) -> TestCase:
    if not 0 <= missing < 1:
        raise ValueError("missing must be in [0,1)")
    rng = random.Random(seed)
    mode = mode or ("single", "or", "and")[seed % 3]
    topology = topology or ("chain", "fork", "join")[seed % 3]
    if mode not in {"single", "or", "and"} or topology not in {"chain", "fork", "join"}:
        raise ValueError("unsupported synthetic setting")
    names = ["fetch", "validate", "analyze", "cache", "report", "finish"]
    faults = frozenset(rng.sample(names[:4], 1 if mode == "single" else 2))
    parents = {
        "chain": [(), ("fetch",), ("validate",), ("analyze",), ("cache",), ("report",)],
        "fork": [(), ("fetch",), ("fetch",), ("validate",), ("analyze", "cache"), ("report",)],
        "join": [(), ("fetch",), ("fetch",), ("validate", "analyze"), ("cache",), ("report",)],
    }[topology]
    observed = []
    for i, name in enumerate(names):
        if name != "finish" and rng.random() < missing:
            continue
        anomaly = (0.63 + 0.37 * rng.random()) if name in faults else (0.06 + 0.55 * rng.random())
        # Final failure is intentionally a symptom and not eligible for repairing.
        observed.append(Span(f"case-{seed}", name, parents[i],
                             "mock_write" if name == "report" else "read", i + 1,
                             round(anomaly, 4), hashlib.sha256(f"{seed}/{name}".encode()).hexdigest()))
    if not observed:
        observed.append(Span(f"case-{seed}", "finish", (), "read", 6, 0.99,
                             hashlib.sha256(str(seed).encode()).hexdigest()))
    repairs = (tuple(frozenset([f]) for f in sorted(faults)) if mode == "and"
               else (tuple([faults]) if mode == "or" else tuple([faults])))
    return TestCase(Trace(f"case-{seed}", tuple(observed), True, len(names) - len(observed)),
                    SimSandbox(faults, mode, seed, permit), repairs, topology, mode)
