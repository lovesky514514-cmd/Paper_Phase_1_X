"""Candidate ancestry from recorded edges, not a causal identification proof."""
from __future__ import annotations

from .model import Span, Trace


def visible_ancestors(trace: Trace) -> tuple[Span, ...]:
    """Return upstream, observed spans; do not guess through missing parents."""
    by_id = {s.span_id: s for s in trace.spans}
    terminal = by_id.get("finish") or max(trace.spans, key=lambda s: s.event_time)
    found: set[str] = set()
    queue = list(terminal.parents)
    while queue:
        current = queue.pop()
        if current in found:
            continue
        if current not in by_id:
            continue  # Unknown edges cannot be filled from a synthetic truth label.
        found.add(current)
        queue.extend(by_id[current].parents)
    return tuple(sorted((by_id[k] for k in found), key=lambda s: s.event_time))
