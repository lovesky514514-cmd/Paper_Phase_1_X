"""Deterministic budget accounting; wall-clock time is reported separately."""
from dataclasses import dataclass, fields


@dataclass(slots=True)
class Budget:
    max_replays: int = 48
    max_tokens: int = 480
    max_time_units: int = 96
    max_risk_units: int = 0
    used_replays: int = 0
    used_tokens: int = 0
    used_time_units: int = 0
    used_risk_units: int = 0

    def __post_init__(self) -> None:
        if any(v < 0 for v in (getattr(self, field.name) for field in fields(self))):
            raise ValueError("budget fields must be non-negative")

    def allows(self, n: int, *, risky: bool = False) -> bool:
        return (n > 0 and self.used_replays + 2 * n <= self.max_replays
                and self.used_tokens + 6 * n <= self.max_tokens
                and self.used_time_units + 2 * n <= self.max_time_units
                and self.used_risk_units + (n if risky else 0) <= self.max_risk_units)

    def charge(self, n: int, *, risky: bool = False) -> None:
        if not self.allows(n, risky=risky):
            raise ValueError("diagnostic budget exceeded")
        self.used_replays += 2 * n
        self.used_tokens += 6 * n
        self.used_time_units += 2 * n
        self.used_risk_units += n if risky else 0
