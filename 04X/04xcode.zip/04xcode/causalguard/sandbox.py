"""Only an isolated deterministic simulator may receive diagnostic interventions."""
from __future__ import annotations

import hashlib
import random
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class ReplayPermit:
    isolated: bool = True
    egress_blocked: bool = True
    snapshot_complete: bool = True
    user_authorized: bool = True
    state_version_matches: bool = True
    all_writes_mocked: bool = True

    @property
    def allowed(self) -> bool:
        return all((self.isolated, self.egress_blocked, self.snapshot_complete,
                    self.user_authorized, self.state_version_matches, self.all_writes_mocked))


class ReplayDenied(RuntimeError):
    """Unsafe or externally effective replay is not permitted."""


class SimSandbox:
    """Private test oracle; never pass hidden fault metadata to the selector.

    Mode 'or': any uncorrected fault fails. Mode 'and': all named faults
    must remain for failure. 'single' is the one-fault special case.
    A small shared nuisance rate models stochastic execution errors.
    """

    def __init__(self, faults: frozenset[str], mode: str, seed: int,
                 permit: ReplayPermit | None = None, nuisance: float = 0.04):
        if not faults or mode not in {"single", "or", "and"}:
            raise ValueError("invalid synthetic SCM")
        if mode == "single" and len(faults) != 1:
            raise ValueError("single expects one fault")
        if not 0 <= nuisance < 1:
            raise ValueError("invalid noise")
        self.__faults = faults  # Ground truth stays inside replay implementation.
        self.__mode = mode
        self.__seed = seed
        self.__nuisance = nuisance
        self.permit = permit or ReplayPermit()
        self.replay_count = 0

    def _failed(self, repaired: frozenset[str], trial: int) -> bool:
        active = self.__faults - repaired
        structural = bool(active) if self.__mode in {"single", "or"} else (active == self.__faults)
        # Independent nuisance generated from the same random stream for paired trials.
        digest = hashlib.sha256(f"{self.__seed}/{trial}".encode()).digest()
        noise = random.Random(int.from_bytes(digest[:8], "big")).random()
        return structural or noise < self.__nuisance

    def paired_replay(self, repaired: frozenset[str], trials: int) -> tuple[tuple[int, int], ...]:
        if not self.permit.allowed:
            raise ReplayDenied("snapshot, authorization or isolation contract invalid")
        if not repaired or trials <= 0 or trials > 64:
            raise ValueError("invalid intervention")
        self.replay_count += 2 * trials
        return tuple((int(self._failed(frozenset(), t)), int(self._failed(repaired, t)))
                     for t in range(trials))
