"""Stable, sanitized trace schema. No hidden causal labels live in Trace."""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Literal

Op = Literal["read", "mock_write", "external_write"]


@dataclass(frozen=True, slots=True)
class Span:
    trace_id: str
    span_id: str
    parents: tuple[str, ...]
    operation: Op
    event_time: int
    anomaly: float
    input_digest: str
    schema_version: str = "causalguard.span.v1"

    def to_dict(self) -> dict:
        data = asdict(self)
        data["parents"] = list(self.parents)
        return data

    @staticmethod
    def from_dict(data: dict) -> "Span":
        required = {"trace_id", "span_id", "parents", "operation", "event_time", "anomaly", "input_digest"}
        if not required <= data.keys():
            raise ValueError("trace missing required metadata")
        if data.get("schema_version", "causalguard.span.v1") != "causalguard.span.v1":
            raise ValueError("unsupported trace schema")
        if type(data["event_time"]) is not int or data["event_time"] < 0:
            raise ValueError("invalid event time")
        if not isinstance(data["parents"], list) or any(not isinstance(p, str) for p in data["parents"]):
            raise ValueError("invalid parents")
        if data["operation"] not in ("read", "mock_write", "external_write"):
            raise ValueError("unknown operation")
        if type(data["anomaly"]) not in (float, int) or not 0 <= data["anomaly"] <= 1:
            raise ValueError("invalid anomaly score")
        if not all(isinstance(data[k], str) and data[k] for k in ("trace_id", "span_id", "input_digest")):
            raise ValueError("invalid identifier")
        # Deliberately ignore unknown caller fields instead of persisting raw arguments.
        return Span(str(data["trace_id"]), str(data["span_id"]), tuple(data["parents"]),
                    data["operation"], data["event_time"], float(data["anomaly"]),
                    data["input_digest"])


@dataclass(frozen=True, slots=True)
class Trace:
    trace_id: str
    spans: tuple[Span, ...]
    failed: bool
    missing_count: int = 0

    def __post_init__(self) -> None:
        if not self.spans:
            raise ValueError("empty trace")
        ids = {s.span_id for s in self.spans}
        if len(ids) != len(self.spans):
            raise ValueError("duplicate span identifiers")
        if any(s.trace_id != self.trace_id for s in self.spans):
            raise ValueError("mixed traces")
        stamps = {s.span_id: s.event_time for s in self.spans}
        if any(stamps[p] >= s.event_time for s in self.spans for p in s.parents if p in stamps):
            raise ValueError("dependency contradicts event order")
        if not isinstance(self.failed, bool) or self.missing_count < 0:
            raise ValueError("invalid outcome/coverage")
