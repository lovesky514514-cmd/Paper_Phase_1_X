"""Load a Go-collected, sanitized JSONL trace without trusting extra fields."""
import json
from pathlib import Path

from .model import Span, Trace


def load_trace(path: Path, trace_id: str, *, failed: bool = True,
               missing_count: int = 0) -> Trace:
    spans = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.strip():
            row = Span.from_dict(json.loads(line))
            if row.trace_id == trace_id:
                spans.append(row)
    return Trace(trace_id, tuple(spans), failed, missing_count)
