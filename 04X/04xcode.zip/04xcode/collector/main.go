// A local-only trace collector. No executable tool or external replay endpoint.
package main

import (
	"flag"
	"log"
	"net"
	"net/http"
	"time"

	ingest "example.org/causalguard/collector/ingest"
)

func main() {
	addr := flag.String("listen", "127.0.0.1:18184", "loopback listen address")
	path := flag.String("log", "results/local-spans.jsonl", "sanitized JSONL output")
	flag.Parse()
	host, _, err := net.SplitHostPort(*addr)
	if err != nil || (host != "127.0.0.1" && host != "::1" && host != "localhost") {
		log.Fatal("collector must listen on loopback only")
	}
	recorder, err := ingest.Open(*path)
	if err != nil {
		log.Fatal(err)
	}
	defer recorder.Close()
	server := &http.Server{Addr: *addr, Handler: recorder.Handler(), ReadHeaderTimeout: 5 * time.Second}
	log.Printf("collector at %s", *addr)
	log.Fatal(server.ListenAndServe())
}
