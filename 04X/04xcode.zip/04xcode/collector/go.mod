module example.org/causalguard/collector

go 1.22
