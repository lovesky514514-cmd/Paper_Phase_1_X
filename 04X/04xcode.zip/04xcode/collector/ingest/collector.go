// Package collector stores only explicitly permitted trace metadata.
// It does not evaluate, execute, or proxy external tool calls.
package collector

import (
	"encoding/json"
	"errors"
	"io"
	"math"
	"net/http"
	"os"
	"sync"
)

const MaxBodyBytes = 32 << 10

type Span struct {
	SchemaVersion string   `json:"schema_version"`
	TraceID       string   `json:"trace_id"`
	SpanID        string   `json:"span_id"`
	Parents       []string `json:"parents"`
	Operation     string   `json:"operation"`
	EventTime     int64    `json:"event_time"`
	Anomaly       float64  `json:"anomaly"`
	InputDigest   string   `json:"input_digest"`
}

// Recorder serializes writes to keep each JSONL record intact.
type Recorder struct {
	mu   sync.Mutex
	file *os.File
}

func Open(path string) (*Recorder, error) {
	f, err := os.OpenFile(path, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0600)
	if err != nil {
		return nil, err
	}
	return &Recorder{file: f}, nil
}

func (r *Recorder) Close() error {
	r.mu.Lock()
	defer r.mu.Unlock()
	return r.file.Close()
}

func validate(s Span) error {
	if s.SchemaVersion != "causalguard.span.v1" || s.TraceID == "" || s.SpanID == "" ||
		s.InputDigest == "" || s.EventTime < 0 || s.Parents == nil ||
		math.IsNaN(s.Anomaly) || math.IsInf(s.Anomaly, 0) || s.Anomaly < 0 || s.Anomaly > 1 {
		return errors.New("invalid span metadata")
	}
	switch s.Operation {
	case "read", "mock_write", "external_write":
	default:
		return errors.New("invalid operation")
	}
	if len(s.TraceID) > 128 || len(s.SpanID) > 128 || len(s.InputDigest) != 64 || len(s.Parents) > 16 {
		return errors.New("span limits exceeded")
	}
	for _, parent := range s.Parents {
		if parent == "" || len(parent) > 128 {
			return errors.New("invalid parent")
		}
	}
	for _, c := range s.InputDigest {
		if !((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f')) {
			return errors.New("digest must be lower-case sha256")
		}
	}
	return nil
}

func (r *Recorder) Handler() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("GET /healthz", func(w http.ResponseWriter, _ *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		_, _ = io.WriteString(w, `{"status":"ok"}`)
	})
	mux.HandleFunc("POST /v1/spans", func(w http.ResponseWriter, req *http.Request) {
		// This endpoint cannot accept arbitrary Agent data: only allowlisted fields survive.
		req.Body = http.MaxBytesReader(w, req.Body, MaxBodyBytes)
		var payload Span
		decoder := json.NewDecoder(req.Body)
		decoder.DisallowUnknownFields()
		if decoder.Decode(&payload) != nil || decoder.Decode(new(any)) != io.EOF || validate(payload) != nil {
			http.Error(w, "invalid or unsafe trace record", http.StatusBadRequest)
			return
		}
		data, err := json.Marshal(payload)
		if err != nil {
			http.Error(w, "encode failed", http.StatusInternalServerError)
			return
		}
		r.mu.Lock()
		_, err = r.file.Write(append(data, '\n'))
		r.mu.Unlock()
		if err != nil {
			http.Error(w, "audit write failed", http.StatusInternalServerError)
			return
		}
		w.WriteHeader(http.StatusAccepted)
	})
	return mux
}
