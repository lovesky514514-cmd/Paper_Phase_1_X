package collector

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"testing"
)

func sample() Span {
	return Span{"causalguard.span.v1", "demo", "read", []string{}, "read", 1, 0.5, strings.Repeat("a", 64)}
}

func newRecorder(t *testing.T) (*Recorder, string) {
	t.Helper()
	path := filepath.Join(t.TempDir(), "spans.jsonl")
	r, err := Open(path)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = r.Close() })
	return r, path
}

func post(h http.Handler, body []byte) int {
	req := httptest.NewRequest("POST", "/v1/spans", bytes.NewReader(body))
	w := httptest.NewRecorder()
	h.ServeHTTP(w, req)
	return w.Code
}

func TestSanitizedReceipt(t *testing.T) {
	r, path := newRecorder(t)
	encoded, _ := json.Marshal(sample())
	if status := post(r.Handler(), encoded); status != 202 {
		t.Fatalf("status %d", status)
	}
	data, _ := os.ReadFile(path)
	if !bytes.Contains(data, []byte(`"input_digest"`)) {
		t.Fatal("missing digest")
	}
	if status := post(r.Handler(), append(encoded[:len(encoded)-1], []byte(`,"secret":"key"}`)...)); status != 400 {
		t.Fatalf("secret field accepted: %d", status)
	}
}

func TestInvalidRecords(t *testing.T) {
	r, _ := newRecorder(t)
	invalid := sample()
	invalid.Operation = "exec"
	data, _ := json.Marshal(invalid)
	if post(r.Handler(), data) != 400 {
		t.Fatal("unknown operation accepted")
	}
	if post(r.Handler(), bytes.Repeat([]byte("X"), MaxBodyBytes+1)) != 400 {
		t.Fatal("oversized record")
	}
}

func TestConcurrentAtomicWrites(t *testing.T) {
	r, path := newRecorder(t)
	var wg sync.WaitGroup
	for i := 0; i < 30; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			data, _ := json.Marshal(sample())
			if post(r.Handler(), data) != 202 {
				t.Error("ingest failed")
			}
		}()
	}
	wg.Wait()
	content, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	lines := bytes.Split(bytes.TrimSpace(content), []byte("\n"))
	if len(lines) != 30 {
		t.Fatalf("got %d records", len(lines))
	}
	for _, line := range lines {
		var span Span
		if json.Unmarshal(line, &span) != nil {
			t.Fatal("interleaved JSONL")
		}
	}
}
