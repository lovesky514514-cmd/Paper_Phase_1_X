# 交叉学科 SCI 研究报告 04：Agent × 因果推断 × 故障诊断

> **研究阶段**：选题与预注册实验设计；不是已完成、已验证或可投稿的论文。  
> **资料截点**：2026-10-20。  
> **适合团队**：熟悉 Agent 调用链、后端网关与 Python/Go 的学生；建议增加一名具备因果推断或统计学习基础的合作者。  
> **选刊硬约束**：优先 SCIE 期刊、非开放获取（subscription / traditional）发表路线不收 APC；审稿相对快；不以“快速初筛”替代“快速录用”。  
> **文献策略**：主要收录可通过 DOI、出版社、会议官方或 arXiv 定位的真实工作，正式论文与预印本分开标识；第 11 节列出 **38 篇/项**学术研究文献（含综述），另附规范及数据资源。

## 0. 一页结论

**建议论文题目（工作标题）**：

**CausalGuard-RCA: Budgeted and Safe Interventional Diagnosis for Partially Observable Tool-Using Agents**

中文：**面向部分可观测工具调用智能体的预算约束与安全干预式根因诊断方法**。

**核心科学主张**：**Agent 最后失败的位置、最早出现异常的位置、最有修复价值的位置，可能是三个不同的位置；仅凭日志相关性通常不能证明因果性。** 故障诊断应当明确区分「观察到的异常」「在某些假设下的可能原因」「经受控干预支持的可修复原因」，并允许在证据不足时弃权。

**推荐切口**：既不重复 Who&When / AgentRx 的失败步定位，也不把 DoVer / REFLECT 已经研究的“干预回放”冒充首次创新；把贡献收敛为：

1. **受约束的干预选择（Constrained intervention selection）**：在固定算力、时间、Token、外部工具副作用风险预算内，优先选择信息价值最高的安全干预，并明确不可重放动作；
2. **多根因集合与可修复性区分（Multiple sufficient causes vs. repairable causes）**：不强行输出唯一故障点，面对交互失效、替代因果路径给出原因集合/干预集合及可修复性证据；
3. **部分可观测与可弃权因果报告（Partial observability & abstention）**：区分图结构证据、真实沙箱执行证据与模型反事实估计；置信区间不足或干预不可执行时输出“未知/不可识别”。

**投稿层级判断**：如果只做一个“LLM 读日志并找故障点”的应用，较高水平 SCI 竞争力不足；若有明确识别假设、成本受控的干预策略、现实分布外验证和严谨对照，优先考虑 **Expert Systems with Applications（ESWA）**、**Future Generation Computer Systems（FGCS）**；若侧重软件实验和工程可重复性，则 **Information and Software Technology（IST）**、**Journal of Systems and Software（JSS）**。这些仅为方向匹配，不代表分区、收录或录用保证。

---

## 1. 研究问题：究竟什么是“真正的故障原因”？

### 1.1 一个可测试案例

一个多 Agent 系统承担报表任务：

`用户指令 → Planner → 检索 Agent → 数据校验工具 → 分析 Agent → 文件写入工具 → 最终答复`

- 第 2 步检索 Agent 读取了**过期库存数据**（上游数据缺陷）。
- 第 4 步分析 Agent 根据这些数据得到了**数值正确但语义错误**的结论（下游症状）。
- 第 5 步文件写入工具成功，却把错误分析**持久化**（后果扩大）。
- 最后回复超时（最明显的**终端报错**）。

“最后超时”是直接观察到的故障，不等同于造成业务错误的根因。把第 5 步改成写入成功，也未必能恢复正确性。要证实过期库存数据在特定运行上下文中具有实际致因作用，需要明确可行干预与对照。

### 1.2 必须统一的四个定义

| 名称 | 建议严格定义 | 需要的证据 |
|---|---|---|
| 异常（anomaly） | 某事件偏离正常统计分布或契约 | 监测数据、规则、残差 |
| 失败（failure） | 任务级验收目标未达成 | 可重复验收器或人工标注 |
| 致因候选（candidate cause） | 在依赖图与时间顺序上可能影响失败的事件/状态 | 调用链、可观察状态及结构先验 |
| 干预支持的可修复原因（intervention-supported repair target） | 在受控条件下替换该因素后，失败概率下降或目标进度改善 | 干预记录、对照重放、重复试验 |

特别注意：**找到有效修复补丁不等于唯一根因被识别**。可能存在两个不同的干预均能恢复成功（过度决定/替代修复），因此实验要同时报告故障原因集合、最小修复集合和干预假设。

### 1.3 可发表的研究问题（RQ）

- **RQ1**：在同等干预预算下，所提策略是否比随机干预、按异常分数排序和纯 LLM 诊断更高效地发现可修复故障？
- **RQ2**：在多个充分原因、交互因果和错误传播条件下，是否比“唯一根因”方法更少做出错误确定性断言？
- **RQ3**：当日志缺失、时间戳漂移、隐藏状态及模型误设增加时，方法的准确率与置信度校准如何变化？
- **RQ4**：网关级部署是否能保留足够诊断证据，且不引入不可接受的 P95 延迟、存储和 Token 成本？
- **RQ5**：面对沙箱不可重放或具有外部不可逆副作用的操作，安全回放机制能否正确拒绝危险干预？

---

## 2. 与最新直接竞争论文的关系（先排除撞题）

以下不是“论文第一次提出……”的宣传表，而是拟投稿时必须交代的工作边界。

| 直接竞争研究 | 已有贡献（按论文公开摘要/项目说明） | 本题不能再声称的首创 | 尚可开展的比较实验 |
|---|---|---|---|
| **Who&When, 2025** | 多 Agent 失败归因任务、错误 Agent/步骤标注数据 | 失败步/责任 Agent 自动定位 | 将责任步定位与干预验证、原因集合分开评价 |
| **AgentRx, 2026** | 基于执行轨迹的约束检查、审计证据与关键步骤定位；115 条已标注轨迹 | “可解释 Agent 故障定位” | 受控干预消歧、预算与弃权 |
| **DoVer, ICLR 2026** | 干预式多 Agent 调试，考虑多种修复路径，评价任务恢复 | “把干预加入 Agent 调试” | 风险预算、不可逆动作、选择性归因稳定性 |
| **REFLECT, 2026 预印本** | 通过受控回放的结果反馈修正归因 | “回放改进故障归因” | 部分可观测、预算优化、多根因集合、拒答 |
| **AgentTrace（因果图版）, 2026 预印本** | 轻量因果图回溯与结构排名 | “从调用链建图并追溯异常” | 结构归因与真正可执行干预的差距 |
| **CEG-Agent, 2026 预印本** | 区分异常、错误、失败，并构建因果错误图 | “区分异常和失败” | 图边可识别性、置信区间、真实干预证据 |
| **AgentEval（DAG 版）, 2026 预印本** | DAG 级错误传播与层次失效分类 | “以 DAG 表示多步骤失败” | 不只分类、而是验证最小修复集合 |
| **Why Did the Agent Fail?, EIT 2026** | 在组合 Agent 中使用结构因果模型、反事实与干预归因指标 | “首次 SCM 解释 Agent 根因” | 分布外扰动、有限预算、安全回放与因果假设压力测试 |
| **Causal Agent Replay, 2026 预印本** | 反事实 Agent 轨迹重放归因 | “首次反事实逐步消融” | 重放不可行时的稳健替代与弃权 |
| **Causal Detection of Multi-Step LLM Agent Attacks, ICML 2026** | 用 SCM、do 运算区分攻击依赖与正常执行，恢复攻击链 | “首次从 Agent 轨迹做因果切片” | 通用故障、业务效果与复杂副作用的工程验证 |

**最重要的创新风险**：若实验只是“先 LLM 标记异常，再在相邻步骤做回放，Top-1 上升”，非常容易与已有工作同质化；新方法必须让**预算约束 + 安全不可重放 + 多原因 + 校准弃权**至少一项成为可独立检验、可复现的核心算法贡献。并非所有四项都必须同一篇做完。

---

## 3. 主算法设计：CausalGuard-RCA（待实现）

### 3.1 系统层次与“最小侵入”

```text
业务 Agent / Planner / 子 Agent
           │
           ▼
    API / MCP / Tool Gateway
           │  trace_id, span_id, parent_id, tool_id
           │  event_time, operation class, idempotency key
           │  sanitized input/output fingerprint, state versions
           ▼
 [事件规范化 + 时间/调用依赖对齐]
           │
           ▼
 [结构先验 + 观测异常 + 候选原因集合]
           │
           ▼
 [干预计划器：价值 / 成本 / 风险预算]
        ┌──┴──────────────────────────┐
        ▼                             ▼
  隔离沙箱可安全重放             不可重放/风险过高
        │                             │
   多次干预与对照                保留未知/升级人工
        │                             │
        └────────────┬────────────────┘
                     ▼
 [原因集合 + 因果证据等级 + 校准置信度]
                     │
                     ▼
          JSON 报告 + 可审计试验清单
```

网关采集应参考 OpenTelemetry GenAI 的 `execute_tool` 和 Agent span 语义约定，但需注意相关 GenAI 语义规范仍包含 **Development** 状态字段，代码应通过版本化适配层隔离，不要将草案字段当作不可变标准。

### 3.2 一组简洁但规范的数学变量

- 轨迹：`τ = (e₁, …, e_T)`，事件 `e_i` 含 Agent、工具、上下文、观测状态与时间戳；
- 隐状态：`S_t`，只观察到 `O_t = g(S_t, ε_t)`；
- 决策与工具动作：`A_t`；任务失败指示器：`Y ∈ {0,1}`（1 表示失败）；
- 因果依赖：`G = (V,E)`，由**结构先验 + 记录依赖 + 时序约束**推断，边的存在不自动等于因果证明；
- 候选干预：`I=(v, a')`，在受控环境将某一步骤/状态替换为安全、可执行的参考值；
- 已用诊断预算：`B_token, B_time, B_replay, B_risk`；
- 以多个随机种子/复现实验估计：`Δ(I) = P(Y=1 | baseline) - P(Y=1 | do(I), context)`。

**警告**：上式若基线与干预样本并不来自可比较的随机化/受控重放条件，只是经验差异，并非已识别的平均因果效应。必须在设计中写明：一致性、可干预性、隐藏混杂/状态重置假设、回放真实性与样本独立性。

### 3.3 预算约束干预策略（主要算法创新候选）

对待测干预 `I`，估计：

- `IG(I)`：预计对根因假设后验的**信息增益**（可用预测熵下降近似）；
- `C(I)`：回放时间 + API/token 成本 + 计算成本；
- `R(I)`：工具调用副作用风险与数据泄露/不可逆写入风险；
- `F(I)`：可行性（权限、快照完整度、幂等性、重放工具覆盖）；
- `D(I)`：预计的任务恢复或重要里程碑改进；

定义示意得分：

`Score(I) = α·IG(I) + β·D(I) − λ·C(I) − μ·R(I)`。

当 `F(I)=false` 或超出预算、外部动作不可安全隔离时 **直接禁止执行**，而非仅仅扣分；未验证的 `IG` 与 `D` 是模型预测，要记录偏差与实际误差。

算法可采用 **成本感知的贝叶斯实验设计 / constrained bandit** 作为策略基线，先以贪心选择完成最小版本；与随机、uncertainty-only、cost-only、DoVer 风格启发式作公平比较。若要提出新理论，需证明特定条件下的预算竞争比/样本复杂度；达不到理论前提，不声称普遍最优。

### 3.4 多原因、交互效应和诊断弃权

多原因示例：错误缓存 `A` 和过期规则 `B` **任一都可能独立导致失败**；单独修复 A 后仍失败并不能证明 A 不是原因。另一个例子是 A、B **同时出现才导致失败**；任何一个单独替换都可能恢复任务。

报告应输出：

```json
{
  "failure_id": "illustration-001",
  "observed_symptoms": ["timeout", "wrong_report"],
  "candidate_sets": [["stale_cache"], ["obsolete_policy"]],
  "tested_interventions": [
    {"id": "replace_cache_snapshot", "safe": true, "replicates": 20, "effect_ci": "estimated_at_runtime"}
  ],
  "evidence_level": "intervention_supported_in_sandbox",
  "identification_status": "partial",
  "abstained_on_unique_root_cause": true,
  "reason": "multiple sufficient causes remain compatible"
}
```

该 JSON 是**模式示例**，不是已经做出的实验或数值结果。多根因集合可用 minimal hitting set、分组测试及稀疏交互效应估计，具体选择需由规模、可行性与样本量决定。要求进行 bootstrap / 贝叶斯后验区间校准；把“多个解释都成立”如实写出，往往比臆断一个 root cause 更有科研价值。

### 3.5 安全回放的边界

- **只在测试沙箱执行干预**，生产系统只读诊断；
- 使用克隆状态/事件日志隔离，API 出站默认阻断，真实邮件发送、支付、删除、工控指令不得直接重放；
- 对可幂等操作保留幂等键，对不可幂等操作使用模拟端点；
- 对数据库读写采用快照或事务沙箱（不能把业务事务可回滚和外部世界可回滚混为一谈）；
- 捕捉模型随机性，采用成对随机种子和相同初始状态的干预组/对照组；
- 若对照世界不可信、日志缺字段、快照无法完全复原，证据等级应降为“模拟支持”或“不可判定”。

**可证明范围**：若网关具有完全中介权、全部外部副作用均被隔离、策略检查无绕过，才能证明实验期间“不执行受禁止外部操作”。这不是对**根因识别正确率**的形式化保证，更不能从单一回放推导生产世界的真实因果结构。

### 3.6 伪代码（研究原型）

```python
# 研究原型伪代码，不可直接用于生产环境

def diagnose(trace, policy, budget, sandbox):
    graph = build_dependency_graph(trace)  # 仅结构候选，不直接宣称因果
    hypotheses = generate_hypothesis_sets(graph, trace)
    evidence = []
    while budget.remaining() and not sufficiently_resolved(hypotheses):
        candidates = propose_interventions(hypotheses)
        safe = [i for i in candidates if policy.safe_to_replay(i, sandbox)]
        if not safe:
            break
        intervention = select_by_value_cost_risk(safe, hypotheses, budget)
        paired = sandbox.paired_replay(intervention, fixed_initial_state=True)
        evidence.append(paired)
        budget.charge(paired.measured_cost)
        hypotheses = update_with_intervention_evidence(hypotheses, paired)
    return report_with_uncertainty_and_abstention(hypotheses, evidence)
```

---

## 4. 八个可拓展的交叉学科子课题

| 子课题 | 交叉学科来源 | 一句话主观点 | 可验证创新点 | 推荐实验 |
|---|---|---|---|---|
| 4A. 因果贝叶斯实验设计 | 统计学、主动学习 | 不是干预越多越好 | 有预算最优/近似最优试验选取 | 同预算下命中率与效应方差 |
| 4B. 可靠性工程故障树 | 系统安全、可靠性 | Agent 多故障并发使唯一根因不成立 | 故障树门逻辑与原因集合结合 | AND/OR 共因、级联注入 |
| 4C. 软件调试与反事实执行 | 软件工程、程序分析 | 逻辑依赖不同于故障责任 | 程序切片 + 沙箱修复验证 | 代码/配置/工具错误分层 |
| 4D. 可观测性与图学习 | 分布式系统、图模型 | 更完整的日志不总是更准确 | 自适应遥测采样、抗日志缺失 | 10%–70% 缺失率鲁棒性 |
| 4E. 因果博弈与责任分配 | 多主体博弈、合作博弈 | 多主体责任不是单步加分 | 交互贡献与原因集合排名 | Shapley vs 最小修复集合 |
| 4F. 控制系统辨识 | 控制理论、状态估计 | 干预要区分真实状态与观测误差 | 隐状态估计 + 不确定性感知 | 传感器漂移/状态延迟 |
| 4G. 运筹优化与序贯决策 | 约束优化、bandit | 诊断资源应分配给最有价值的试验 | 多预算约束自适应停止 | 延迟/成本/准确率帕累托前沿 |
| 4H. 网络安全与数字取证 | 网络安全、证据链 | 推测的攻击链不等于验证的原因链 | 可追溯因果证据与安全重放 | 注入攻击、权限错误与副作用 |

**推荐先做 4A + 4C + 4D**：适合 Agent 与后端网关同学，依赖计算资源相对少；4B 可做高水平解释与共因测试；涉及工控或医疗真实世界时应另寻领域合作，不能以合成实验替代现场有效性。

---

## 5. 实验设计：如何从“demo”变成科学研究

### 5.1 三层实验结构

**L0 可控合成因果基准**（用来证明/证伪方法机制）

- 构造不同拓扑：链式、分叉、汇合、环状工作流（动态展开为时间有向图）；
- 生成故障：单点源头、双故障独立路径、交互式共因、工具超时、缓存脏读、检索污染、上下文状态失效；
- 注入隐藏共同因素（网络拥塞、模型版本变更）、日志缺失、时间戳漂移；
- 由生成器显式保存真实 SCM/故障注入点、替代原因集、受控干预真值。

**L1 真实开源 Agent 轨迹**（检验外部有效性）

- [Who&When](https://arxiv.org/abs/2505.00212)：多 Agent 失败归因与精细注释；若只给步骤标签，不可直接当“真实因果效应”标注；
- [AgentRx / AgentRx Benchmark](https://github.com/microsoft/AgentRx)：已发布轨迹与约束检查，论文称 115 条标注失败轨迹；需要核实许可和版本；
- [τ 系列 benchmark](https://github.com/sierra-research/tau2-bench)：有状态工具交互；固定评测版本与数据，注意 2026 年评分修订影响可比性；
- [DoVer](https://www.microsoft.com/en-us/research/publication/dover-intervention-driven-auto-debugging-for-llm-multi-agent-systems/)：尝试复现干预/恢复实验，若代码/数据未能实际复现必须在结果中说明。

**L2 后端分布式工具环境**（验证系统工程价值）

- [DeathStarBench](https://github.com/delimitrou/DeathStarBench)：将网关接到 microservice 服务链，注入网络故障、资源抢占与失效依赖；
- OpenTelemetry 接入：测量 span 覆盖率、跨服务 parent 关联正确率、存储与时间开销；
- 业务无危险外部副作用：优先模拟报表生成、库存核对、文件写入仿真等任务。

### 5.2 基线必须公平

| 基线 | 对照目的 | 公平性要求 |
|---|---|---|
| Last-error / first-anomaly | 简单局部启发式 | 同样可观测日志 |
| 结构拓扑反向传播 + PageRank | 不做干预的图 RCA | 相同拓扑数据 |
| AgentRx 风格约束定位 | 规则证据型 Agent RCA | 同一类别约束输入/LLM 预算 |
| AgentTrace 风格因果图排序 | 轻量结构归因 | 相同日志采集成本 |
| Who&When 的公开诊断基线 | Agent 和故障步骤定位 | 原样复现实验口径 |
| DoVer / REFLECT 风格干预 | 最直接的创新竞争者 | **相同沙箱、干预次数、时间/Token 预算** |
| Random / uncertainty / cost-only 干预 | 测试预算策略增益 | 相同可行性过滤与停止条件 |
| 理想 oracle（只用于上界） | 确认方法是否接近真值 | 标注为不可部署上界 |

若代码缺失，不可把按摘要重写的“近似版”标为官方 SOTA 复现；必须写 *faithful reimplementation* 并提供实现差异说明。

### 5.3 主要指标与报告方式

| 指标 | 具体定义 | 防止误读 |
|---|---|---|
| Root-cause Top-1 / Top-3 | 命中标注因果源/责任步骤的比例 | 只能在定义相同的数据集比较 |
| Cause-set F1 / Jaccard | 预测的多原因集合与真值集合一致程度 | 不将多根因硬压缩成单点 |
| Verified Repair@B | 给定预算 B 内经重放验证的可修复比例 | 是“修复成功”，不等于唯一原因正确 |
| Cost per verified repair | 成功确认一个可修复位置所用 Token、秒数、调用数 | 失败样本也应计入成本 |
| Selective risk / coverage | 拒答率与已回答部分错误率 | 高准确率不能靠全部拒答获得 |
| ECE / Brier / CI coverage | 后验/效果置信度的校准情况 | 对低样本置信度不得过分自信 |
| Unsafe replay count | 违规发出危险外部操作数量 | 目标应为 0，报告覆盖范围及漏洞 |
| P50/P95 overhead | 网关增加的延迟/吞吐/存储 | 同机器、同负载、含日志开销 |
| OOD robustness | 新工具、拓扑变化、未见故障类型上的性能 | 必须分域拆分，不能随机切分泄漏 |

### 5.4 应做的消融研究

A1：去掉成本约束；A2：去掉风险过滤；A3：把多原因集合强制变成单原因；A4：不做安全回放，仅用图排序；A5：不允许弃权；A6：不建时间依赖；A7：把潜在状态先验删除；A8：干预选择由模型预测替换为随机；A9：日志完整率分级；A10：不同 LLM / 零 LLM 判断器；A11：限制只用网关 Span；A12：不同预算 B 与任务长度。

### 5.5 统计设计（避免“漂亮表格但不可信”）

- 在研究启动时固定训练/调参/验证/最终测试边界，绝不在测试集上反复选择算法；
- 各条件运行不同随机种子，建议初步每条件 ≥5 种种子，并依据方差和最小可检测效应增加重复，而不是将 5 当作统计充分性保证；
- 成对比较使用 bootstrap 95% CI 或恰当的配对检验；多个基线/多数据集时校正多重检验；
- 对 Token、API 单价、机器型号与网络波动记录完整；
- 显示每个数据集、故障类型、轨迹长度的拆分结果，不只汇总一个平均分；
- 公开失败案例与反例，不删除方法未识别根因的试验；
- 提供可复现实验配置、仓库 commit、锁定依赖与生成器真值元数据；
- 如果没有足够人工标注，明确将合成数据、专家标注和“LLM 自动标签”分为不同证据等级。

### 5.6 论文必要的负面结果

必须报告：**无法复原外部世界、隐藏混杂严重、非确定性过强、多故障互相补偿、实测效果无统计意义** 等条件下的方法失效；这类结果反而能够说明你们理解因果识别的边界。

---

## 6. 最小可运行版本与升级路线

### MVP：先证明不是重命名旧论文（建议第 1—4 周）

- 选定 3 类因果图：链式源头故障、并行双因故障、交互型故障；
- 合成 100–200 个任务轨迹作为**内部开发设计目标**，不能宣传为已经存在数据集；
- 实现网关事件记录 + 反向候选检索；
- 只实现沙箱内安全的状态替换，不调用真实外部 API；
- 分别比较随机、异常优先、成本优先、主动信息增益选择；
- 输出干预预算—验证成功率曲线以及多根因失效案例。

**第一道停项门槛（预先约定）**：如果同预算下对照的优势没有稳定复现，先查选择偏差与泄漏，不继续堆 LLM 提示词；如果随机基线已接近最优，应调整研究问题而非强行投稿。

### 完整版：第 5—10 周

- 接入 AgentRx / Who&When 的许可允许轨迹，并定义**可比的真值定义**；
- 建立日志缺失、隐藏状态和时间漂移实验；
- 实现多根因集合输出与置信度弃权；
- 对公开基线尽可能复现并记录差异；
- 加入预算、成本与风险多目标曲线。

### 投稿准备版：第 11—14 周（计划而非承诺）

- 多工具 Agent 系统跨域测试 + 至少一个真实微服务用例；
- 系统延迟、P95 与流量退化压力测试；
- 独立分析失败样本，封存运行日志与源码版本；
- 组装 IMRaD 正文，附假设表、基线公平性表和 Threats to Validity；
- 对照目标期刊 Scope 与最新版 Guide for Authors 做预审；
- 预注册主要指标和显著性标准，拒绝事后“挑分数最好的一组”。

> 14 周只是建议排程。是否具有 SCI 投稿竞争力由实验证据决定，不是按时间自动达标。

---

## 7. 期刊筛选：SCIE、免 APC、投稿相对快（截至 2026-10）

**判别原则**：Elsevier 对混合期刊的 **subscription/traditional** 发表通常不收 APC（发行费用来自订阅读者）；不等于全文免费阅读，也不排除少数期刊特殊页费、彩图费及资金方 OA 强制要求。期刊在投稿系统/编辑部确认前不能写“100%零费用”。[Elsevier 官方收费说明](https://www.elsevier.support/publishing/answer/what-is-elseviers-waiver-policy-for-open-access-fees) / [出版定价政策](https://www.elsevier.com/about/policies-and-standards/pricing)。

| 期刊 | 更合适的论文版本 | 投稿至录用统计 | 无 APC 线路 | 优先级与真实性提示 |
|---|---|---:|---|---|
| **Expert Systems with Applications** (ESWA) | 信息增益、因果诊断决策算法 + 跨域证据 | **约 147 天** | 通常可选订阅发表 | **快速优先之一**；偏 AI 方法而非单纯网关搭建 |
| **Computers & Security** | 如果任务重点是安全攻击根因、恶意工具与取证 | **约 162 天** | 官方 insights 页面列订阅无出版费 | 仅限安全版本，普通故障诊断不建议投 |
| **Knowledge-Based Systems** (KBS) | 结构化因果知识、推理及决策方法显著创新 | **约 165 天** | 应逐条确认传统路线及篇幅附加收费 | 有“快”的指标，但近年来个别论文实际周期差距大 |
| **Future Generation Computer Systems** (FGCS) | 多 Agent 分布式系统、可观测性和部署开销 | **约 183 天** | 通常可选订阅发表 | 工程系统定位强，适合网关落地 |
| **Journal of Network and Computer Applications** (JNCA) | 端到端网络服务诊断、跨服务调用根因 | **约 187 天** | 通常可选订阅发表 | 需要网络或分布式服务贡献而非纯 AI |
| **Software Quality Journal** (SQJ) | 软件故障定位、质量保证与复现实验 | **约 207 天**（近期已录用文章样本的中位数） | 混合出版非 OA 路线，需核查费用 | 更看重软件工程实验；样本指标非全投稿周期 |
| **Information and Software Technology** (IST) | 工程化诊断流程、可复现方法与开发者评估 | **约 233 天**（可检索镜像统计） | 通常可选订阅发表 | 与软件工程研究契合，但不算最快 |
| **Journal of Systems and Software** (JSS) | 软件系统诊断与方法比较 | **约 252 天**（可检索镜像统计） | 通常可选订阅发表 | 论文匹配度高，但时间未必比上述期刊短 |

**时间口径和取证说明**：上述数值不是人工审稿阶段的净时间，也不是承诺；147/162/165/183/187 天来自期刊 Insights 数据的公开转录（其口径通常为投稿至录用），207 天是第三方从近 24 个月已录用文章日期计算的中位数；233/252 天可在带期刊样式的第三方镜像查到，**其域名不是 Elsevier 官方网站**，只能作为低置信度参考。具体数据、更新时间与置信度见下。

| 数据 / 规则 | 链接与来源性质 | 可信度 |
|---|---|---|
| ESWA 147 天，订阅路线无发表费 | [LetPub 收录的期刊 Insights 数值](https://www.letpub.com.cn/index.php?journalid=2799&page=journalapp&view=detail)；[Elsevier Shop 期刊](https://shop.elsevier.com/journals/expert-systems-with-applications/0957-4174) | 中：时间为二次转录，出版模式有官方政策依据 |
| Computers & Security 162 天、订阅免费 | [期刊 Insights 汇总页](https://computersandsecurity.org/journal-insights/)；非出版社主域 | 中：需到 Elsevier 原站复核 |
| KBS 165 天 | [LetPub 汇总](https://www.letpub.com.cn/index.php?journalid=5495&page=journalapp&view=detail) | 中低：需核对收费、页数、最新周期 |
| FGCS 183 天 | [JournalCompass 汇总](https://journalcompass.com/journals/future-generation-computer-systems-the-international-journal-of-escien-0167739x.html) | 中：时间转录非直接实时源 |
| JNCA 187 天 | [期刊官网入口](https://www.sciencedirect.com/journal/journal-of-network-and-computer-applications/about/insights) | 待核：当前工具无法直接打开该 Insights 页 |
| SQJ 207 天 | [JournalCompass 按文章日期统计](https://journalcompass.com/journals/software-quality-journal-09639314.html) | 中：可审计样本但选择性仅含已录用文章 |
| IST 233 天、JSS 252 天 | [IST 第三方镜像](https://www.sciencedirectelsevier.com/journal/Information-and-Software-Technology)；[JSS 第三方镜像](https://www.sciencedirectelsevier.com/journal/Journal-of-Systems-and-Software) | **低**：不是 `sciencedirect.com`，严禁当作正式出版商实时数据 |
| 订阅路线一般免 APC | [Elsevier 官方帮助中心](https://www.elsevier.support/publishing/answer/what-is-elseviers-waiver-policy-for-open-access-fees) | 高：官方政策；个刊特殊费用需再确认 |
| 当前 SCIE 收录与分区 | [Clarivate Master Journal List](https://mjl.clarivate.com/) | 正式投稿前按 ISSN 查询；不能依赖本报告锁定未来状态 |

### 7.1 按论文结果反向选刊

1. **有新的因果/决策算法 + 3 个跨场景实验**：先看 ESWA；若重点是因果知识结构，评估 KBS；
2. **有运行级网关系统 + 微服务压力测试 + 全套复现**：先看 FGCS 或 JNCA；
3. **有软件工程领域实证、程序/工具故障注入和开发者研究**：看 IST 或 JSS；
4. **有攻击链归因、安全日志与对抗评估**：才考虑 Computers & Security。

不要因为 JCR Q1/Q2 或某年中科院区而优先写作某一本：分区随年份/学科变化，无法替代 Scope。**不存在保录用、保快审、保免费且一定高区的选刊方案。**

### 7.2 简短投稿前核查清单

- 使用 ISSN 在 Clarivate MJL 确认 **SCIE** 而非单独 ESCI；
- 在出版社域名确认 **subscription option**，识别是否全 OA；
- 查看 Guide for Authors 的 page/colour/extra charges、人工/AI 使用声明、数据可用性政策；
- 区分 first decision、decision after review、submission to acceptance、acceptance to publication；
- 阅读近 12 个月同专题文章 10 篇，确认该刊愿意收工程系统/因果算法这样的论文；
- 若有单位基金要求 OA，另核算 APC 或绿色 OA 许可。

---

## 8. 高水平交叉论文究竟“高”在哪里

不是把 SCM、图网络、LLM 和 Agent 四个流行词写到一个题目里。评审更看重：

- **理论对象清楚**：你识别的是责任步骤、必要原因、充分原因、最小可修复集合，还是“有效干预方案”？避免概念偷换；
- **理论或算法增量独立成立**：预算下如何选择干预、何时弃权、什么假设保证估计收敛，不依赖“大模型很强”；
- **可干预真值**：构造可控制实验，提供真实 `do()` 级别的对照（必要时合成）；
- **分布外泛化**：新拓扑、新工具、新模型版本、新风险类别，仍然稳定而不只在同一生成器中变好；
- **生态兼容**：不修改每个 Agent 内部实现的网关部署，保留可观察性和因果安全边界；
- **严谨消融/反例**：能够清楚回答如果去掉任何核心创新，性能在哪里下降，甚至说明哪些条件不能成立。

研究下限是“可以运行的诊断 demo”；有希望投稿较好 SCI 的版本至少应提供有统计依据的实证增量和清晰的因果识别假设。高水平期刊**不因为“交叉学科”三个字自动加分**。

---

## 9. 团队分工与所需资源

| 角色 | 关键任务 | 必交付产物 |
|---|---|---|
| Agent / Gateway 主开发 | 统一 trace schema、工具网关埋点、沙箱重放、性能测试 | 可复现 trace + gateway + replay package |
| 因果推断 / 算法人员 | SCM 假设、干预价值、假设检验、集合估计与弃权校准 | 方法推导、算法实现、校准报告 |
| 评测与工程人员 | 合成生成器、故障注入、公开基准适配 | 数据协议、基线复现、完整实验表 |
| 论文负责人 | 问题界定、文献冲突、审稿匹配、质量控制 | 注册实验计划、论文、Threats to Validity |

**初期算力**：CPU 可完成图方法、合成故障和小规模回放；有 12–16GB 显存的机器可运行某些小模型判断器，但不应假定能训练大模型；涉及高质量商业 LLM 时事先限制 API 预算并报告总成本。

**工具建议**：Python（科研算法与基准适配）、Go 或 Rust（网关/采集性能可选）、Docker（隔离重放）、SQLite/PostgreSQL（实验索引）、OpenTelemetry（遥测）。避免在第一阶段同时建设大型前端平台。

---

## 10. SCI 写作框架与否决条件

### 10.1 论文正文建议

1. Introduction：为什么“观察异常”不足以判断根因，说明预算与重放安全的真实约束。
2. Related Work：Agent attribution、counterfactual debugging、microservice RCA、causal discovery 四条文献线。
3. Problem Formulation：观测过程、可行动作、隐变量、风险预算、可识别/不可识别条件。
4. Method：结构候选、干预策略、多根因集合、弃权与证据等级。
5. Experimental Setup：3 层基准、真值定义、基线公平性与可复现环境。
6. Results：诊断收益、成本曲线、泛化性、校准与安全回放结果。
7. Ablation & Failure Analysis：删除模块、无法识别案例、隐藏混杂压力测试。
8. Threats to Validity：模拟器真实性、标注一致性、概念漂移、成本来源。
9. Conclusion：严格限制在实验证明的范围内。

### 10.2 需要停止冲高刊的情况

- 仅有单域合成数据，没有公开基准复核；
- 与 AgentRx/DoVer/REFLECT 之间无可复现、预算匹配的比较；
- 训练和测试泄漏，或者所谓干预只是让 LLM“想象改了以后怎样”；
- “根因真值”其实完全由另一模型自动生成，且没有专家/执行级审查；
- 仅报告单一准确率，不提供修复收益、成本、拒答率与错误案例；
- 以测试环境安全推断真实生产环境安全；
- 数学部分只是给已有算法重新起名，未说明新增假设/结论。

---

## 11. 关联论文（按阅读价值分类；见行内原始链接）

标记释义：**[会议] / [期刊]** 表示可查到正式场所，**[预印本]** 表示当前列出的版本不应自动视为同行评审通过；个别研究可能存在同名异文、后续录用或更新，以作者主页/出版社 DOI 为准。关联文献包含直接竞争、方法基础和系统相邻研究，并不是全部“Agent RCA 直接论文”。

### A. Agent 根因与反事实直接竞争

1. **[AgentRx: Diagnosing AI Agent Failures from Execution Trajectories](https://www.microsoft.com/en-us/research/publication/agentrx-diagnosing-ai-agent-failures-from-execution-trajectories/)**（2026，[会议，EMNLP 2026 / 预印本版本并存]）——证据化 Agent 故障步定位，必须直接比较。
2. **[Which Agent Causes Task Failures and When? On Automated Failure Attribution of LLM Multi-Agent Systems](https://arxiv.org/abs/2505.00212)**（2025，[预印本]）——Who&When 数据集和归因基准。
3. **[DoVer: Intervention-Driven Auto Debugging for LLM Multi-Agent Systems](https://www.microsoft.com/en-us/research/publication/dover-intervention-driven-auto-debugging-for-llm-multi-agent-systems/)**（2026，[会议，ICLR 2026]）——受控干预和多重修复竞争者。
4. **[REFLECT: Intervention-Supported Error Attribution for Silent Failures in LLM Agent Traces](https://arxiv.org/abs/2606.09071)**（2026，[预印本]）——通过回放反馈修正归因。
5. **[AgentTrace: Causal Graph Tracing for Root Cause Analysis in Deployed Multi-Agent Systems](https://arxiv.org/abs/2603.14688)**（2026，[预印本]）——调用链因果图定位；不可视作真正 do 级证明。
6. **[AgentTrace: A Structured Logging Framework for Agent System Observability](https://arxiv.org/abs/2602.10133)**（2026，[预印本]）——同名另一篇，重点是 Agent 可观测性。
7. **[From Anomalies to Failures: Constructing Causal Error Graphs for Agentic Trace Diagnosis](https://arxiv.org/abs/2609.32514)**（2026，[预印本]）——CEG-Agent 的错误传播因果图。
8. **[AgentEval: DAG-Structured Step-Level Evaluation for Agentic Workflows with Error Propagation Tracking](https://arxiv.org/abs/2604.23581)**（2026，[预印本]）——基于 DAG 的错误传播评价。
9. **[AgentEval: Evidence-Bounded Assessment of Stateful Agents](https://arxiv.org/abs/2610.21177)**（2026，[预印本]）——同名另一项研究，强调状态与证据绑定。
10. **[Why Did the Agent Fail? Root Cause Analysis for Compositional AI Agents](https://doi.org/10.1109/EIT68936.2026.11670338)**（2026，[会议，EIT 2026]）——SCM 和干预指标，直接撞题风险高。
11. **[Causal Agent Replay: Counterfactual Attribution for LLM-Agent Failures](https://arxiv.org/abs/2606.08275)**（2026，[预印本]）——逐步反事实消融和归因。
12. **[Causal Detection of Multi-Step LLM Agent Attacks](https://proceedings.mlr.press/v306/mothukuri26a.html)**（2026，[会议，ICML 2026]）——攻击链因果切片与反事实。
13. **[TRACE: TRajectory Attribution for Automated Context Engineering](https://arxiv.org/abs/2608.09153)**（2026，[预印本]）——从轨迹定位提示词/知识/工具上下文问题。
14. **[Long-Horizon Agent Trajectory Attribution: A Unified Benchmark and Fine-Grained Annotation Framework](https://arxiv.org/abs/2608.06909)**（2026，[预印本]）——长轨迹精细归因数据与任务。
15. **[Where Do Deep-Research Agents Go Wrong? Span-Level Error Localization in Agent Trajectories](https://arxiv.org/abs/2606.02060)**（2026，[预印本]）——定位粒度与长程研究型 Agent 错误。
16. **[HINTBench: Horizon-agent Intrinsic Non-attack Trajectory Benchmark](https://arxiv.org/abs/2604.13954)**（2026，[预印本]）——非攻击场景内生失效及长轨迹风险。
17. **[A Survey for LLM Agent Trajectory Analysis: From Failure Attribution to Enhancement](https://doi.org/10.1109/TSE.2026.3717765)**（2026，[期刊，IEEE TSE Early Access]）——系统综述，避免漏掉直接竞争文献。
18. **[Counterfactual Planning for Generalizable Agents’ Actions](https://doi.org/10.1609/aaai.v40i35.40184)**（2026，[会议，AAAI 2026]）——Agent 行动决策中的 SCM 与反事实方法。
19. **[Improving Fault Localization with External Oracle by Using Counterfactual Execution](https://doi.org/10.1145/3695997)**（2025，[期刊，ACM TOSEM]）——程序调试中的外部 oracle 与反事实执行。

### B. 微服务与因果故障定位

20. **[Root Cause Analysis for Microservice System based on Causal Inference: How Far Are We?](https://arxiv.org/abs/2408.13729)**（2024，[预印本]）——实证比较 9 种因果发现及 21 种 RCA 法。
21. **[DynaCausal: Dynamic Causality-Aware Root Cause Analysis for Distributed Microservices](https://arxiv.org/abs/2510.22613)**（2025，[预印本]）——动态传播、漂移与噪声鲁棒性。
22. **[CausalRCA: Causal inference based precise fine-grained root cause localization for microservice applications](https://doi.org/10.1016/j.jss.2023.111724)**（2023，[期刊，JSS]）——细粒度指标级根因定位。
23. **[Root Cause Analysis in Microservice Using Neural Granger Causal Discovery](https://doi.org/10.1609/aaai.v38i1.27772)**（2024，[会议，AAAI 2024]）——Neural Granger 与时间因果。
24. **[CHASE: A Causal Heterogeneous Graph based Framework for Root Cause Analysis in Multimodal Microservice Systems](https://arxiv.org/abs/2406.19711)**（2024，[预印本]）——多模态日志、追踪、指标和异构图。
25. **[CauseLens: Causality-Based Interpretable Root Cause Analysis for Microservice Systems](https://ieeexplore.ieee.org/document/11143407/)**（2025，[会议，IEEE/ACM IWQoS]）——细粒度 SCM 与反事实传播路径。
26. **[CloudRanger: Root Cause Identification for Cloud Native Systems](https://doi.org/10.1109/CCGRID.2018.00076)**（2018，[会议，IEEE/ACM CCGrid]）——动态图依赖与根因排名。
27. **[MicroRCA: Root Cause Localization of Performance Issues in Microservices](https://doi.org/10.1109/NOMS47738.2020.9110353)**（2020，[会议，IEEE/IFIP NOMS]）——微服务拓扑与性能指标异常传播。
28. **[MicroHECL: High-Efficient Root Cause Localization in Large-Scale Microservice Systems](https://doi.org/10.1109/ICSE-SEIP52600.2021.00043)**（2021，[会议，ICSE-SEIP]）——大规模调用依赖上的高效异常定位。
29. **[Automated Analysis of Distributed Tracing: Challenges and Research Directions](https://doi.org/10.1007/s10723-021-09551-5)**（2021，[期刊，Journal of Grid Computing]）——追踪信息可用性与系统性挑战。

### C. 因果识别、序列与图模型基础

30. **[DAGs with NO TEARS: Continuous Optimization for Structure Learning](https://arxiv.org/abs/1803.01422)**（2018，[会议，NeurIPS]）——连续优化发现 DAG 的代表方法。
31. **[DAG-GNN: DAG Structure Learning with Graph Neural Networks](https://proceedings.mlr.press/v97/yu19a.html)**（2019，[会议，ICML]）——非线性图结构学习基线。
32. **[A Linear Non-Gaussian Acyclic Model for Causal Discovery](https://jmlr.csail.mit.edu/papers/v7/shimizu06a.html)**（2006，[期刊，JMLR]）——LiNGAM 和可识别性假设。
33. **[Causal inference by using invariant prediction: identification and confidence intervals](https://doi.org/10.1111/rssb.12167)**（2016，[期刊，JRSS B]）——跨环境不变性与识别条件。
34. **[Detecting and quantifying causal associations in large nonlinear time series datasets](https://doi.org/10.1126/sciadv.aau4996)**（2019，[期刊，Science Advances]）——PCMCI 时间序列因果图。
35. **[Discovering contemporaneous and lagged causal relations in autocorrelated nonlinear time series datasets](https://proceedings.mlr.press/v124/runge20a.html)**（2020，[会议，UAI]）——PCMCI+ 时延和同时因果边。

### D. 相邻系统与统计基础

- **阅读提醒**：新研究现状快速核对。
36. **[An Open-Source Benchmark Suite for Microservices and Their Hardware-Software Implications for Cloud and Edge Systems](https://github.com/delimitrou/DeathStarBench)**（2019，[会议，ASPLOS]）——DeathStarBench 的基准论文与代码入口。
37. **[MACIE: a multi-agent causal intelligence explainer for collective behavior understanding](https://doi.org/10.1007/s44163-026-01543-2)**（2026，[期刊，Discover Artificial Intelligence]）——多智能体行为的 SCM 与交互贡献。
38. **[Benchmarking Counterfactual Prediction in Epidemic Time Series with Time-Varying Interventions](https://doi.org/10.1145/3770855.3817522)**（2026，[会议论文，ACM DOI]）——具有可控干预的反事实基准建设思路。


**文献使用注意**：

- 上表按可核查标题和原始 DOI / arXiv / 出版会议页面组织，至少 30 条；存在同名 **AgentTrace**、**AgentEval** 但不同作者与主题的论文，不能合并误引。
- arXiv 预印本不等于正式同行评审，需在 2026 年 10 月后投稿前检查后续发表状态、内容版本及撤稿情况；有些官方页面同时显示早期预印本与后期会议条目，以最终引用版本为准。
- 参考文献的相关程度不同：系统相邻论文与经典因果方法应放在 Related Work / Method 背景，不能宣称为“直接对照 Agent 方法”；只有有开源实现及输入相容时才列入公平基线。
- 文献真实存在并不代表报告已逐篇核验正文所有实验细节；**正式投稿前必须阅读全文、核对 DOI/年份/作者、复核数学假设**。

---

## 12. 资源、规范与可复现链接（非论文，不计入文献数量）

- AgentRx 开源代码与数据：https://github.com/microsoft/AgentRx
- Who&When 数据入口：https://github.com/mingyin1/Agents_Failure_Attribution
- τ / τ² / τ³ 工具交互基准：https://github.com/sierra-research/tau2-bench
- DeathStarBench 原项目：https://github.com/delimitrou/DeathStarBench
- OpenTelemetry 常用语义规范：https://opentelemetry.io/docs/concepts/semantic-conventions/
- OpenTelemetry GenAI spans（Development 状态需注意）：https://github.com/open-telemetry/semantic-conventions-genai/blob/main/docs/gen-ai/gen-ai-spans.md
- Clarivate Master Journal List：https://mjl.clarivate.com/
- Elsevier 非 OA 订阅发表政策：https://www.elsevier.support/publishing/answer/what-is-elseviers-waiver-policy-for-open-access-fees

---

## 13. 给学弟的立项结论

**建议先立项一个“小而硬”的版本：**「通过网关埋点 + 受控沙箱重放，在相同预算下更快发现可修复的原因集合，并在缺乏证据时可靠弃权。」

本题最大理论风险是因果**不可识别**与反事实**不可真实重放**，最大创新风险是与 DoVer / REFLECT / Who&When 等工作重叠，最大工程风险是新系统在真实网关上引入额外成本。只有把这三类风险均变成可测量的实验，论文才真正具备跨因果推断和软件工程的研究价值。

**预计第一轮必须完成的验收输出**：

1. 带注入真值、可重复状态和干预器的最小因果工作流基准；
2. 同预算下至少三种干预策略的对照曲线；
3. 单根因与多根因、隐藏混杂与日志缺失四类场景的失败剖析；
4. 可检测并拒绝危险回放的网关安全测试；
5. 完整的因果假设表、置信区间及可核查实验脚本。

如果这五项尚未完成，**应称为研究计划或实验原型，不能称为已达到 SCI 发表水平**。

---

*文档用途：科研立项、文献研读、实验预注册与选刊初筛。禁止把示意结果、目标阈值、计划周期写成已取得的实验结论。*
