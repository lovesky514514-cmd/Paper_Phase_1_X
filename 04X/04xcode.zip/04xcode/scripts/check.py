"""One command checks Python, Go, race support, and real local HTTP demo."""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def run(args: list[str], *, cwd: Path = ROOT) -> str:
    print("CHECK", " ".join(args), flush=True)
    result = subprocess.run(args, cwd=cwd, text=True, encoding="utf-8", errors="replace",
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=120)
    print(result.stdout[-2200:])
    if result.returncode:
        raise RuntimeError(f"check failed with status {result.returncode}: {' '.join(args)}")
    return result.stdout


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--no-race", action="store_true", help="Skip Go race check (Windows without CGO)")
    parser.add_argument("--no-go", action="store_true", help="Run Python-only tests")
    args = parser.parse_args()
    if sys.version_info < (3, 11):
        raise SystemExit("Python 3.11+ is required")
    run([sys.executable, "-m", "compileall", "-q", "causalguard", "scripts", "tests"])
    output = run([sys.executable, "-m", "unittest", "discover", "-s", "tests", "-v"])
    if not args.no_go:
        if not shutil.which("go"):
            raise SystemExit("Go 1.22+ is required; use --no-go for Python tests only")
        run(["go", "test", "./..."], cwd=ROOT / "collector")
        run(["go", "vet", "./..."], cwd=ROOT / "collector")
        if not args.no_race:
            run(["go", "test", "-race", "./..."], cwd=ROOT / "collector")
        run([sys.executable, "scripts/demo.py"])
    run([sys.executable, "-m", "causalguard.study", "--count", "25", "--out", "results/local-check.json"])
    run([sys.executable, "scripts/verify_package.py"])
    print("PASS: behavior tests and selected integration checks")


if __name__ == "__main__":
    main()
