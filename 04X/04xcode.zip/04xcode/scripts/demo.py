"""End-to-end local demonstration: Go HTTP collection -> Python diagnosis."""
from __future__ import annotations

import json
import os
import socket
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from causalguard.budget import Budget  # noqa: E402
from causalguard.diagnose import diagnose  # noqa: E402
from causalguard.generate import make_case  # noqa: E402
from causalguard.traces import load_trace  # noqa: E402


def demo() -> dict:
    case = make_case(81, mode="and", topology="join", missing=0)
    with tempfile.TemporaryDirectory(prefix="cg4x-") as folder:
        path = Path(folder) / "spans.jsonl"
        program = Path(folder) / ("collector.exe" if os.name == "nt" else "collector")
        subprocess.run(["go", "build", "-o", str(program), "."], cwd=ROOT / "collector",
                       check=True, capture_output=True, text=True, timeout=90)
        # Bind local-only and get an ephemeral port (demo is not a security boundary).
        with socket.socket() as sock:
            sock.bind(("127.0.0.1", 0))
            port = sock.getsockname()[1]
        base = f"http://127.0.0.1:{port}"
        proc = subprocess.Popen([str(program), "-listen", f"127.0.0.1:{port}", "-log", str(path)],
                                cwd=ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        try:
            for _ in range(80):
                if proc.poll() is not None:
                    raise RuntimeError("collector terminated during startup")
                try:
                    with urllib.request.urlopen(base + "/healthz", timeout=0.25) as res:
                        if res.status == 200:
                            break
                except (OSError, TimeoutError):
                    time.sleep(0.05)
            else:
                raise RuntimeError("collector did not start")
            for span in case.trace.spans:
                request = urllib.request.Request(base + "/v1/spans",
                    data=json.dumps(span.to_dict()).encode("utf-8"),
                    headers={"Content-Type": "application/json"}, method="POST")
                with urllib.request.urlopen(request, timeout=2) as res:
                    if res.status != 202:
                        raise RuntimeError(f"failed to record span {span.span_id}")
            collected = load_trace(path, case.trace.trace_id)
            if collected.spans != case.trace.spans:
                raise AssertionError("trace content diverged through HTTP")
            report = diagnose(collected, case.sandbox, budget=Budget(max_replays=240))
            result = report.to_dict()
            result["collector_records"] = len(collected.spans)
            result["demo_only"] = "synthetic, no production tools or external egress"
            return result
        finally:
            proc.terminate()
            try:
                proc.communicate(timeout=4)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.communicate(timeout=4)


if __name__ == "__main__":
    print(json.dumps(demo(), ensure_ascii=False, indent=2))
