@echo off
setlocal
cd /d "%~dp0.."
where py >nul 2>nul
if not errorlevel 1 (py -3 scripts\check.py --no-race) else (python scripts\check.py --no-race)
if errorlevel 1 (echo CHECK FAILED & pause & exit /b 1)
echo CHECK PASSED
pause
