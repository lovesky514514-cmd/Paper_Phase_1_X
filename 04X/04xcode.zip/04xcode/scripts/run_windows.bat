@echo off
setlocal
cd /d "%~dp0.."
where py >nul 2>nul
if not errorlevel 1 (py -3 scripts\demo.py) else (python scripts\demo.py)
if errorlevel 1 (echo DEMO FAILED & pause & exit /b 1)
pause
