"""Verify the package's content hashes (manifest itself is excluded)."""
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def verify() -> None:
    expected = json.loads((ROOT / "PACKAGE_SHA256.json").read_text(encoding="utf-8"))
    if expected.get("hash") != "sha256" or not isinstance(expected.get("files"), dict):
        raise ValueError("invalid manifest")
    for filename, digest in expected["files"].items():
        candidate = (ROOT / filename).resolve()
        if not candidate.is_relative_to(ROOT.resolve()) or not candidate.is_file():
            raise ValueError(f"missing or unsafe path: {filename}")
        actual = hashlib.sha256(candidate.read_bytes()).hexdigest()
        if actual != digest:
            raise ValueError(f"SHA mismatch: {filename}")
    print("PASS: verified", len(expected["files"]), "files")


if __name__ == "__main__":
    try:
        verify()
    except Exception as error:
        print("FAIL:", error, file=sys.stderr)
        sys.exit(1)
