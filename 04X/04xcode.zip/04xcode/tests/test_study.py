import unittest

from causalguard.study import POLICIES, study


class StudyTests(unittest.TestCase):
    def test_no_truth_in_diagnoser_metrics(self):
        report = study(count=15, seed=71)
        self.assertEqual(set(report["strategies"]), set(POLICIES))
        self.assertEqual(report["cases"], 15)
        self.assertTrue(all(x["unsafe_replays"] == 0 for x in report["strategies"].values()))

    def test_identical_seed_reproduces_scientific_metrics(self):
        left = study(count=15, seed=91, missing=0.3)
        right = study(count=15, seed=91, missing=0.3)
        self.assertEqual(left, right)

    def test_failure_cases_remain_in_denominator(self):
        r = study(count=9, seed=4, max_replays=0)
        self.assertTrue(all(v["verified_repair_rate"] == 0 for v in r["strategies"].values()))

    def test_replay_limit_for_all_policies(self):
        report = study(count=21, seed=100, max_replays=16)
        for policy in report["strategies"].values():
            self.assertTrue(all(row["spent_replays"] <= 16 for row in policy["rows"]))


if __name__ == "__main__":
    unittest.main()
