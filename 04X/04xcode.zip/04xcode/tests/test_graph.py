import unittest

from causalguard.generate import make_case
from causalguard.graph import visible_ancestors


class GraphTests(unittest.TestCase):
    def test_full_trace_has_every_relevant_predecessor(self):
        for shape in ("chain", "fork", "join"):
            case = make_case(17, topology=shape)
            observed = {s.span_id for s in visible_ancestors(case.trace)}
            self.assertEqual(len(observed), 5)
            self.assertNotIn("finish", observed)

    def test_missing_parent_is_not_invented(self):
        case = make_case(18, missing=0.6)
        observed = {s.span_id for s in case.trace.spans}
        graph = {s.span_id for s in visible_ancestors(case.trace)}
        self.assertTrue(graph.issubset(observed))


if __name__ == "__main__":
    unittest.main()
