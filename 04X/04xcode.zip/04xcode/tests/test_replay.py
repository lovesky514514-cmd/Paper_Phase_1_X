import unittest

from causalguard.budget import Budget
from causalguard.generate import make_case
from causalguard.sandbox import ReplayDenied, ReplayPermit, SimSandbox


class ReplayTests(unittest.TestCase):
    def test_pair_uses_same_noise(self):
        sandbox = SimSandbox(frozenset({"A"}), "single", 31, nuisance=0.15)
        pairs = sandbox.paired_replay(frozenset({"A"}), 20)
        self.assertTrue(all(before >= after for before, after in pairs))
        self.assertEqual(sandbox.replay_count, 40)

    def test_or_requires_fixing_both(self):
        sandbox = SimSandbox(frozenset({"A", "B"}), "or", 31, nuisance=0)
        self.assertEqual(sandbox.paired_replay(frozenset({"A"}), 4), ((1, 1),) * 4)
        self.assertEqual(sandbox.paired_replay(frozenset({"A", "B"}), 4), ((1, 0),) * 4)

    def test_and_has_multiple_minimal_repairs(self):
        sandbox = SimSandbox(frozenset({"A", "B"}), "and", 31, nuisance=0)
        self.assertEqual(sandbox.paired_replay(frozenset({"A"}), 4), ((1, 0),) * 4)
        self.assertEqual(sandbox.paired_replay(frozenset({"B"}), 4), ((1, 0),) * 4)

    def test_rejects_each_broken_sandbox_contract(self):
        for field in ReplayPermit.__dataclass_fields__:
            permit = ReplayPermit(**{field: False})
            self.assertFalse(permit.allowed)
            sandbox = SimSandbox(frozenset({"A"}), "single", 3, permit)
            with self.assertRaises(ReplayDenied):
                sandbox.paired_replay(frozenset({"A"}), 4)
            self.assertEqual(sandbox.replay_count, 0)

    def test_budget_multiple_dimensions(self):
        budget = Budget(max_replays=12, max_tokens=30, max_time_units=12)
        self.assertTrue(budget.allows(4))
        budget.charge(4)
        self.assertEqual(budget.used_replays, 8)
        self.assertFalse(budget.allows(2))  # token budget exceeded
        with self.assertRaises(ValueError):
            budget.charge(2)

    def test_risk_budget_never_substitutes_permission(self):
        budget = Budget(max_risk_units=0)
        self.assertFalse(budget.allows(1, risky=True))


if __name__ == "__main__":
    unittest.main()
