import hashlib
import json
import tempfile
import unittest
from pathlib import Path

from causalguard.generate import make_case
from causalguard.model import Span, Trace
from causalguard.traces import load_trace


class ModelTests(unittest.TestCase):
    def test_trace_has_no_hidden_truth(self):
        case = make_case(12)
        serialized = json.dumps([s.to_dict() for s in case.trace.spans])
        self.assertNotIn("ground_repair_sets", serialized)
        self.assertNotIn("faults", serialized)

    def test_schema_roundtrip(self):
        event = make_case(17).trace.spans[0]
        self.assertEqual(Span.from_dict(event.to_dict()), event)

    def test_unknown_private_fields_are_not_saved(self):
        data = make_case(7).trace.spans[0].to_dict()
        data["password"] = "fake-secret"
        self.assertNotIn("password", Span.from_dict(data).to_dict())

    def test_required_fields_and_bad_ops(self):
        data = make_case(17).trace.spans[0].to_dict()
        data.pop("input_digest")
        with self.assertRaises(ValueError):
            Span.from_dict(data)
        data["input_digest"] = "a"
        data["operation"] = "send_money"
        with self.assertRaises(ValueError):
            Span.from_dict(data)

    def test_dependent_span_must_come_later(self):
        x = Span("t", "x", ("y",), "read", 1, 0.3, "0" * 64)
        y = Span("t", "y", (), "read", 2, 0.3, "1" * 64)
        with self.assertRaises(ValueError):
            Trace("t", (x, y), True)

    def test_missing_trace_and_schema_version(self):
        data = make_case(0, missing=0.4).trace.spans[0].to_dict()
        data["schema_version"] = "made-up.v2"
        with self.assertRaises(ValueError):
            Span.from_dict(data)

    def test_jsonl_loader_rejects_unrelated_truth(self):
        trace = make_case(5).trace
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "events.jsonl"
            rows = [dict(s.to_dict(), ground_truth="sneaky") for s in trace.spans]
            path.write_text("\n".join(json.dumps(x) for x in rows), encoding="utf-8")
            restored = load_trace(path, trace.trace_id)
        self.assertEqual(restored.spans, trace.spans)
        self.assertNotIn("ground_truth", restored.spans[0].to_dict())

    def test_generator_is_deterministic(self):
        self.assertEqual(make_case(99).trace, make_case(99).trace)

    def test_generator_rejects_bad_configuration(self):
        with self.assertRaises(ValueError):
            make_case(1, missing=1)
        with self.assertRaises(ValueError):
            make_case(1, mode="magic")


if __name__ == "__main__":
    unittest.main()
