import unittest
from dataclasses import replace

from causalguard.budget import Budget
from causalguard.diagnose import _wilson_lower, diagnose
from causalguard.generate import make_case
from causalguard.model import Span, Trace
from causalguard.sandbox import ReplayPermit, SimSandbox


class DiagnoseTests(unittest.TestCase):
    def test_exact_single_repair_when_observed(self):
        case = make_case(10, mode="single", missing=0)
        res = diagnose(case.trace, case.sandbox, budget=Budget(max_replays=240))
        self.assertTrue(set(map(frozenset, res.candidate_sets)) & set(case.ground_repair_sets))
        self.assertTrue(res.abstained_unique)  # repair != unique cause

    def test_or_pair_is_reported_as_a_set(self):
        case = make_case(10, mode="or", missing=0)
        res = diagnose(case.trace, case.sandbox, budget=Budget(max_replays=240))
        self.assertIn(tuple(sorted(next(iter(case.ground_repair_sets)))), res.candidate_sets)
        self.assertTrue(all(len(repair) >= 2 for repair in res.candidate_sets))

    def test_and_multiple_possible_repair_routes(self):
        case = make_case(10, mode="and", missing=0)
        res = diagnose(case.trace, case.sandbox, budget=Budget(max_replays=240))
        self.assertEqual(set(map(frozenset, res.candidate_sets)), set(case.ground_repair_sets))
        self.assertEqual(res.reason, "multiple_repair_sets_not_unique_cause")

    def test_zero_budget_forbids_replay(self):
        case = make_case(10)
        res = diagnose(case.trace, case.sandbox, budget=Budget(max_replays=0))
        self.assertEqual(res.budget_used["replays"], 0)
        self.assertFalse(res.candidate_sets)

    def test_missing_snapshot_abstains_and_does_not_replay(self):
        case = make_case(2, permit=ReplayPermit(snapshot_complete=False))
        res = diagnose(case.trace, case.sandbox)
        self.assertEqual(res.reason, "replay_contract_not_satisfied")
        self.assertEqual(case.sandbox.replay_count, 0)

    def test_real_write_action_is_not_a_candidate(self):
        case = make_case(2, missing=0)
        spans = tuple(replace(s, operation="external_write") if s.span_id == "analyze" else s
                      for s in case.trace.spans)
        trace = Trace(case.trace.trace_id, spans, True)
        res = diagnose(trace, case.sandbox, budget=Budget(max_replays=240))
        self.assertEqual(res.reason, "external_effect_not_replayable")
        self.assertEqual(case.sandbox.replay_count, 0)

    def test_cannot_claim_on_successful_task(self):
        case = make_case(2)
        res = diagnose(replace(case.trace, failed=False), case.sandbox)
        self.assertEqual(res.reason, "task_did_not_fail")

    def test_report_exposes_cost_and_evidence_level(self):
        case = make_case(2, missing=0)
        result = diagnose(case.trace, case.sandbox)
        self.assertIn("budget_used", result.to_dict())
        self.assertEqual(result.unsafe_replays, 0)
        self.assertLessEqual(result.budget_used["replays"], 48)

    def test_missing_data_never_invented(self):
        case = make_case(12, missing=0.7)
        res = diagnose(case.trace, case.sandbox)
        ids = {s.span_id for s in case.trace.spans}
        self.assertTrue(all(set(t).issubset(ids) for t in res.candidate_sets))

    def test_wilson_bound_not_unconditional_proof(self):
        self.assertLess(_wilson_lower(4, 4), 1)
        self.assertEqual(_wilson_lower(0, 4), 0)

    def test_strategy_names(self):
        case = make_case(2)
        for name in ("value", "anomaly", "random", "uncertainty", "cost_only"):
            self.assertEqual(diagnose(case.trace, case.sandbox, strategy=name).strategy, name)
        with self.assertRaises(ValueError):
            diagnose(case.trace, case.sandbox, strategy="oracle")

    def test_invalid_trials_rejected(self):
        case = make_case(3)
        with self.assertRaises(ValueError):
            diagnose(case.trace, case.sandbox, trials=1)


if __name__ == "__main__":
    unittest.main()
