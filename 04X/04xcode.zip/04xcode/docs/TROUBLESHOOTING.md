# 常见问题

| 症状 | 检查与解决 |
|---|---|
| `No module named causalguard` | 在 `04xcode` 根目录运行；不要在 `scripts/` 中直接执行模块。 |
| `go: command not found` | 安装 Go 1.22+；纯算法阶段可 `python scripts/check.py --no-go`。 |
| Windows Go 竞态检测失败 | 默认 bat 已 `--no-race`；Go race 通常需要 CGO/C 工具链。 |
| 端口占用 | 演示使用动态本地端口；手动启动 Go 时修改 `-listen`。 |
| `replay_contract_not_satisfied` | 检查授权、隔离、无出站、版本、快照及模拟写入六项，不得绕过安全门。 |
| `external_effect_not_replayable` | 移除真实外部写行为并在**隔离的合成场景**重新建模；不要添加跳过检查开关。 |
| `budget_exhausted` | 减少候选/试验数，或明确增加实验预算；不能把弃权写成诊断失败。 |
| `multiple_repair_sets_not_unique_cause` | 多个修复方案都有效，继续安全干预或保留不唯一的结论。 |
| 结果与上次 wall_ms 不同 | 计时不可确定性，比较固定种子下的科研指标与回放次数。 |
| `invalid or unsafe trace record` | 只发送 v1 allowlist 字段；不能提交原始提示词、密钥、路径或未定义属性。 |

逐文件排查见 `DEBUG_INDEX.md`。
