# 架构与接口

```text
Agent / local synthetic trace
      ↓ allowlisted metadata (no raw prompts)
Go collector :127.0.0.1 → JSONL
      ↓ load_trace(versioned parser)
Trace → graph.visible_ancestors (observed dependency ancestry)
      ↓ candidate repair interventions (never infer missing span)
Diagnoser → Budget (hard caps) → ReplayPermit → SimSandbox
      ↓ paired failure outcomes, Wilson beneficial-flip lower bound
Diagnosis: minimal verified repair sets + non-unique abstention + evidence tier
```

- Go `GET /healthz`, `POST /v1/spans`。事件使用 `causalguard.span.v1`，未知字段被拒绝；输入内容仅存 SHA-256 摘要。
- Python `diagnose(trace, sandbox, budget=..., strategy=...)` 为主要接口；`simulator` 不公开因果生成标签。
- 所有候选仅来自**可观测** Span 的调用链祖先；父 Span 缺失就停止推断那条边。
- `single`（单源）、`or`（独立致因路径需组合修复）、`and`（交互故障任意单支修复即可恢复）为测试 SCM，**不是学成的因果模型**。
- 所有不可逆或不透明外部写操作一经出现，回放全部停止；没有真实网关执行面。

## 保障范围

Go 只接收指定元数据；模拟器不包含外部网络调用。其安全性质不外推到生产插件、外部数据服务、Docker/VM 安全或真实世界因果识别。
