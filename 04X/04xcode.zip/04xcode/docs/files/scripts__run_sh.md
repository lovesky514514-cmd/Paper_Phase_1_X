# scripts/run.sh

**职责**：Linux/macOS 演示脚本。

**常见症状**：演示命令退出非零。

**排查及修复**：执行 sh scripts/run.sh，确认本机 loopback 可用。

**验证**：在项目根目录执行 `python scripts/check.py`；如需仅检查 Python，可加 `--no-go`。
