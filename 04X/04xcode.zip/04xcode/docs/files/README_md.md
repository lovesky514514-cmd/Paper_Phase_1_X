# README.md

**职责**：快速安装与操作入口。

**常见症状**：执行命令失效。

**排查及修复**：在项目根目录按步骤运行，缺 Go 时先做 Python-only 测试。

**验证**：在项目根目录执行 `python scripts/check.py`；如需仅检查 Python，可加 `--no-go`。
