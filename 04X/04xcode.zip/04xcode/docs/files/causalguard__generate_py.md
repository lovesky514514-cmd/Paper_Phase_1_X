# causalguard/generate.py

**职责**：合成 DAG、故障注入与仅评分可见的真值。

**常见症状**：同种子不同轨迹或异常标签泄漏。

**排查及修复**：确认 random.Random 使用局部 seed 且不将 ground_repair_sets 交给诊断器。

**验证**：在项目根目录执行 `python scripts/check.py`；如需仅检查 Python，可加 `--no-go`。
