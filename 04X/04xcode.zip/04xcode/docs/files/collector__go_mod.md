# collector/go.mod

**职责**：Go 工具链与模块声明。

**常见症状**：go: incompatible version。

**排查及修复**：安装 Go 1.22+，在 collector 目录运行 go test ./...。

**验证**：在项目根目录执行 `python scripts/check.py`；如需仅检查 Python，可加 `--no-go`。
