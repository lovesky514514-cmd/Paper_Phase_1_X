# causalguard/graph.py

**职责**：仅使用已观测边重建上游候选集合。

**常见症状**：候选意外消失或依赖图不完整。

**排查及修复**：检查 finish 的 parents 和缺失记录，不要擅自补边。

**验证**：在项目根目录执行 `python scripts/check.py`；如需仅检查 Python，可加 `--no-go`。
