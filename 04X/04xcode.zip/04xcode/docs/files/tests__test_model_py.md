# tests/test_model.py

**职责**：脱敏 schema 与日志加载行为回归。

**常见症状**：Schema 规则变化后测试失败。

**排查及修复**：核对兼容版本而非静默接受敏感字段。

**验证**：在项目根目录执行 `python scripts/check.py`；如需仅检查 Python，可加 `--no-go`。
