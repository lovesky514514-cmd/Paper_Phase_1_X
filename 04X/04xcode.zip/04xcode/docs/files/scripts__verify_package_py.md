# scripts/verify_package.py

**职责**：SHA-256 文件内容清单验证。

**常见症状**：SHA mismatch 或缺少文件。

**排查及修复**：重新下载原包或从可信源码重建，不手动修改清单掩盖错误。

**验证**：在项目根目录执行 `python scripts/check.py`；如需仅检查 Python，可加 `--no-go`。
