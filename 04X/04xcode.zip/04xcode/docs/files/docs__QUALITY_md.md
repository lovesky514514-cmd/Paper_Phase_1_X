# docs/QUALITY.md

**职责**：自检项目与未实现边界。

**常见症状**：错误地推断生产保证。

**排查及修复**：阅读未实现列表；Go Collector 仅本地数据采集。

**验证**：在项目根目录执行 `python scripts/check.py`；如需仅检查 Python，可加 `--no-go`。
