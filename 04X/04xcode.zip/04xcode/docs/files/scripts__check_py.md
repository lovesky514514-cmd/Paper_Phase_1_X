# scripts/check.py

**职责**：统一 Python/Go/竞态/HTTP/哈希自检。

**常见症状**：测试无法启动或退出码不为零。

**排查及修复**：先查看失败命令；单独执行并检查 Python 3.11+ 与 Go 1.22+。

**验证**：在项目根目录执行 `python scripts/check.py`；如需仅检查 Python，可加 `--no-go`。
