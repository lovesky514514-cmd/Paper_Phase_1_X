# CODING_STANDARDS.md

**职责**：Skill 落地的项目约定。

**常见症状**：代码风格不统一。

**排查及修复**：遵守小接口、单一账本位置、精确领域术语；测试行为而非布局。

**验证**：在项目根目录执行 `python scripts/check.py`；如需仅检查 Python，可加 `--no-go`。
