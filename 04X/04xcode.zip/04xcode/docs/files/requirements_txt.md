# requirements.txt

**职责**：无第三方 Python 依赖声明。

**常见症状**：pip 安装异常。

**排查及修复**：直接用 Python 标准库，不执行无关 pip install。

**验证**：在项目根目录执行 `python scripts/check.py`；如需仅检查 Python，可加 `--no-go`。
