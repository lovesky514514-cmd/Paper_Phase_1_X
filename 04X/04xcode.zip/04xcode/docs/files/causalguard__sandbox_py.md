# causalguard/sandbox.py

**职责**：可重复、不可连接外网的隔离因果模型。

**常见症状**：ReplayDenied 或回放前后不一致。

**排查及修复**：逐项核对 ReplayPermit；配对基线/干预必须使用同一 trial seed。

**验证**：在项目根目录执行 `python scripts/check.py`；如需仅检查 Python，可加 `--no-go`。
