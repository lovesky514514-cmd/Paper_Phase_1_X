# causalguard/traces.py

**职责**：读取 Go JSONL，按 trace_id 过滤并保留允许字段。

**常见症状**：加载空轨迹或 JSON 解析失败。

**排查及修复**：检查 JSONL 行是否为完整 Span v1 和 trace_id 匹配。

**验证**：在项目根目录执行 `python scripts/check.py`；如需仅检查 Python，可加 `--no-go`。
