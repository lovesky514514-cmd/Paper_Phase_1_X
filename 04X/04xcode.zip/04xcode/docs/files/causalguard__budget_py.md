# causalguard/budget.py

**职责**：回放次数、模拟 Token、模拟耗时与风险硬预算。

**常见症状**：budget exceeded 或费用统计异常。

**排查及修复**：核对 2 次 replay/paired-trial、6 token units/trial、2 time units/trial。

**验证**：在项目根目录执行 `python scripts/check.py`；如需仅检查 Python，可加 `--no-go`。
