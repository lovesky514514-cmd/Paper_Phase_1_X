# docs/ARCHITECTURE.md

**职责**：边界、数据流、可信假设与接口。

**常见症状**：不清楚哪层负责真值。

**排查及修复**：原始因果真值仅在测试评测器，诊断器只见脱敏元数据和 paired 结果。

**验证**：在项目根目录执行 `python scripts/check.py`；如需仅检查 Python，可加 `--no-go`。
