# causalguard/__init__.py

**职责**：Python 模块入口。

**常见症状**：No module named causalguard。

**排查及修复**：在项目根目录运行 python -m causalguard.study。

**验证**：在项目根目录执行 `python scripts/check.py`；如需仅检查 Python，可加 `--no-go`。
