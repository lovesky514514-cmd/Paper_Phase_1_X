# scripts/check.sh

**职责**：Linux/macOS 自检脚本。

**常见症状**：Permission denied / python3 not found。

**排查及修复**：执行 sh scripts/check.sh，安装 python3 与 Go。

**验证**：在项目根目录执行 `python scripts/check.py`；如需仅检查 Python，可加 `--no-go`。
