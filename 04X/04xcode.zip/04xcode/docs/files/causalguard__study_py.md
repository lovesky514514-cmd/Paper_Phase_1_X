# causalguard/study.py

**职责**：固定种子下五组本地策略的配对对照。

**常见症状**：多次运行的科学指标变化。

**排查及修复**：确认 count/seed/missing/replays 参数一致；wall time 不参与精确一致性断言。

**验证**：在项目根目录执行 `python scripts/check.py`；如需仅检查 Python，可加 `--no-go`。
