# scripts/demo.py

**职责**：真正本地 HTTP 发 Span→JSONL→诊断链演示。

**常见症状**：collector 启动超时或连接中断。

**排查及修复**：确认 go 命令可用、loopback 许可和临时目录可写。

**验证**：在项目根目录执行 `python scripts/check.py`；如需仅检查 Python，可加 `--no-go`。
