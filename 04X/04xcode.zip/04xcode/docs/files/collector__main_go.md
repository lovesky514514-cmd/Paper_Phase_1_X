# collector/main.go

**职责**：127.0.0.1 本地 Go collector 启动入口。

**常见症状**：监听失败/端口占用。

**排查及修复**：使用 -listen 127.0.0.1:另一端口；不能改成公网地址。

**验证**：在项目根目录执行 `python scripts/check.py`；如需仅检查 Python，可加 `--no-go`。
