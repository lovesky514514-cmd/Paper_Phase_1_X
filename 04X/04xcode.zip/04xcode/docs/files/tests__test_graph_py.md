# tests/test_graph.py

**职责**：可观测上游依赖图测试。

**常见症状**：日志缺失时出现不存在的祖先。

**排查及修复**：只使用真实记录的 parent id，保留缺失数据。

**验证**：在项目根目录执行 `python scripts/check.py`；如需仅检查 Python，可加 `--no-go`。
