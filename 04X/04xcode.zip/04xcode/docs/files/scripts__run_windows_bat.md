# scripts/run_windows.bat

**职责**：Windows 一键端到端演示。

**常见症状**：命令找不到或演示错误。

**排查及修复**：检查 py -3/python 和 Go 在 PATH 中；先跑 check_windows.bat。

**验证**：在项目根目录执行 `python scripts/check.py`；如需仅检查 Python，可加 `--no-go`。
