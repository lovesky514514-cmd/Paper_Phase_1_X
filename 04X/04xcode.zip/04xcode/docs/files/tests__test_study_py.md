# tests/test_study.py

**职责**：公平对照、重复性与失败样本分母测试。

**常见症状**：同 seed 指标不同或某策略超预算。

**排查及修复**：确保所有策略读同一可观测轨迹和公平预算。

**验证**：在项目根目录执行 `python scripts/check.py`；如需仅检查 Python，可加 `--no-go`。
