# causalguard/model.py

**职责**：脱敏 Span 与 Trace 结构、输入合法性。

**常见症状**：schema_version/parents 不正确。

**排查及修复**：核对 v1 元数据与父调用时间；不要添加隐藏真值到 Span。

**验证**：在项目根目录执行 `python scripts/check.py`；如需仅检查 Python，可加 `--no-go`。
