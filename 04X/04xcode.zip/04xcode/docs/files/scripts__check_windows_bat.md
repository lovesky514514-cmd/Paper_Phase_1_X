# scripts/check_windows.bat

**职责**：Windows 一键自检。

**常见症状**：窗口退出/找不到 Python。

**排查及修复**：安装 Python 3.11+ 和 Go，检查 py -3 命令；输出窗口不会自动关闭。

**验证**：在项目根目录执行 `python scripts/check.py`；如需仅检查 Python，可加 `--no-go`。
