# results/pilot.json

**职责**：固定配置合成对照原始输出。

**常见症状**：结果不一致或想看失败案例。

**排查及修复**：运行 python -m causalguard.study --count 120 --seed 19 --missing 0.15 --replays 48。

**验证**：在项目根目录执行 `python scripts/check.py`；如需仅检查 Python，可加 `--no-go`。
