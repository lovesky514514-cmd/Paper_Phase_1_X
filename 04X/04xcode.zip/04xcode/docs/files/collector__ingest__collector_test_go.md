# collector/ingest/collector_test.go

**职责**：collector 的拒绝危险字段与并发原子性测试。

**常见症状**：Go 测试失败。

**排查及修复**：单独运行 go test -v ./ingest；保留失败输入，不削弱字段过滤。

**验证**：在项目根目录执行 `python scripts/check.py`；如需仅检查 Python，可加 `--no-go`。
