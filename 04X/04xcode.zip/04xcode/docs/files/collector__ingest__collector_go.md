# collector/ingest/collector.go

**职责**：HTTP 脱敏元数据采集与并发 JSONL 写入。

**常见症状**：400/500 状态或乱序日志。

**排查及修复**：校验 schema、digest、payload 体积、文件写权限；运行 go test -race ./...。

**验证**：在项目根目录执行 `python scripts/check.py`；如需仅检查 Python，可加 `--no-go`。
