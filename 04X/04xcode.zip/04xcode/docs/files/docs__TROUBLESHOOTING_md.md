# docs/TROUBLESHOOTING.md

**职责**：常见安装/执行/研究误区。

**常见症状**：一般异常无法定位。

**排查及修复**：先匹配报错，再看 DEBUG_INDEX 对应文件。

**验证**：在项目根目录执行 `python scripts/check.py`；如需仅检查 Python，可加 `--no-go`。
