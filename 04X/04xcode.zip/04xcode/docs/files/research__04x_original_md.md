# research/04x_original.md

**职责**：原始 04 研究规划与边界。

**常见症状**：需求口径不一致。

**排查及修复**：对照原始 RQ 和实验层级，禁止以本地启发式冒充官方复现。

**验证**：在项目根目录执行 `python scripts/check.py`；如需仅检查 Python，可加 `--no-go`。
