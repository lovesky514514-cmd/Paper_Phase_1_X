# tests/test_replay.py

**职责**：AND/OR/single 配对 SCM 与回放契约测试。

**常见症状**：回放允许不安全动作或噪声错位。

**排查及修复**：确保全部许可条件同时为真，配对使用同一噪声种子。

**验证**：在项目根目录执行 `python scripts/check.py`；如需仅检查 Python，可加 `--no-go`。
